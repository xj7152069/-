﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data.SqlClient
Imports System.Math


Public Class Form4
    Dim myconn As New SqlConnection("initial catalog=china earthquake;data source=10.10.109.119;user id=tj5;password=db18-5")
    Dim mydataset As New DataSet
    Dim mybind As New BindingSource
    Dim mybinds As New BindingSource
    Dim c(16000), b(16000), d(16000), r(16000) As String
    Dim f(16000), g(16000) As String
    Dim mybind1 As New BindingSource
    Dim mybind2 As New BindingSource
    Private fs As FileStream
    Dim myoldataset As DataSet = New DataSet
   

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        OpenFileDialog1.Filter = "(*.xls)|*.xls|(*.xlsx)|*.xlsx"
        OpenFileDialog1.FilterIndex = 2
        If Not Me.OpenFileDialog1.ShowDialog(Me) = vbOK Then
            Exit Sub
        End If
        Dim myolconn As New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Me.OpenFileDialog1.FileName & ";User ID=Admin;Password=;Extended properties=Excel 12.0")
        Dim myoladapter As OleDb.OleDbDataAdapter = New OleDb.OleDbDataAdapter("SELECT * FROM [Table1$]", myolconn)
        myoladapter.Fill(myoldataset)
        DataGridView3.DataSource = myoldataset.Tables(0)
        Me.Label文件路径.Text = OpenFileDialog1.FileName
        k = 14
    End Sub


    Private Sub Button14_Click(sender As Object, e As EventArgs) Handles Button14.Click
        If Me.ComboBox时间删除下限.Text = "" Then
            ComboBox时间删除下限.Text = Form2.TextBox时间跨度下限.Text
        End If
        If Me.ComboBox时间删除上限.Text = "" Then
            ComboBox时间删除上限.Text = Form2.TextBox时间跨度上限.Text
        End If
        If Me.TextBox纬度删除下限.Text = "" Then
            Me.TextBox纬度删除下限.Text = Form2.TextBox纬度跨度下限.Text
        End If
        If Me.TextBox纬度删除上限.Text = "" Then
            Me.TextBox纬度删除上限.Text = Form2.TextBox纬度跨度上限.Text
        End If
        If Me.TextBox经度删除下限.Text = "" Then
            Me.TextBox经度删除下限.Text = Form2.TextBox经度跨度下限.Text
        End If
        If Me.TextBox经度删除上限.Text = "" Then
            Me.TextBox经度删除上限.Text = Form2.TextBox经度跨度上限.Text
        End If
        If Me.TextBox震级删除下限.Text = "" Then
            Me.TextBox震级删除下限.Text = 0
        End If
        If Me.TextBox震级删除上限.Text = "" Then
            Me.TextBox震级删除上限.Text = 10
        End If
        mydataset.Tables("查询1").Clear()
        Dim str3 As String = "select * from earthquake where 时间>='" & ComboBox时间删除下限.Text & "' and 时间<='" & ComboBox时间删除上限.Text & "' and 纬度>='" & TextBox纬度删除下限.Text & "' and 纬度<='" & TextBox纬度删除上限.Text & "' and 经度>='" & TextBox经度删除下限.Text & "'and 经度<='" & TextBox经度删除上限.Text & "' and 震级>='" & TextBox震级删除下限.Text & "' and 震级<='" & TextBox震级删除上限.Text & "'"
        Dim myad3 As New SqlDataAdapter(str3, myconn)
        myad3.Fill(mydataset, "查询1")
        Me.DataGridView1.DataSource = mydataset.Tables("查询1")
        Label16.Text = mydataset.Tables("查询1").Rows.Count
        TextBox经度删除浏览.DataBindings.Clear()
        TextBox纬度删除浏览.DataBindings.Clear()
        TextBox震级删除浏览.DataBindings.Clear()
        TextBox深度删除浏览.DataBindings.Clear()
        TextBox时间删除浏览.DataBindings.Clear()
        TextBox位置删除浏览.DataBindings.Clear()
        mybind1.DataSource = mydataset
        mybind1.DataMember = "查询1"
        TextBox经度删除浏览.DataBindings.Add(New Binding("text", mybind1, "经度", True))
        TextBox纬度删除浏览.DataBindings.Add(New Binding("text", mybind1, "纬度", True))
        TextBox震级删除浏览.DataBindings.Add(New Binding("text", mybind1, "震级", True))
        TextBox深度删除浏览.DataBindings.Add(New Binding("text", mybind1, "震源深度", True))
        TextBox时间删除浏览.DataBindings.Add(New Binding("text", mybind1, "时间", True))
        TextBox位置删除浏览.DataBindings.Add(New Binding("text", mybind1, "区域位置", True))

    End Sub

  
    
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Label删除说明3.Parent = PictureBox删除说明
        OpenFileDialog1.FileName = Nothing
        Dim mystr4 As String = "select * from picture"
        Dim myadapter4 As New SqlDataAdapter(mystr4, myconn)
        myadapter4.Fill(mydataset, "删除科普")
        mydataset.Tables("删除科普").Clear()
        Dim mystr As String = "select * from photo where 专题名称='" & Me.ComboBox1.Text & "'"
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        Dim mycomm As New SqlCommand
        mycomm.Connection = myconn
        myadapter.Fill(mydataset, "专题删除")
        mydataset.Tables("专题删除").Clear()
        Dim str1 As String = "select * from earthquake"
        Dim myad1 As New SqlDataAdapter(str1, myconn)
        myad1.Fill(mydataset, "查询1")
        mydataset.Tables("查询1").Clear()
        Dim str2 As String
        str2 = "select 震级 from earthquake"
        mycomm.CommandText = str2
        myadapter.SelectCommand = mycomm
        myadapter.Fill(mydataset, "筛选")
        myad1.Fill(mydataset, "筛选")
        mydataset.Tables("筛选").Clear()
        Me.ComboBox时间删除上限.Items.Clear()
        Me.ComboBox时间删除下限.Items.Clear()
        ComboBox时间删除下限.Text = Form2.TextBox时间跨度下限.Text
        ComboBox时间删除上限.Text = Form2.TextBox时间跨度上限.Text
        Me.TextBox纬度删除下限.Text = Form2.TextBox纬度跨度下限.Text
        Me.TextBox纬度删除上限.Text = Form2.TextBox纬度跨度上限.Text
        Me.TextBox经度删除下限.Text = Form2.TextBox经度跨度下限.Text
        Me.TextBox经度删除上限.Text = Form2.TextBox经度跨度上限.Text
        Me.TextBox震级删除下限.Text = 0
        Me.TextBox震级删除上限.Text = 10
        Dim str6 As String = "select distinct left(ltrim(时间),7) as x from earthquake order by x asc"
        Dim myad6 As New SqlDataAdapter(str6, myconn)
        myad6.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox时间删除上限.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
            Me.ComboBox时间删除下限.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs)
        ReDim c(16000), b(16000), d(16000)
        For i = 1 To mydataset.Tables("查询1").Rows.Count
            c(i) = mydataset.Tables("查询1").Rows(i - 1).Item("经度")
            b(i) = mydataset.Tables("查询1").Rows(i - 1).Item("纬度")
            d(i) = mydataset.Tables("查询1").Rows(i - 1).Item("震级")
        Next
    End Sub

    Private Sub Button23_Click(sender As Object, e As EventArgs) Handles Button23.Click
        Dim mysql1 As String
        mysql1 = "insert into earthquake values('" & TextBox时间添加.Text & "'," & Val(TextBox震级添加.Text) & "," & Val(TextBox纬度添加.Text) & "," & Val(TextBox经度添加.Text) & "," & Val(TextBox深度添加.Text) & ",'" & TextBox位置添加.Text & "')"
        Dim mycomm1 As New SqlCommand(mysql1, myconn)
        Dim s% = 0
        myconn.Open()
             Try
            s = mycomm1.ExecuteNonQuery()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        If s >= 1 Then
            MsgBox("导入成功")
        End If
        myconn.Close()
    End Sub

   
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        mybind1.MoveFirst()
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        mybind1.MovePrevious()
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        mybind1.MoveNext()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        mybind1.MoveLast()
    End Sub

    Private Sub Button13_Click(sender As Object, e As EventArgs) Handles Button13.Click
        Dim str2 As String = "delete from earthquake where 震级='" & TextBox震级删除浏览.Text & "' and 经度='" & TextBox经度删除浏览.Text & "' and 纬度='" & TextBox纬度删除浏览.Text & "' and 时间='" & TextBox时间删除浏览.Text & "'"
        Dim mycomm As New SqlCommand(str2, myconn)
        mycomm.CommandType = CommandType.Text
        myconn.Open()
        mycomm.ExecuteNonQuery()
        MsgBox("已移除，请点击'开始查询'按钮进行刷新")
        myconn.Close()
    End Sub

    Private Sub Button24_Click(sender As Object, e As EventArgs) Handles Button24.Click
        Me.TextBox时间添加.Clear()
        Me.TextBox经度添加.Clear()
        Me.TextBox纬度添加.Clear()
        Me.TextBox深度添加.Clear()
        Me.TextBox位置添加.Clear()
        Me.TextBox震级添加.Clear()
    End Sub

    Private Sub Button12_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button16_Click(sender As Object, e As EventArgs) Handles Button16.Click
        If k = 99 Then
            MsgBox("您不能重复添加专题的基本信息，若要更改基本信息则需先删除整个专题")
        Else
            Dim mysql1 As String
            Dim s% = 0
            mysql1 = "insert into information values('" & TextBox时间专题添加.Text & "'," & Val(TextBox震级专题添加.Text) & "," & Val(TextBox纬度专题添加.Text) & "," & Val(TextBox经度专题添加.Text) & "," & Val(TextBox深度专题添加.Text) & ",'" & TextBox位置专题添加.Text & "','" & TextBox专题名称.Text & "')"
            Dim mycomm1 As New SqlCommand(mysql1, myconn)
            myconn.Open()
            Try
                s = mycomm1.ExecuteNonQuery()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            If s >= 1 Then
                MsgBox("导入成功")
            End If
            myconn.Close()
            k = 99
        End If
    End Sub

    Private Sub Button11_Click_1(sender As Object, e As EventArgs) Handles Button11.Click
        myconn.Close()
        If k = 99 Then
            If OpenFileDialog1.FileName = Nothing Then
                MsgBox("请插入图片")
            Else
                Dim sqlcomm As New SqlCommand
                sqlcomm.CommandText = "INSERT INTO photo (专题名称,照片标题,说明,图片) VALUES (@专题名称,@照片标题,@说明,@图片)"
                sqlcomm.Connection = myconn
                fs = New FileStream(Me.OpenFileDialog1.FileName.ToString(), FileMode.Open, FileAccess.Read)
                Dim Data(fs.Length) As Byte
                fs.Read(Data, 0, Int(fs.Length))
                Dim prm1 As New SqlParameter("@专题名称", Me.ComboBox专题添加.Text)
                Dim prm2 As New SqlParameter("@照片标题", Me.TextBox2.Text)
                Dim prm3 As New SqlParameter("@说明", Me.TextBox3.Text)
                Dim prm4 As New SqlParameter("@图片", SqlDbType.Image, Int(fs.Length), ParameterDirection.Input, False, 0, 0, "", DataRowVersion.Current, Data)
                sqlcomm.Parameters.Add(prm1)
                sqlcomm.Parameters.Add(prm2)
                sqlcomm.Parameters.Add(prm3)
                sqlcomm.Parameters.Add(prm4)
                myconn.Open()
                Dim s% = 0
                Try
                    s = sqlcomm.ExecuteNonQuery()
                Catch ex As Exception
                    MsgBox(ex.Message)
                End Try
                If s >= 1 Then
                    MsgBox("导入成功")
                End If
                myconn.Close()
                fs.Close()
            End If
        End If
        If k = 98 Then
            MsgBox("请先添加基本信息")
        End If
    End Sub

    Private Sub Button33_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Me.TextBox位置专题添加.Clear()
        Me.TextBox震级专题添加.Clear()
        Me.TextBox纬度专题添加.Clear()
        Me.TextBox时间专题添加.Clear()
        Me.TextBox经度专题添加.Clear()
        Me.TextBox深度专题添加.Clear()
        Me.TextBox2.Clear()
        Me.TextBox3.Clear()
        Dim str2 As String = "select  * from information where information.专题名称='" & Me.ComboBox1.Text & "'"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        Me.TextBox专题修改经度.Text = mydataset.Tables("t1").Rows(0).Item("经度")
        Me.TextBox专题修改深度.Text = mydataset.Tables("t1").Rows(0).Item("震源深度")
        Me.TextBox专题修改时间.Text = mydataset.Tables("t1").Rows(0).Item("时间")
        Me.TextBox专题修改纬度.Text = mydataset.Tables("t1").Rows(0).Item("纬度")
        Me.TextBox专题修改位置.Text = mydataset.Tables("t1").Rows(0).Item("区域位置")
        Me.TextBox专题修改震级.Text = mydataset.Tables("t1").Rows(0).Item("震级")
        mydataset.Tables("t1").Clear()
        mydataset.Tables("专题删除").Clear()
        PictureBox7.Image = Nothing
        TextBox4.Clear()
        TextBox1.Clear()
        Dim mystr As String = "select * from photo where 专题名称='" & Me.ComboBox1.Text & "'"
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        myadapter.Fill(mydataset, "专题删除")
        TextBox1.DataBindings.Clear()
        TextBox4.DataBindings.Clear()
        PictureBox7.DataBindings.Clear()
        mybind.DataSource = mydataset
        mybind.DataMember = "专题删除"
        TextBox1.DataBindings.Add(New Binding("text", mybind, "照片标题", True))
        TextBox4.DataBindings.Add(New Binding("text", mybind, "说明", True))
        PictureBox7.DataBindings.Add(New Binding("image", mybind, "图片", True))
    End Sub


    Private Sub TabPage4_Enter(sender As Object, e As EventArgs) Handles TabPage4.Enter
        Me.ComboBox1.Items.Clear()
        Dim str2 As String = "select  distinct 专题名称 as x from information"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox1.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()
    End Sub

    Private Sub TextBox专题名称_TextChanged(sender As Object, e As EventArgs) Handles TextBox专题名称.TextChanged
        k = 98
        Me.TextBox位置专题添加.Clear()
        Me.TextBox震级专题添加.Clear()
        Me.TextBox纬度专题添加.Clear()
        Me.TextBox时间专题添加.Clear()
        Me.TextBox经度专题添加.Clear()
        Me.TextBox深度专题添加.Clear()
        Me.TextBox2.Clear()
        Me.TextBox3.Clear()
        PictureBox6.Image = Nothing
    End Sub

    Private Sub Button36_Click(sender As Object, e As EventArgs) Handles Button36.Click
        myconn.Close()
        Dim str3 As String = "delete from photo where photo.专题名称='" & Me.ComboBox1.Text & "'"
        Dim mycomm3 As New SqlCommand(str3, myconn)
        mycomm3.CommandType = CommandType.Text
        myconn.Open()
        mycomm3.ExecuteNonQuery()
        myconn.Close()
        Dim str1 As String = "delete from information where information.专题名称='" & Me.ComboBox1.Text & "'"
        Dim mycomm1 As New SqlCommand(str1, myconn)
        mycomm1.CommandType = CommandType.Text
        myconn.Open()
        mycomm1.ExecuteNonQuery()
        MsgBox("已删除")
        myconn.Close()
        Me.TextBox位置专题添加.Clear()
        Me.TextBox震级专题添加.Clear()
        Me.TextBox纬度专题添加.Clear()
        Me.TextBox时间专题添加.Clear()
        Me.TextBox经度专题添加.Clear()
        Me.TextBox深度专题添加.Clear()
        Me.PictureBox7.Image = Nothing
        Me.TextBox1.Clear()
        Me.TextBox4.Clear()
        mydataset.Tables("专题删除").Clear()
        Me.ComboBox1.Items.Clear()
        Dim str9 As String = "select  distinct 专题名称 as x from information"
        Dim myad9 As New SqlDataAdapter(str9, myconn)
        myad9.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox1.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()
    End Sub

    Private Sub Button15_Click(sender As Object, e As EventArgs) Handles Button15.Click
        GroupBox7.Visible = True
        MsgBox("删除的数据将无法恢复")
        ProgressBar2.Minimum = 0
        ProgressBar2.Maximum = mydataset.Tables("查询1").Rows.Count
        ProgressBar2.Value = 0
        ReDim c(16000), b(16000), d(16000)
        Dim mycomm As New SqlCommand
        mycomm.Connection = myconn
        Dim str2 As String
        For i = 0 To mydataset.Tables("查询1").Rows.Count - 1
            c(i) = mydataset.Tables("查询1").Rows(i).Item("经度")
            b(i) = mydataset.Tables("查询1").Rows(i).Item("纬度")
            d(i) = mydataset.Tables("查询1").Rows(i).Item("震级")
        Next
        myconn.Open()
        For i = 0 To mydataset.Tables("查询1").Rows.Count - 1
            str2 = "delete from earthquake where 震级='" & d(i) & "' and 经度='" & c(i) & "' and 纬度='" & b(i) & "' "
            mycomm.CommandText = str2
            mycomm.CommandType = CommandType.Text
            mycomm.ExecuteNonQuery()
            ProgressBar2.Value = i
        Next
        myconn.Close()
        GroupBox7.Visible = False
        mydataset.Tables("查询1").Clear()
        MsgBox("已删除")
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        mybind.MovePrevious()
    End Sub

    Private Sub Button12_Click_2(sender As Object, e As EventArgs) Handles Button12.Click
        mybind.MoveNext()
    End Sub

    Private Sub Button17_Click(sender As Object, e As EventArgs) Handles Button17.Click
        If k = 99 Then
            OpenFileDialog1.Filter = "(*.bmp)|*bmp|(*.jpg)|*.jpg"
            OpenFileDialog1.FilterIndex = 2
            If Not Me.OpenFileDialog1.ShowDialog(Me) = vbOK Then
                Exit Sub
            End If
            Me.PictureBox6.ImageLocation = Me.OpenFileDialog1.FileName
        Else
            MsgBox("请先完成基本信息的添加")
        End If
    End Sub

    Private Sub Button34_Click(sender As Object, e As EventArgs) Handles Button34.Click
        If k = 14 Then
            Me.GroupBox5.Visible = True
            MsgBox("系统将自动筛选出与后台重复的数据，重复的以及错误数据将不会被导入后台数据库中")
            Static a%, s%, err%
            a = 0
            s = 0
            err = 0
            ProgressBar1.Minimum = 0
            ProgressBar1.Maximum = myoldataset.Tables(0).Rows.Count
            ProgressBar1.Value = 0
            ReDim c(16000), b(16000), d(16000), r(16000), f(16000), g(16000)
            Dim mycomm1, mycomm As New SqlCommand
            Dim myadapter As New SqlDataAdapter
            mycomm.Connection = myconn
            mycomm1.Connection = myconn
            Dim mysql1, str2 As String
            For i = 0 To myoldataset.Tables(0).Rows.Count - 1
                c(i) = Trim(Str(myoldataset.Tables(0).Rows(i).Item(3)))
                b(i) = Trim(Str(myoldataset.Tables(0).Rows(i).Item(2)))
                d(i) = Trim(Str(myoldataset.Tables(0).Rows(i).Item(1)))
                r(i) = Trim(Str(myoldataset.Tables(0).Rows(i).Item(4)))
                f(i) = Trim(myoldataset.Tables(0).Rows(i).Item(0))
                g(i) = Trim(myoldataset.Tables(0).Rows(i).Item(5))
            Next
            For i = 0 To myoldataset.Tables(0).Rows.Count - 1
                str2 = "select 震级 from earthquake where 震级=" & d(i) & " and 经度=" & c(i) & " and 纬度=" & b(i) & ""
                mycomm.CommandText = str2
                myadapter.SelectCommand = mycomm
                myadapter.Fill(mydataset, "筛选")
                If c(i) Is Nothing Or b(i) Is Nothing Or d(i) Is Nothing Or f(i) Is Nothing Or r(i) = "0" Then
                    err = err + 1
                ElseIf mydataset.Tables("筛选").Rows.Count = 0 Then
                    mysql1 = "insert into earthquake values('" & f(i) & "'," & d(i) & "," & b(i) & "," & c(i) & "," & r(i) & ",'" & g(i) & "')"
                    mycomm1.CommandText = mysql1
                    myconn.Open()
                    Try
                        mycomm1.ExecuteNonQuery()
                    Catch ex As Exception

                    End Try
                    myconn.Close()
                    a = a + 1
                End If
                If mydataset.Tables("筛选").Rows.Count <> 0 Then
                    s = s + 1
                    mydataset.Tables("筛选").Clear()
                End If
                ProgressBar1.Value = i
            Next
            myoldataset.Tables(0).Clear()
            Me.Label导入.Text = a
            Me.Label重复.Text = s
            Me.Labelerr.Text = err
            Me.GroupBox5.Visible = False
            MsgBox("导入完成")
        End If
    End Sub

    Private Sub TabPage16_Click(sender As Object, e As EventArgs) Handles TabPage16.Click

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        OpenFileDialog1.Filter = "(*.bmp)|*bmp|(*.jpg)|*.jpg"
        OpenFileDialog1.FilterIndex = 2
        If Not Me.OpenFileDialog1.ShowDialog(Me) = vbOK Then
            Exit Sub
        End If
        Me.PictureBox1.ImageLocation = Me.OpenFileDialog1.FileName
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        Me.PictureBox1.Image = Nothing
        Me.TextBox说明2.Text = ""
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        myconn.Close()
            Dim sqlcomm As New SqlCommand
        sqlcomm.CommandText = "INSERT INTO picture (科普标题,说明2,图片) VALUES (@科普标题,@说明2,@图片)"
        sqlcomm.Connection = myconn
        If OpenFileDialog1.FileName = Nothing Then
            MsgBox("请插入图片")
        Else
            fs = New FileStream(Me.OpenFileDialog1.FileName.ToString(), FileMode.Open, FileAccess.Read)
            Dim Data(fs.Length) As Byte
            fs.Read(Data, 0, Int(fs.Length))
            Dim prm1 As New SqlParameter("@科普标题", Me.TextBox5.Text)
            Dim prm3 As New SqlParameter("@说明2", Me.TextBox说明2.Text)
            Dim prm5 As New SqlParameter("@图片", SqlDbType.Image, Int(fs.Length), ParameterDirection.Input, False, 0, 0, "", DataRowVersion.Current, Data)
            sqlcomm.Parameters.Add(prm1)
            sqlcomm.Parameters.Add(prm3)
            sqlcomm.Parameters.Add(prm5)
            Dim s% = 0
            myconn.Open()
             Try
                s = sqlcomm.ExecuteNonQuery()
            Catch ex As Exception
                MsgBox(ex.Message)
            End Try
            If s >= 1 Then
                MsgBox("导入成功")
            End If
            myconn.Close()
            fs.Close()
        End If
        TextBox说明2.Clear()
        TextBox5.Clear()
        Me.PictureBox1.Image = Nothing
    End Sub

    Private Sub ComboBox删除科普标题_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox删除科普标题.SelectedIndexChanged
        PictureBox删除说明.Image = Nothing
        mydataset.Tables("删除科普").Clear()
        Dim mystr As String = "select * from picture where 科普标题='" & Me.ComboBox删除科普标题.Text & "'"
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        myadapter.Fill(mydataset, "删除科普")
        Label删除说明2.DataBindings.Clear()
        PictureBox删除说明.DataBindings.Clear()
        mybind2.DataSource = mydataset
        mybind2.DataMember = "删除科普"
        Label删除说明2.DataBindings.Add(New Binding("text", mybind2, "说明2", True))
        PictureBox删除说明.DataBindings.Add(New Binding("image", mybind2, "图片", True))

    End Sub

    Private Sub Button18_Click(sender As Object, e As EventArgs) Handles Button18.Click
        myconn.Close()
        Dim str3 As String = "delete from picture where 科普标题='" & Me.ComboBox删除科普标题.Text & "'"
        Dim mycomm3 As New SqlCommand(str3, myconn)
        mycomm3.CommandType = CommandType.Text
        myconn.Open()
        mycomm3.ExecuteNonQuery()
        myconn.Close()
        MsgBox("已删除")
        Me.TextBox时间专题添加.Clear()
        Me.TextBox经度专题添加.Clear()
        Me.TextBox深度专题添加.Clear()
        Me.PictureBox7.Image = Nothing
        Me.TextBox1.Clear()
        Me.TextBox4.Clear()
        mydataset.Tables("删除科普").Clear()
        Me.ComboBox删除科普标题.Items.Clear()
        Dim str9 As String = "select  distinct 科普标题 as x from picture"
        Dim myad9 As New SqlDataAdapter(str9, myconn)
        myad9.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox删除科普标题.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()
    End Sub

    Private Sub TabPage4_Click(sender As Object, e As EventArgs) Handles TabPage4.Click

    End Sub

    Private Sub TabPage12_Click(sender As Object, e As EventArgs) Handles TabPage12.Click

    End Sub

    Private Sub TabPage12_Enter(sender As Object, e As EventArgs) Handles TabPage12.Enter
        Me.ComboBox删除科普标题.Items.Clear()
        Dim str2 As String = "select  distinct 科普标题 as x from picture"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox删除科普标题.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()
    End Sub

    Private Sub Button19_Click(sender As Object, e As EventArgs) Handles Button19.Click
        Me.ComboBox专题添加.Visible = True
        Me.TextBox专题名称.Visible = False
        k = 99
    End Sub

    Private Sub Button20_Click(sender As Object, e As EventArgs) Handles Button20.Click
        Me.ComboBox专题添加.Visible = False
        Me.TextBox专题名称.Visible = True
        Me.TextBox位置专题添加.Clear()
        Me.TextBox震级专题添加.Clear()
        Me.TextBox纬度专题添加.Clear()
        Me.TextBox时间专题添加.Clear()
        Me.TextBox经度专题添加.Clear()
        Me.TextBox深度专题添加.Clear()
        Me.TextBox2.Clear()
        Me.TextBox3.Clear()
        k = 98
        Me.Label提示.Text = "提示：要先完成基本信息的添加才能添加图片；基本信息一经添加，就不能单独删除，添加前请确认信息正确！在专题添加过程中请勿更改标题，否则系统将默认您已完成当前专题的添加！"
    End Sub

    Private Sub ComboBox专题添加_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox专题添加.SelectedIndexChanged
        Me.TextBox位置专题添加.Clear()
        Me.TextBox震级专题添加.Clear()
        Me.TextBox纬度专题添加.Clear()
        Me.TextBox时间专题添加.Clear()
        Me.TextBox经度专题添加.Clear()
        Me.TextBox深度专题添加.Clear()
        Me.TextBox2.Clear()
        Me.TextBox3.Clear()
        Dim str2 As String = "select  * from information where information.专题名称='" & Me.ComboBox专题添加.Text & "'"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        If mydataset.Tables("t1").Rows.Count = 0 Then
            Me.Label提示.Text = "后台无此专题的基本信息"
        Else
            Me.TextBox经度专题添加.Text = mydataset.Tables("t1").Rows(0).Item("经度")
            Me.TextBox深度专题添加.Text = mydataset.Tables("t1").Rows(0).Item("震源深度")
            Me.TextBox时间专题添加.Text = mydataset.Tables("t1").Rows(0).Item("时间")
            Me.TextBox纬度专题添加.Text = mydataset.Tables("t1").Rows(0).Item("纬度")
            Me.TextBox位置专题添加.Text = mydataset.Tables("t1").Rows(0).Item("区域位置")
            Me.TextBox震级专题添加.Text = mydataset.Tables("t1").Rows(0).Item("震级")
            Me.Label提示.Text = "后台已有此专题的基本信息"
            k = 99
        End If
        mydataset.Tables("t1").Clear()
    End Sub
    Private Sub TabPage3_Enter(sender As Object, e As EventArgs) Handles TabPage3.Enter
        Me.ComboBox专题添加.Items.Clear()
        Dim str2 As String = "select  distinct 专题名称 as x from information"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox专题添加.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()

    End Sub

    Private Sub Button21_Click(sender As Object, e As EventArgs) Handles Button21.Click
        myconn.Close()
        Dim str3 As String = "delete from photo where photo.专题名称='" & Me.ComboBox1.Text & "' and 照片标题='" & Me.TextBox1.Text & "'"
        Dim mycomm3 As New SqlCommand(str3, myconn)
        mycomm3.CommandType = CommandType.Text
        myconn.Open()
        mycomm3.ExecuteNonQuery()
        myconn.Close()
        Me.PictureBox7.Image = Nothing
        Me.TextBox1.Clear()
        Me.TextBox4.Clear()
        MsgBox("已删除")
    End Sub

    Private Sub TabPage3_Click(sender As Object, e As EventArgs) Handles TabPage3.Click

    End Sub
End Class