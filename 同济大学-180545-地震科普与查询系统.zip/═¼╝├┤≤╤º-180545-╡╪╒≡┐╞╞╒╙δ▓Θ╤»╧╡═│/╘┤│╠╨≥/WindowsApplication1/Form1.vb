﻿Imports System.Data.SqlClient
Imports System.Math
Imports System.Drawing.Drawing2D
Imports System.IO
Imports System.Data.OleDb
Public Class Form1
    Dim myconn As New SqlConnection("initial catalog=china earthquake;data source=10.10.109.119;user id=tj5;password=db18-5")
    Dim mydataset As New DataSet
    Dim mybind As New BindingSource
    Dim c(16000), b(16000), d(16000) As Single
    Function JC(n As Long)
        If n > 0 Then
            JC = n * JC(n - 1)
        Else
            JC = 1
        End If

    End Function

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Form5.Close()
        Form5.Show()
        k = 4
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        Me.ComboBox城市风险年份.Items.Clear()
        Me.ComboBox时间查询上限.Items.Clear()
        Me.ComboBox时间查询下限.Items.Clear()
        Me.TextBox城市经度查询.Text = 0
        Me.TextBox城市纬度查询.Text = 0
        Dim str1 As String = "select * from earthquake"
        Dim myad1 As New SqlDataAdapter(str1, myconn)
        myad1.Fill(mydataset, "t1")
        If mydataset.Tables("t1").Rows.Count < 2 Then
            MsgBox("后台无数据，此功能无法使用")
            k = 13
            Me.Close()
        Else
            myad1.Fill(mydataset, "所有数据")
            myad1.Fill(mydataset, "查询")
            myad1.Fill(mydataset, "城市")
            mydataset.Tables("查询").Clear()
            mydataset.Tables("城市").Clear()
            Me.DataGridView4.DataSource = mydataset.Tables("所有数据")
            Me.TextBox数据总量.Text = mydataset.Tables("t1").Rows.Count
            mydataset.Tables("t1").Clear()
            Dim str2 As String = "select min(时间) as Q,max(时间) as W,min(经度) as E,max(经度) as R,min(纬度) as T,max(纬度) as Y from earthquake"
            Dim myad2 As New SqlDataAdapter(str2, myconn)
            myad2.Fill(mydataset, "t2")
            Me.TextBox时间跨度下限.Text = mydataset.Tables("t2").Rows(0).Item("Q")
            Me.TextBox时间跨度上限.Text = mydataset.Tables("t2").Rows(0).Item("W")
            Me.TextBox经度跨度下限.Text = mydataset.Tables("t2").Rows(0).Item("E")
            Me.TextBox经度跨度上限.Text = mydataset.Tables("t2").Rows(0).Item("R")
            Me.TextBox纬度跨度下限.Text = mydataset.Tables("t2").Rows(0).Item("T")
            Me.TextBox纬度跨度上限.Text = mydataset.Tables("t2").Rows(0).Item("Y")
            mydataset.Tables("t2").Clear()
            Dim str3 As String = "select * from earthquake where 震级<4"
            Dim myad3 As New SqlDataAdapter(str3, myconn)
            myad3.Fill(mydataset, "t1")
            Me.TextBox小于四级数量.Text = mydataset.Tables("t1").Rows.Count
            mydataset.Tables("t1").Clear()
            Dim str4 As String = "select * from earthquake where 震级>=4 and 震级<=6"
            Dim myad4 As New SqlDataAdapter(str4, myconn)
            myad4.Fill(mydataset, "t1")
            Me.TextBox四到六数量.Text = mydataset.Tables("t1").Rows.Count
            mydataset.Tables("t1").Clear()
            Dim str5 As String = "select * from earthquake where 震级>6"
            Dim myad5 As New SqlDataAdapter(str5, myconn)
            myad5.Fill(mydataset, "t1")
            Me.TextBox大于六数量.Text = mydataset.Tables("t1").Rows.Count
            mydataset.Tables("t1").Clear()
            Me.TextBox大于六比重.Text = Round((TextBox大于六数量.Text / TextBox数据总量.Text), 4)
            Me.TextBox四到六比重.Text = Round((TextBox四到六数量.Text / TextBox数据总量.Text), 4)
            Me.TextBox小于四级百分比.Text = Round((TextBox小于四级数量.Text / TextBox数据总量.Text), 4)
            Dim str6 As String = "select distinct left(ltrim(时间),7) as x from earthquake order by x asc"
            Dim myad6 As New SqlDataAdapter(str6, myconn)
            myad6.Fill(mydataset, "t1")
            For i = 0 To mydataset.Tables("t1").Rows.Count - 1
                Me.ComboBox时间查询上限.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
                Me.ComboBox时间查询下限.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
            Next
            mydataset.Tables("t1").Clear()
            Dim str7 As String = "select rtrim(城市名称) as x from city order by x asc"
            Dim myad7 As New SqlDataAdapter(str7, myconn)
            myad7.Fill(mydataset, "t1")
            For i = 0 To mydataset.Tables("t1").Rows.Count - 1
                Me.ComboBox城市查询.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
            Next
            mydataset.Tables("t1").Clear()
            If Me.ComboBox时间查询下限.Text = "" Then
                ComboBox时间查询下限.Text = Me.TextBox时间跨度下限.Text
            End If
            If Me.ComboBox时间查询上限.Text = "" Then
                ComboBox时间查询上限.Text = Me.TextBox时间跨度上限.Text
            End If
            If Me.TextBox纬度查询下限.Text = "" Then
                Me.TextBox纬度查询下限.Text = Me.TextBox纬度跨度下限.Text
            End If
            If Me.TextBox纬度查询上限.Text = "" Then
                Me.TextBox纬度查询上限.Text = Me.TextBox纬度跨度上限.Text
            End If
            If Me.TextBox经度查询下限.Text = "" Then
                Me.TextBox经度查询下限.Text = Me.TextBox经度跨度下限.Text
            End If
            If Me.TextBox经度查询上限.Text = "" Then
                Me.TextBox经度查询上限.Text = Me.TextBox经度跨度上限.Text
            End If
            If Me.TextBox震级查询下限.Text = "" Then
                Me.TextBox震级查询下限.Text = 0
            End If
            If Me.TextBox震级查询上限.Text = "" Then
                Me.TextBox震级查询上限.Text = 10
            End If
            Dim str8 As String = "select distinct left(ltrim(时间),4) as x from earthquake order by x asc"
            Dim myad8 As New SqlDataAdapter(str8, myconn)
            myad8.Fill(mydataset, "t1")
            If mydataset.Tables("t1").Rows.Count >= 3 Then
                For i = 1 To mydataset.Tables("t1").Rows.Count - 2
                    Me.ComboBox城市风险年份.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
                Next
            Else
                MsgBox("后台数据库中没有足够的数据，因而城市风险评估功能可能无法使用")
            End If
            mydataset.Tables("t1").Clear()
        End If
    End Sub





    Private Sub ComboBox城市查询_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox城市查询.SelectedIndexChanged
        Dim str7 As String = "select * from city where 城市名称 = '" & Me.ComboBox城市查询.Text & "'"
        Dim myad7 As New SqlDataAdapter(str7, myconn)
        myad7.Fill(mydataset, "t1")
        Me.TextBox城市纬度查询.Text = mydataset.Tables("t1").Rows(0).Item("纬度")
        Me.TextBox城市经度查询.Text = mydataset.Tables("t1").Rows(0).Item("经度")
        mydataset.Tables("t1").Clear()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form3.Close()
        Form3.Show()
        k = 1
        Form3.Button1.PerformClick()
    End Sub



    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        If Me.ComboBox时间查询下限.Text = "" Then
            ComboBox时间查询下限.Text = Me.TextBox时间跨度下限.Text
        End If
        If Me.ComboBox时间查询上限.Text = "" Then
            ComboBox时间查询上限.Text = Me.TextBox时间跨度上限.Text
        End If
        If Me.TextBox纬度查询下限.Text = "" Then
            Me.TextBox纬度查询下限.Text = Me.TextBox纬度跨度下限.Text
        End If
        If Me.TextBox纬度查询上限.Text = "" Then
            Me.TextBox纬度查询上限.Text = Me.TextBox纬度跨度上限.Text
        End If
        If Me.TextBox经度查询下限.Text = "" Then
            Me.TextBox经度查询下限.Text = Me.TextBox经度跨度下限.Text
        End If
        If Me.TextBox经度查询上限.Text = "" Then
            Me.TextBox经度查询上限.Text = Me.TextBox经度跨度上限.Text
        End If
        If Me.TextBox震级查询下限.Text = "" Then
            Me.TextBox震级查询下限.Text = 0
        End If
        If Me.TextBox震级查询上限.Text = "" Then
            Me.TextBox震级查询上限.Text = 10
        End If
        mydataset.Tables("查询").Clear()
            Dim str3 As String = "select * from earthquake where 时间>='" & ComboBox时间查询下限.Text & "' and 时间<='" & ComboBox时间查询上限.Text & "' and 纬度>=" & TextBox纬度查询下限.Text & " and 纬度<=" & TextBox纬度查询上限.Text & " and 经度>=" & TextBox经度查询下限.Text & "and 经度<=" & TextBox经度查询上限.Text & " and 震级>=" & TextBox震级查询下限.Text & " and 震级<=" & TextBox震级查询上限.Text & ""
            Dim myad3 As New SqlDataAdapter(str3, myconn)
            myad3.Fill(mydataset, "查询")
            DataGridView1.DataSource = mydataset.Tables("查询")
            Label20.Text = mydataset.Tables("查询").Rows.Count
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form3.Close()
        Form3.Show()
        k = 2
        Form3.Button1.PerformClick()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Dim g As Graphics = PictureBox1.CreateGraphics()
        Dim myrec As Rectangle = New Rectangle(25, 15, 280, 280)
        Dim b() As Brush = {New SolidBrush(Color.Blue), New SolidBrush(Color.Orange), New SolidBrush(Color.Red)}
        Dim ang(3), startang As Single
        ang(0) = Me.TextBox小于四级百分比.Text * 100 * 3.6
        ang(1) = Me.TextBox四到六比重.Text * 100 * 3.6
        ang(2) = Me.TextBox大于六比重.Text * 100 * 3.6
        startang = 0
        g.Clear(PictureBox1.BackColor)
        For i = 0 To 2
            g.FillPie(b(i), myrec, startang, -ang(i))
            startang = startang - ang(i)
        Next
        Me.Timer2.Stop()
    End Sub

    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        Dim str2 As String = "select sum(case when 震级<3 then 1 else 0 end) as Q,sum(case when 震级<4 and 震级>=3 then 1 else 0 end) as W,sum(case when 震级<5 and 震级>=4 then 1 else 0 end) as E,sum(case when 震级<6 and 震级>=5 then 1 else 0 end) as R,sum(case when 震级<7 and 震级>=6 then 1 else 0 end) as T,sum(case when 震级>=7 then 1 else 0 end) as Y from earthquake"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t2")
        Dim g1 As Graphics = PictureBox2.CreateGraphics()
        Dim p1 As Pen = New Pen(Color.Gray)
        Dim p2 As Pen = New Pen(Color.Black, 1)
        Dim b1 As Brush = New SolidBrush(Color.OrangeRed)
        Dim bb As New SolidBrush(Color.White)
        g1.TranslateTransform(60, -15)
        g1.Clear(PictureBox2.BackColor)
        g1.FillRectangle(bb, 0, 0, 450, 305)
        Dim dw% = 50, dg% = 20
        For i = 0 To 5
            g1.DrawLine(p1, 0, 50 * i, 450, 50 * i)
        Next
        Dim d% = Me.TextBox数据总量.Text
        Dim s(6) As Single
            s(0) = (mydataset.Tables("t2").Rows(0).Item("Q") / d) * 300
            s(1) = (mydataset.Tables("t2").Rows(0).Item("W") / d) * 300
            s(2) = (mydataset.Tables("t2").Rows(0).Item("E") / d) * 300
            s(3) = (mydataset.Tables("t2").Rows(0).Item("R") / d) * 300
            s(4) = (mydataset.Tables("t2").Rows(0).Item("T") / d) * 300
            s(5) = (mydataset.Tables("t2").Rows(0).Item("Y") / d) * 600
            g1.FillRectangle(b1, dg, 300 - s(0), dw, s(0))
            g1.FillRectangle(b1, dg * 2 + dw, 300 - s(1), dw, s(1))
            g1.FillRectangle(b1, dg * 3 + dw * 2, 300 - s(2), dw, s(2))
            g1.FillRectangle(b1, dg * 4 + dw * 3, 300 - s(3), dw, s(3))
            g1.FillRectangle(b1, dg * 5 + dw * 4, 300 - s(4), dw, s(4))
            g1.FillRectangle(b1, dg * 6 + dw * 5, 300 - s(5), dw, s(5))
            p2.SetLineCap(LineCap.Flat, LineCap.ArrowAnchor, DashCap.Flat)
            g1.DrawLine(p2, 0, 300, 453, 300)
        g1.DrawLine(p2, 0, 300, 0, 40)
        For i = 1 To 5
            g1.DrawLine(p1, dg * i + dw * i + 10, 300, dg * i + dw * i + 10, 305)
        Next
        Me.Labelq.Text = mydataset.Tables("t2").Rows(0).Item("Q") & "次"
        Me.Labelw.Text = mydataset.Tables("t2").Rows(0).Item("W") & "次"
        Me.Labele.Text = mydataset.Tables("t2").Rows(0).Item("E") & "次"
        Me.Labelr.Text = mydataset.Tables("t2").Rows(0).Item("R") & "次"
        Me.Labelt.Text = mydataset.Tables("t2").Rows(0).Item("T") & "次"
        Me.Labely.Text = mydataset.Tables("t2").Rows(0).Item("Y") & "次"
        Timer3.Stop()
    End Sub
    Private Sub TabPage1_Enter(sender As Object, e As EventArgs) Handles TabPage1.Enter
        Me.Timer2.Start()
        Me.Timer3.Start()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim a%, b%, c%, d%
        Dim score As Long
        Me.TextBox风险指数.Text = "(级数越高，地震影响越大）" & vbCrLf
        Dim l1(16000), l2(16000), mag(16000) As Double
        mydataset.Tables("城市").Clear()
        Dim str1 As String = "select * from earthquake where 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' and left(ltrim(时间),4)='" & Me.ComboBox城市风险年份.Text & "'"
        Dim myad1 As New SqlDataAdapter(str1, myconn)
        myad1.Fill(mydataset, "城市")
        Me.TextBox城市风险地震数.Text = mydataset.Tables("城市").Rows.Count
        Me.DataGridView5.DataSource = mydataset.Tables("城市")
        For i = 0 To mydataset.Tables("城市").Rows.Count - 1
            l1(i) = Abs(mydataset.Tables("城市").Rows(i).Item("经度") - Me.TextBox城市经度查询.Text)
            l2(i) = Abs(mydataset.Tables("城市").Rows(i).Item("纬度") - Me.TextBox城市纬度查询.Text)
            mag(i) = mydataset.Tables("城市").Rows(i).Item("震级")
        Next
        For i = 0 To mydataset.Tables("城市").Rows.Count - 1
            score = score + Exp((mag(i) - 1.5) / 0.58 - Pow(l1(i) * l1(i) + l2(i) * l2(i), 0.5))
        Next
        Me.TextBox风险指数.Text = Me.TextBox风险指数.Text & score & "分" & vbCrLf & Int(Log10(score + 10)) & "级" & vbCrLf
        If Int(Log10(score + 10)) = 1 Then
            Me.TextBox风险指数.Text = Me.TextBox风险指数.Text & "该地受地震影响很小"
        ElseIf Int(Log10(score + 10)) = 2 Then
            Me.TextBox风险指数.Text = Me.TextBox风险指数.Text & "地震对该地有一定影响"
        ElseIf Int(Log10(score + 10)) = 3 Then
            Me.TextBox风险指数.Text = Me.TextBox风险指数.Text & "地震对该地有较大影响"
        ElseIf Int(Log10(score + 10)) > 3 Then
            Me.TextBox风险指数.Text = Me.TextBox风险指数.Text & "该地受地震影响很大"
        End If
        Dim str3 As String = "select * from earthquake where 震级<4 and 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' and left(ltrim(时间),4)='" & Me.ComboBox城市风险年份.Text & "'"
        Dim myad3 As New SqlDataAdapter(str3, myconn)
        myad3.Fill(mydataset, "t1")
        Me.TextBox城市风险小于四.Text = mydataset.Tables("t1").Rows.Count
        a = mydataset.Tables("t1").Rows.Count
        mydataset.Tables("t1").Clear()
        Dim str4 As String = "select * from earthquake where 震级>=4 and 震级<=6 and 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' and left(ltrim(时间),4)='" & Me.ComboBox城市风险年份.Text & "'"
        Dim myad4 As New SqlDataAdapter(str4, myconn)
        myad4.Fill(mydataset, "t1")
        Me.TextBox城市风险四到六.Text = mydataset.Tables("t1").Rows.Count
        b = mydataset.Tables("t1").Rows.Count
        mydataset.Tables("t1").Clear()
        Dim str5 As String = "select * from earthquake where 震级>6 and 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' and left(ltrim(时间),4)='" & Me.ComboBox城市风险年份.Text & "'"
        Dim myad5 As New SqlDataAdapter(str5, myconn)
        myad5.Fill(mydataset, "t1")
        Me.TextBox城市风险大于六.Text = mydataset.Tables("t1").Rows.Count
        c = mydataset.Tables("t1").Rows.Count
        mydataset.Tables("t1").Clear()
        d = Me.TextBox城市风险地震数.Text
        Me.TextBox城市小于4级概率.Text = Round((Pow(a, Me.DomainUpDown1.Text) * Exp(-a) / JC(Me.DomainUpDown1.Text)) * 100, 4) & "%"
        Me.TextBox城市4到6级概率.Text = Round((Pow(b, Me.DomainUpDown2.Text) * Exp(-b) / JC(Me.DomainUpDown2.Text)) * 100, 4) & "%"
        Me.TextBox城市大于6级概率.Text = Round((Pow(c, Me.DomainUpDown3.Text) * Exp(-c) / JC(Me.DomainUpDown3.Text)) * 100, 4) & "%"
        Dim g1 As Graphics = PictureBox4.CreateGraphics()
        Dim p1 As Pen = New Pen(Color.Gray)
        Dim p2 As Pen = New Pen(Color.Black, 3)
        Dim b1 As Brush = New SolidBrush(Color.Blue)
        Dim b2 As Brush = New SolidBrush(Color.Orange)
        Dim b3 As Brush = New SolidBrush(Color.Red)
        Dim pb1 As Pen = New Pen(Color.Blue, 2)
        Dim pb2 As Pen = New Pen(Color.Orange, 2)
        Dim pb3 As Pen = New Pen(Color.Red, 2)
        Dim bb As New SolidBrush(Color.White)
        g1.TranslateTransform(60, 20)
        g1.FillRectangle(bb, 0, 0, 800, 255)
        Dim dw% = 6, dg% = 14
        For i = 0 To 4
            g1.DrawLine(p1, 0, 50 * i, 800, 50 * i)
        Next
        Dim s1(80), s2(80), s3(80) As Single
        For i = 0 To 39
            s1(i) = Round((Pow(a, i + 1) * Exp(-a) / JC(i + 1)) * 100, 4) * 5
        Next
        For i = 0 To 39
            s2(i) = Round((Pow(b, i + 1) * Exp(-b) / JC(i + 1)) * 100, 4) * 5
        Next
        For i = 0 To 39
            s3(i) = Round((Pow(c, i + 1) * Exp(-c) / JC(i + 1)) * 100, 4) * 5
        Next
        For i = 0 To 39
            g1.FillRectangle(b1, dg * (i + 1) + dw * i, 240 - s1(i), dw, 6)
        Next
        For i = 0 To 39
            g1.FillRectangle(b2, dg * (i + 1) + dw * i, 240 - s2(i), dw, 6)
        Next
        For i = 0 To 39
            g1.FillRectangle(b3, dg * (i + 1) + dw * i, 240 - s3(i), dw, 6)
        Next
        p2.SetLineCap(LineCap.Flat, LineCap.ArrowAnchor, DashCap.Flat)
        g1.DrawLine(p2, 0, 250, 810, 250)
        g1.DrawLine(p2, 0, 250, 0, -10)
        For i = 0 To 38
            g1.DrawLine(pb1, dg * (i + 1) + dw * i + 1, 240 - s1(i) + 3, dg * (i + 2) + dw * (i + 1) + 3, 240 - s1(i + 1) + 1)
            g1.DrawLine(pb2, dg * (i + 1) + dw * i + 3, 240 - s2(i) + 3, dg * (i + 2) + dw * (i + 1) + 3, 240 - s2(i + 1) + 3)
            g1.DrawLine(pb3, dg * (i + 1) + dw * i + 4, 240 - s3(i) + 3, dg * (i + 2) + dw * (i + 1) + 3, 240 - s3(i + 1) + 4)
        Next
        For i = 0 To 39
            g1.DrawLine(p1, dg * (i + 1) + dw * i, 250, dg * (i + 1) + dw * i, 255)
        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Form3.Close()
        Form3.Show()
        k = 5
        Form3.Button1.PerformClick()
    End Sub

    Private Sub Button6_Click_1(sender As Object, e As EventArgs) Handles Button6.Click
        Form3.Close()
        Form3.Show()
        k = 7
        Form3.Button1.PerformClick()
    End Sub

    Private Sub Button7_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim s(10) As String
        Dim s0(10), s2(10), s3(10) As Integer
        Static s1%, s4%
        s1 = 0
        s4 = 0
        For i = 1 To Me.ComboBox城市风险年份.Items.Count
            If Me.ComboBox城市风险年份.Items.Count <= 10 Then
                s(Me.ComboBox城市风险年份.Items.Count - i) = Me.ComboBox城市风险年份.Items(Me.ComboBox城市风险年份.Items.Count - i)
                s1 = i
            Else
                If i <= 10 Then
                    s(10 - i) = Me.ComboBox城市风险年份.Items(Me.ComboBox城市风险年份.Items.Count - i)
                    s1 = 10
                End If
            End If
        Next

        Dim mycomm As New SqlCommand
        Dim myadapter As New SqlDataAdapter
        mycomm.Connection = myconn
        Dim str1 As String
        For i = 0 To s1 - 1
            str1 = "select count(时间) as '0' from earthquake where 震级<4 and left(ltrim(时间),4)='" & s(i) & "' and 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' "
            mycomm.CommandText = str1
            myadapter.SelectCommand = mycomm
            myadapter.Fill(mydataset, "筛选")
            s0(i) = mydataset.Tables("筛选").Rows(0).Item("0")
            If s4 < s0(i) Then
                s4 = s0(i)
            End If
            mydataset.Tables("筛选").Clear()
        Next
        For i = 0 To s1 - 1
            str1 = "select count(时间) as '2' from earthquake where 震级>=4 and 震级<6 and left(ltrim(时间),4)='" & s(i) & "' and 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' "
            mycomm.CommandText = str1
            myadapter.SelectCommand = mycomm
            myadapter.Fill(mydataset, "筛选")
            s2(i) = mydataset.Tables("筛选").Rows(0).Item("2")
            If s4 < s2(i) Then
                s4 = s2(i)
            End If
            mydataset.Tables("筛选").Clear()
        Next
        For i = 0 To s1 - 1
            str1 = "select count(时间) as '3' from earthquake where 震级>=6 and left(ltrim(时间),4)='" & s(i) & "' and 纬度>='" & TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & TextBox城市经度查询.Text + 1.5 & "' "
            mycomm.CommandText = str1
            myadapter.SelectCommand = mycomm
            myadapter.Fill(mydataset, "筛选")
            s3(i) = mydataset.Tables("筛选").Rows(0).Item("3")
            If s4 < s3(i) Then
                s4 = s3(i)
            End If
            mydataset.Tables("筛选").Clear()
        Next
        If s4 = 0 Then
            s4 = 1
        End If
        For i = 0 To s1 - 1
            s0(i) = Int((s0(i) / s4) * 250)
            s2(i) = Int((s2(i) / s4) * 250)
            s3(i) = Int((s3(i) / s4) * 250)
        Next
        mydataset.Tables("筛选").Clear()
        Dim g1 As Graphics = PictureBox3.CreateGraphics()
        Dim p1 As Pen = New Pen(Color.Gray)
        Dim p2 As Pen = New Pen(Color.Black, 3)
        Dim b1 As Brush = New SolidBrush(Color.Blue)
        Dim b2 As Brush = New SolidBrush(Color.Orange)
        Dim b3 As Brush = New SolidBrush(Color.Red)
        Dim pb1 As Pen = New Pen(Color.Blue, 2)
        Dim pb2 As Pen = New Pen(Color.Orange, 2)
        Dim pb3 As Pen = New Pen(Color.Red, 2)
        Dim bb As New SolidBrush(Color.White)
        g1.TranslateTransform(60, 20)
        g1.FillRectangle(bb, 0, 0, 810, 255)
        Dim dw% = 6, dg% = 800 / s1 - 6, h% = dg - 10
        For i = 0 To 4
            g1.DrawLine(p1, 0, 50 * i, 810, 50 * i)
        Next
        For i = 0 To s1 - 1
            g1.FillRectangle(b1, dg * (i + 1) + dw * i - h, 245 - s0(i), dw, 6)
        Next
        For i = 0 To s1 - 1
            g1.FillRectangle(b2, dg * (i + 1) + dw * i - h, 245 - s2(i), dw, 6)
        Next
        For i = 0 To s1 - 1
            g1.FillRectangle(b3, dg * (i + 1) + dw * i - h, 245 - s3(i), dw, 6)
        Next
        p2.SetLineCap(LineCap.Flat, LineCap.ArrowAnchor, DashCap.Flat)
        g1.DrawLine(p2, 0, 250, 820, 250)
        g1.DrawLine(p2, 0, 250, 0, -10)
        For i = 0 To s1 - 2
            g1.DrawLine(pb1, dg * (i + 1) + dw * i + 3 - h, 245 - s0(i) + 3, dg * (i + 2) + dw * (i + 1) - h + 3, 245 - s0(i + 1) + 3)
            g1.DrawLine(pb2, dg * (i + 1) + dw * i + 3 - h, 245 - s2(i) + 3, dg * (i + 2) + dw * (i + 1) - h + 3, 245 - s2(i + 1) + 3)
            g1.DrawLine(pb3, dg * (i + 1) + dw * i + 3 - h, 245 - s3(i) + 3, dg * (i + 2) + dw * (i + 1) - h + 3, 245 - s3(i + 1) + 3)
        Next
        For i = 0 To s1 - 1
            g1.DrawLine(p1, dg * (i + 1) + dw * i - h, 250, dg * (i + 1) + dw * i, 255)
        Next
        Me.Label86.Text = Int(s4 * 0.8)
        Me.Label87.Text = Int(s4 * 0.6)
        Me.Label88.Text = Int(s4 * 0.4)
        Me.Label89.Text = Int(s4 * 0.2)
        Me.Label92.Text = s4
        Me.Label93.Text = s(0)
        Me.Label94.Text = s(s1 - 1)
    End Sub
End Class
