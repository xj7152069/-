﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TextBox纬度跨度下限 = New System.Windows.Forms.TextBox()
        Me.TextBox经度跨度下限 = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TextBox时间跨度上限 = New System.Windows.Forms.TextBox()
        Me.TextBox纬度跨度上限 = New System.Windows.Forms.TextBox()
        Me.TextBox经度跨度上限 = New System.Windows.Forms.TextBox()
        Me.TextBox时间跨度下限 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox数据总量 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Button1.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Button1.Location = New System.Drawing.Point(12, 350)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 52)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "地震记录查询系统"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Button2.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Button2.Location = New System.Drawing.Point(12, 494)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 52)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "管理员系统"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Location = New System.Drawing.Point(12, 32)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(789, 141)
        Me.TabControl1.TabIndex = 4
        Me.TabControl1.Visible = False
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.Controls.Add(Me.Label53)
        Me.TabPage1.Controls.Add(Me.Label52)
        Me.TabPage1.Controls.Add(Me.TextBox纬度跨度下限)
        Me.TabPage1.Controls.Add(Me.TextBox经度跨度下限)
        Me.TabPage1.Controls.Add(Me.Label51)
        Me.TabPage1.Controls.Add(Me.TextBox时间跨度上限)
        Me.TabPage1.Controls.Add(Me.TextBox纬度跨度上限)
        Me.TabPage1.Controls.Add(Me.TextBox经度跨度上限)
        Me.TabPage1.Controls.Add(Me.TextBox时间跨度下限)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.TextBox数据总量)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(781, 115)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "后台数据预览"
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(422, 34)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(17, 12)
        Me.Label53.TabIndex = 35
        Me.Label53.Text = "到"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(569, 73)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(17, 12)
        Me.Label52.TabIndex = 34
        Me.Label52.Text = "到"
        '
        'TextBox纬度跨度下限
        '
        Me.TextBox纬度跨度下限.Location = New System.Drawing.Point(450, 70)
        Me.TextBox纬度跨度下限.Name = "TextBox纬度跨度下限"
        Me.TextBox纬度跨度下限.ReadOnly = True
        Me.TextBox纬度跨度下限.Size = New System.Drawing.Size(113, 21)
        Me.TextBox纬度跨度下限.TabIndex = 33
        '
        'TextBox经度跨度下限
        '
        Me.TextBox经度跨度下限.Location = New System.Drawing.Point(99, 70)
        Me.TextBox经度跨度下限.Name = "TextBox经度跨度下限"
        Me.TextBox经度跨度下限.ReadOnly = True
        Me.TextBox经度跨度下限.Size = New System.Drawing.Size(88, 21)
        Me.TextBox经度跨度下限.TabIndex = 32
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(193, 73)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(17, 12)
        Me.Label51.TabIndex = 31
        Me.Label51.Text = "到"
        '
        'TextBox时间跨度上限
        '
        Me.TextBox时间跨度上限.Location = New System.Drawing.Point(450, 31)
        Me.TextBox时间跨度上限.Name = "TextBox时间跨度上限"
        Me.TextBox时间跨度上限.ReadOnly = True
        Me.TextBox时间跨度上限.Size = New System.Drawing.Size(315, 21)
        Me.TextBox时间跨度上限.TabIndex = 30
        '
        'TextBox纬度跨度上限
        '
        Me.TextBox纬度跨度上限.Location = New System.Drawing.Point(597, 70)
        Me.TextBox纬度跨度上限.Name = "TextBox纬度跨度上限"
        Me.TextBox纬度跨度上限.ReadOnly = True
        Me.TextBox纬度跨度上限.Size = New System.Drawing.Size(168, 21)
        Me.TextBox纬度跨度上限.TabIndex = 7
        '
        'TextBox经度跨度上限
        '
        Me.TextBox经度跨度上限.Location = New System.Drawing.Point(221, 70)
        Me.TextBox经度跨度上限.Name = "TextBox经度跨度上限"
        Me.TextBox经度跨度上限.ReadOnly = True
        Me.TextBox经度跨度上限.Size = New System.Drawing.Size(134, 21)
        Me.TextBox经度跨度上限.TabIndex = 6
        '
        'TextBox时间跨度下限
        '
        Me.TextBox时间跨度下限.Location = New System.Drawing.Point(450, 6)
        Me.TextBox时间跨度下限.Name = "TextBox时间跨度下限"
        Me.TextBox时间跨度下限.ReadOnly = True
        Me.TextBox时间跨度下限.Size = New System.Drawing.Size(315, 21)
        Me.TextBox时间跨度下限.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(377, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 12)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "纬度范围："
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 12)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "经度范围："
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(377, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "时间范围："
        '
        'TextBox数据总量
        '
        Me.TextBox数据总量.Location = New System.Drawing.Point(99, 27)
        Me.TextBox数据总量.Name = "TextBox数据总量"
        Me.TextBox数据总量.ReadOnly = True
        Me.TextBox数据总量.Size = New System.Drawing.Size(256, 21)
        Me.TextBox数据总量.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "数据总量："
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.TextBox1)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Location = New System.Drawing.Point(270, 240)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(270, 126)
        Me.GroupBox1.TabIndex = 5
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "管理员登录"
        Me.GroupBox1.Visible = False
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(154, 78)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 32)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "取消"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(109, 35)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(155, 21)
        Me.TextBox1.TabIndex = 2
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(41, 78)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 32)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "登录"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 38)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 12)
        Me.Label5.TabIndex = 0
        Me.Label5.Text = "请输入口令："
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.Button5.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Button5.Location = New System.Drawing.Point(12, 423)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(93, 52)
        Me.Button5.TabIndex = 6
        Me.Button5.Text = "地震科普与地震专题"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Form2
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._030fca73d053a951fbaa4f46808c1d1e
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(819, 558)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form2"
        Me.Text = "山河震撼--纪念汶川地震十周年"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents TextBox纬度跨度下限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox经度跨度下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TextBox时间跨度上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox纬度跨度上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox经度跨度上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox时间跨度下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox数据总量 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button5 As System.Windows.Forms.Button
End Class
