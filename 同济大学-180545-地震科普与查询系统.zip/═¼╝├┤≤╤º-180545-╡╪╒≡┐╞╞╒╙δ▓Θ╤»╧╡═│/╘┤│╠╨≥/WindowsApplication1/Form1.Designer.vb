﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Labely = New System.Windows.Forms.Label()
        Me.Labele = New System.Windows.Forms.Label()
        Me.Labelr = New System.Windows.Forms.Label()
        Me.Labelw = New System.Windows.Forms.Label()
        Me.Labelt = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Labelq = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.DataGridView4 = New System.Windows.Forms.DataGridView()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.TextBox纬度跨度下限 = New System.Windows.Forms.TextBox()
        Me.TextBox经度跨度下限 = New System.Windows.Forms.TextBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.TextBox时间跨度上限 = New System.Windows.Forms.TextBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.TextBox大于六比重 = New System.Windows.Forms.TextBox()
        Me.TextBox四到六比重 = New System.Windows.Forms.TextBox()
        Me.TextBox小于四级百分比 = New System.Windows.Forms.TextBox()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.TextBox大于六数量 = New System.Windows.Forms.TextBox()
        Me.TextBox四到六数量 = New System.Windows.Forms.TextBox()
        Me.TextBox小于四级数量 = New System.Windows.Forms.TextBox()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TextBox纬度跨度上限 = New System.Windows.Forms.TextBox()
        Me.TextBox经度跨度上限 = New System.Windows.Forms.TextBox()
        Me.TextBox时间跨度下限 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox数据总量 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.ComboBox时间查询上限 = New System.Windows.Forms.ComboBox()
        Me.ComboBox时间查询下限 = New System.Windows.Forms.ComboBox()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox震级查询上限 = New System.Windows.Forms.TextBox()
        Me.TextBox震级查询下限 = New System.Windows.Forms.TextBox()
        Me.TextBox经度查询下限 = New System.Windows.Forms.TextBox()
        Me.TextBox经度查询上限 = New System.Windows.Forms.TextBox()
        Me.TextBox纬度查询上限 = New System.Windows.Forms.TextBox()
        Me.TextBox纬度查询下限 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label92 = New System.Windows.Forms.Label()
        Me.Label91 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.Label89 = New System.Windows.Forms.Label()
        Me.Label90 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.ComboBox城市风险年份 = New System.Windows.Forms.ComboBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.DomainUpDown3 = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDown2 = New System.Windows.Forms.DomainUpDown()
        Me.DomainUpDown1 = New System.Windows.Forms.DomainUpDown()
        Me.TextBox风险指数 = New System.Windows.Forms.TextBox()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.TextBox城市小于4级概率 = New System.Windows.Forms.TextBox()
        Me.TextBox城市大于6级概率 = New System.Windows.Forms.TextBox()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.TextBox城市4到6级概率 = New System.Windows.Forms.TextBox()
        Me.DataGridView5 = New System.Windows.Forms.DataGridView()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.TextBox城市风险大于六 = New System.Windows.Forms.TextBox()
        Me.TextBox城市风险四到六 = New System.Windows.Forms.TextBox()
        Me.TextBox城市风险小于四 = New System.Windows.Forms.TextBox()
        Me.TextBox城市风险地震数 = New System.Windows.Forms.TextBox()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TextBox城市纬度查询 = New System.Windows.Forms.TextBox()
        Me.TextBox城市经度查询 = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.ComboBox城市查询 = New System.Windows.Forms.ComboBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Label93 = New System.Windows.Forms.Label()
        Me.Label94 = New System.Windows.Forms.Label()
        Me.Label95 = New System.Windows.Forms.Label()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage5.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage5)
        Me.TabControl1.Location = New System.Drawing.Point(112, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(934, 1210)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.White
        Me.TabPage1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage1.Controls.Add(Me.Button6)
        Me.TabPage1.Controls.Add(Me.Label41)
        Me.TabPage1.Controls.Add(Me.Labely)
        Me.TabPage1.Controls.Add(Me.Labele)
        Me.TabPage1.Controls.Add(Me.Labelr)
        Me.TabPage1.Controls.Add(Me.Labelw)
        Me.TabPage1.Controls.Add(Me.Labelt)
        Me.TabPage1.Controls.Add(Me.Label83)
        Me.TabPage1.Controls.Add(Me.Label82)
        Me.TabPage1.Controls.Add(Me.Label81)
        Me.TabPage1.Controls.Add(Me.Label80)
        Me.TabPage1.Controls.Add(Me.Label79)
        Me.TabPage1.Controls.Add(Me.Label43)
        Me.TabPage1.Controls.Add(Me.Label42)
        Me.TabPage1.Controls.Add(Me.Labelq)
        Me.TabPage1.Controls.Add(Me.Label59)
        Me.TabPage1.Controls.Add(Me.Label58)
        Me.TabPage1.Controls.Add(Me.Label57)
        Me.TabPage1.Controls.Add(Me.Label56)
        Me.TabPage1.Controls.Add(Me.Label55)
        Me.TabPage1.Controls.Add(Me.Label54)
        Me.TabPage1.Controls.Add(Me.PictureBox2)
        Me.TabPage1.Controls.Add(Me.DataGridView4)
        Me.TabPage1.Controls.Add(Me.Label53)
        Me.TabPage1.Controls.Add(Me.Label52)
        Me.TabPage1.Controls.Add(Me.TextBox纬度跨度下限)
        Me.TabPage1.Controls.Add(Me.TextBox经度跨度下限)
        Me.TabPage1.Controls.Add(Me.Label51)
        Me.TabPage1.Controls.Add(Me.TextBox时间跨度上限)
        Me.TabPage1.Controls.Add(Me.Button5)
        Me.TabPage1.Controls.Add(Me.TextBox大于六比重)
        Me.TabPage1.Controls.Add(Me.TextBox四到六比重)
        Me.TabPage1.Controls.Add(Me.TextBox小于四级百分比)
        Me.TabPage1.Controls.Add(Me.Label37)
        Me.TabPage1.Controls.Add(Me.Label36)
        Me.TabPage1.Controls.Add(Me.Label35)
        Me.TabPage1.Controls.Add(Me.TextBox大于六数量)
        Me.TabPage1.Controls.Add(Me.TextBox四到六数量)
        Me.TabPage1.Controls.Add(Me.TextBox小于四级数量)
        Me.TabPage1.Controls.Add(Me.Label34)
        Me.TabPage1.Controls.Add(Me.Label33)
        Me.TabPage1.Controls.Add(Me.Label32)
        Me.TabPage1.Controls.Add(Me.PictureBox1)
        Me.TabPage1.Controls.Add(Me.TextBox纬度跨度上限)
        Me.TabPage1.Controls.Add(Me.TextBox经度跨度上限)
        Me.TabPage1.Controls.Add(Me.TextBox时间跨度下限)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.TextBox数据总量)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(926, 1184)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "后台数据预览"
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button6.ForeColor = System.Drawing.Color.White
        Me.Button6.Location = New System.Drawing.Point(446, 150)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(162, 47)
        Me.Button6.TabIndex = 57
        Me.Button6.Text = "识别地震影响大的区域"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Label41
        '
        Me.Label41.AutoSize = True
        Me.Label41.Location = New System.Drawing.Point(594, 227)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(89, 12)
        Me.Label41.TabIndex = 56
        Me.Label41.Text = "地震频率直方图"
        '
        'Labely
        '
        Me.Labely.AutoSize = True
        Me.Labely.BackColor = System.Drawing.Color.Transparent
        Me.Labely.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labely.Location = New System.Drawing.Point(790, 505)
        Me.Labely.Name = "Labely"
        Me.Labely.Size = New System.Drawing.Size(47, 12)
        Me.Labely.TabIndex = 55
        Me.Labely.Text = "Label88"
        '
        'Labele
        '
        Me.Labele.AutoSize = True
        Me.Labele.BackColor = System.Drawing.Color.Transparent
        Me.Labele.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labele.Location = New System.Drawing.Point(584, 506)
        Me.Labele.Name = "Labele"
        Me.Labele.Size = New System.Drawing.Size(47, 12)
        Me.Labele.TabIndex = 54
        Me.Labele.Text = "Label87"
        '
        'Labelr
        '
        Me.Labelr.AutoSize = True
        Me.Labelr.BackColor = System.Drawing.Color.Transparent
        Me.Labelr.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labelr.Location = New System.Drawing.Point(654, 507)
        Me.Labelr.Name = "Labelr"
        Me.Labelr.Size = New System.Drawing.Size(47, 12)
        Me.Labelr.TabIndex = 53
        Me.Labelr.Text = "Label86"
        '
        'Labelw
        '
        Me.Labelw.AutoSize = True
        Me.Labelw.BackColor = System.Drawing.Color.Transparent
        Me.Labelw.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labelw.Location = New System.Drawing.Point(513, 505)
        Me.Labelw.Name = "Labelw"
        Me.Labelw.Size = New System.Drawing.Size(47, 12)
        Me.Labelw.TabIndex = 52
        Me.Labelw.Text = "Label84"
        '
        'Labelt
        '
        Me.Labelt.AutoSize = True
        Me.Labelt.BackColor = System.Drawing.Color.Transparent
        Me.Labelt.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labelt.Location = New System.Drawing.Point(723, 506)
        Me.Labelt.Name = "Labelt"
        Me.Labelt.Size = New System.Drawing.Size(47, 12)
        Me.Labelt.TabIndex = 52
        Me.Labelt.Text = "Label84"
        '
        'Label83
        '
        Me.Label83.AutoSize = True
        Me.Label83.Location = New System.Drawing.Point(831, 508)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(29, 12)
        Me.Label83.TabIndex = 51
        Me.Label83.Text = "震级"
        '
        'Label82
        '
        Me.Label82.AutoSize = True
        Me.Label82.Location = New System.Drawing.Point(777, 506)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(11, 12)
        Me.Label82.TabIndex = 50
        Me.Label82.Text = "7"
        '
        'Label81
        '
        Me.Label81.AutoSize = True
        Me.Label81.Location = New System.Drawing.Point(707, 506)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(11, 12)
        Me.Label81.TabIndex = 49
        Me.Label81.Text = "6"
        '
        'Label80
        '
        Me.Label80.AutoSize = True
        Me.Label80.Location = New System.Drawing.Point(636, 506)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(11, 12)
        Me.Label80.TabIndex = 48
        Me.Label80.Text = "5"
        '
        'Label79
        '
        Me.Label79.AutoSize = True
        Me.Label79.Location = New System.Drawing.Point(566, 506)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(11, 12)
        Me.Label79.TabIndex = 47
        Me.Label79.Text = "4"
        '
        'Label43
        '
        Me.Label43.AutoSize = True
        Me.Label43.Location = New System.Drawing.Point(495, 506)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(11, 12)
        Me.Label43.TabIndex = 46
        Me.Label43.Text = "3"
        '
        'Label42
        '
        Me.Label42.AutoSize = True
        Me.Label42.Location = New System.Drawing.Point(375, 248)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(29, 12)
        Me.Label42.TabIndex = 45
        Me.Label42.Text = "次数"
        '
        'Labelq
        '
        Me.Labelq.AutoSize = True
        Me.Labelq.BackColor = System.Drawing.Color.Transparent
        Me.Labelq.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Labelq.Location = New System.Drawing.Point(444, 505)
        Me.Labelq.Name = "Labelq"
        Me.Labelq.Size = New System.Drawing.Size(41, 12)
        Me.Labelq.TabIndex = 44
        Me.Labelq.Text = "Labelq"
        '
        'Label59
        '
        Me.Label59.AutoSize = True
        Me.Label59.Location = New System.Drawing.Point(290, 524)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(29, 12)
        Me.Label59.TabIndex = 43
        Me.Label59.Text = ">6级"
        '
        'Label58
        '
        Me.Label58.BackColor = System.Drawing.Color.Red
        Me.Label58.Location = New System.Drawing.Point(329, 519)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(20, 20)
        Me.Label58.TabIndex = 42
        '
        'Label57
        '
        Me.Label57.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label57.Location = New System.Drawing.Point(329, 490)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(20, 20)
        Me.Label57.TabIndex = 41
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(282, 495)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(35, 12)
        Me.Label56.TabIndex = 40
        Me.Label56.Text = "4-6级"
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(290, 465)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(29, 12)
        Me.Label55.TabIndex = 39
        Me.Label55.Text = "<4级"
        '
        'Label54
        '
        Me.Label54.BackColor = System.Drawing.Color.Blue
        Me.Label54.Location = New System.Drawing.Point(329, 462)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(20, 20)
        Me.Label54.TabIndex = 38
        '
        'PictureBox2
        '
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(361, 213)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(559, 339)
        Me.PictureBox2.TabIndex = 37
        Me.PictureBox2.TabStop = False
        '
        'DataGridView4
        '
        Me.DataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView4.Location = New System.Drawing.Point(16, 558)
        Me.DataGridView4.Name = "DataGridView4"
        Me.DataGridView4.RowTemplate.Height = 27
        Me.DataGridView4.Size = New System.Drawing.Size(904, 322)
        Me.DataGridView4.TabIndex = 36
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(569, 30)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(17, 12)
        Me.Label53.TabIndex = 35
        Me.Label53.Text = "到"
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(597, 73)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(17, 12)
        Me.Label52.TabIndex = 34
        Me.Label52.Text = "到"
        '
        'TextBox纬度跨度下限
        '
        Me.TextBox纬度跨度下限.Location = New System.Drawing.Point(478, 70)
        Me.TextBox纬度跨度下限.Name = "TextBox纬度跨度下限"
        Me.TextBox纬度跨度下限.ReadOnly = True
        Me.TextBox纬度跨度下限.Size = New System.Drawing.Size(113, 21)
        Me.TextBox纬度跨度下限.TabIndex = 33
        '
        'TextBox经度跨度下限
        '
        Me.TextBox经度跨度下限.Location = New System.Drawing.Point(99, 70)
        Me.TextBox经度跨度下限.Name = "TextBox经度跨度下限"
        Me.TextBox经度跨度下限.ReadOnly = True
        Me.TextBox经度跨度下限.Size = New System.Drawing.Size(116, 21)
        Me.TextBox经度跨度下限.TabIndex = 32
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(221, 73)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(17, 12)
        Me.Label51.TabIndex = 31
        Me.Label51.Text = "到"
        '
        'TextBox时间跨度上限
        '
        Me.TextBox时间跨度上限.Location = New System.Drawing.Point(597, 27)
        Me.TextBox时间跨度上限.Name = "TextBox时间跨度上限"
        Me.TextBox时间跨度上限.ReadOnly = True
        Me.TextBox时间跨度上限.Size = New System.Drawing.Size(261, 21)
        Me.TextBox时间跨度上限.TabIndex = 30
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button5.ForeColor = System.Drawing.Color.White
        Me.Button5.Location = New System.Drawing.Point(649, 150)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(144, 47)
        Me.Button5.TabIndex = 28
        Me.Button5.Text = "在地图中标记地震"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'TextBox大于六比重
        '
        Me.TextBox大于六比重.Location = New System.Drawing.Point(267, 182)
        Me.TextBox大于六比重.Name = "TextBox大于六比重"
        Me.TextBox大于六比重.ReadOnly = True
        Me.TextBox大于六比重.Size = New System.Drawing.Size(108, 21)
        Me.TextBox大于六比重.TabIndex = 23
        '
        'TextBox四到六比重
        '
        Me.TextBox四到六比重.Location = New System.Drawing.Point(267, 144)
        Me.TextBox四到六比重.Name = "TextBox四到六比重"
        Me.TextBox四到六比重.ReadOnly = True
        Me.TextBox四到六比重.Size = New System.Drawing.Size(108, 21)
        Me.TextBox四到六比重.TabIndex = 22
        '
        'TextBox小于四级百分比
        '
        Me.TextBox小于四级百分比.Location = New System.Drawing.Point(267, 109)
        Me.TextBox小于四级百分比.Name = "TextBox小于四级百分比"
        Me.TextBox小于四级百分比.ReadOnly = True
        Me.TextBox小于四级百分比.Size = New System.Drawing.Size(108, 21)
        Me.TextBox小于四级百分比.TabIndex = 21
        '
        'Label37
        '
        Me.Label37.AutoSize = True
        Me.Label37.Location = New System.Drawing.Point(239, 185)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(17, 12)
        Me.Label37.TabIndex = 20
        Me.Label37.Text = "占"
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(239, 147)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(17, 12)
        Me.Label36.TabIndex = 19
        Me.Label36.Text = "占"
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(239, 112)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(17, 12)
        Me.Label35.TabIndex = 18
        Me.Label35.Text = "占"
        '
        'TextBox大于六数量
        '
        Me.TextBox大于六数量.Location = New System.Drawing.Point(125, 182)
        Me.TextBox大于六数量.Name = "TextBox大于六数量"
        Me.TextBox大于六数量.ReadOnly = True
        Me.TextBox大于六数量.Size = New System.Drawing.Size(108, 21)
        Me.TextBox大于六数量.TabIndex = 17
        '
        'TextBox四到六数量
        '
        Me.TextBox四到六数量.Location = New System.Drawing.Point(125, 144)
        Me.TextBox四到六数量.Name = "TextBox四到六数量"
        Me.TextBox四到六数量.ReadOnly = True
        Me.TextBox四到六数量.Size = New System.Drawing.Size(108, 21)
        Me.TextBox四到六数量.TabIndex = 16
        '
        'TextBox小于四级数量
        '
        Me.TextBox小于四级数量.Location = New System.Drawing.Point(125, 109)
        Me.TextBox小于四级数量.Name = "TextBox小于四级数量"
        Me.TextBox小于四级数量.ReadOnly = True
        Me.TextBox小于四级数量.Size = New System.Drawing.Size(108, 21)
        Me.TextBox小于四级数量.TabIndex = 15
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(12, 185)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(83, 12)
        Me.Label34.TabIndex = 14
        Me.Label34.Text = "6级以上地震："
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(11, 147)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(83, 12)
        Me.Label33.TabIndex = 13
        Me.Label33.Text = "4-6级地震数："
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(13, 112)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(95, 12)
        Me.Label32.TabIndex = 12
        Me.Label32.Text = "4级以下地震数："
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(16, 213)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(339, 339)
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'TextBox纬度跨度上限
        '
        Me.TextBox纬度跨度上限.Location = New System.Drawing.Point(625, 70)
        Me.TextBox纬度跨度上限.Name = "TextBox纬度跨度上限"
        Me.TextBox纬度跨度上限.ReadOnly = True
        Me.TextBox纬度跨度上限.Size = New System.Drawing.Size(168, 21)
        Me.TextBox纬度跨度上限.TabIndex = 7
        '
        'TextBox经度跨度上限
        '
        Me.TextBox经度跨度上限.Location = New System.Drawing.Point(242, 70)
        Me.TextBox经度跨度上限.Name = "TextBox经度跨度上限"
        Me.TextBox经度跨度上限.ReadOnly = True
        Me.TextBox经度跨度上限.Size = New System.Drawing.Size(133, 21)
        Me.TextBox经度跨度上限.TabIndex = 6
        '
        'TextBox时间跨度下限
        '
        Me.TextBox时间跨度下限.Location = New System.Drawing.Point(315, 27)
        Me.TextBox时间跨度下限.Name = "TextBox时间跨度下限"
        Me.TextBox时间跨度下限.ReadOnly = True
        Me.TextBox时间跨度下限.Size = New System.Drawing.Size(248, 21)
        Me.TextBox时间跨度下限.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(403, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 12)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "纬度范围："
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(26, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(65, 12)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "经度范围："
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(239, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(65, 12)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "时间范围："
        '
        'TextBox数据总量
        '
        Me.TextBox数据总量.Location = New System.Drawing.Point(99, 27)
        Me.TextBox数据总量.Name = "TextBox数据总量"
        Me.TextBox数据总量.ReadOnly = True
        Me.TextBox数据总量.Size = New System.Drawing.Size(116, 21)
        Me.TextBox数据总量.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(26, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "数据总量："
        '
        'TabPage2
        '
        Me.TabPage2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage2.Controls.Add(Me.Button10)
        Me.TabPage2.Controls.Add(Me.ComboBox时间查询上限)
        Me.TabPage2.Controls.Add(Me.ComboBox时间查询下限)
        Me.TabPage2.Controls.Add(Me.DataGridView1)
        Me.TabPage2.Controls.Add(Me.Button1)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.Label10)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.TextBox震级查询上限)
        Me.TabPage2.Controls.Add(Me.TextBox震级查询下限)
        Me.TabPage2.Controls.Add(Me.TextBox经度查询下限)
        Me.TabPage2.Controls.Add(Me.TextBox经度查询上限)
        Me.TabPage2.Controls.Add(Me.TextBox纬度查询上限)
        Me.TabPage2.Controls.Add(Me.TextBox纬度查询下限)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(926, 1184)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "地震记录查询"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button10.ForeColor = System.Drawing.Color.White
        Me.Button10.Location = New System.Drawing.Point(612, 18)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(144, 47)
        Me.Button10.TabIndex = 31
        Me.Button10.Text = "开始查询"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'ComboBox时间查询上限
        '
        Me.ComboBox时间查询上限.FormattingEnabled = True
        Me.ComboBox时间查询上限.Location = New System.Drawing.Point(265, 18)
        Me.ComboBox时间查询上限.Name = "ComboBox时间查询上限"
        Me.ComboBox时间查询上限.Size = New System.Drawing.Size(146, 20)
        Me.ComboBox时间查询上限.TabIndex = 30
        '
        'ComboBox时间查询下限
        '
        Me.ComboBox时间查询下限.FormattingEnabled = True
        Me.ComboBox时间查询下限.Location = New System.Drawing.Point(100, 18)
        Me.ComboBox时间查询下限.Name = "ComboBox时间查询下限"
        Me.ComboBox时间查询下限.Size = New System.Drawing.Size(140, 20)
        Me.ComboBox时间查询下限.TabIndex = 29
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(28, 184)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 27
        Me.DataGridView1.Size = New System.Drawing.Size(873, 668)
        Me.DataGridView1.TabIndex = 28
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button1.ForeColor = System.Drawing.Color.White
        Me.Button1.Location = New System.Drawing.Point(612, 147)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(144, 31)
        Me.Button1.TabIndex = 27
        Me.Button1.Text = "在地图中标注地震"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(146, 155)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(65, 12)
        Me.Label20.TabIndex = 26
        Me.Label20.Text = "（记录数）"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(234, 155)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(41, 12)
        Me.Label19.TabIndex = 25
        Me.Label19.Text = "条记录"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(103, 155)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(29, 12)
        Me.Label18.TabIndex = 24
        Me.Label18.Text = "共有"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(25, 155)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(65, 12)
        Me.Label17.TabIndex = 23
        Me.Label17.Text = "查询结果："
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(378, 86)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(131, 12)
        Me.Label15.TabIndex = 21
        Me.Label15.Text = "输入-180--180之间的值"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(378, 55)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(119, 12)
        Me.Label14.TabIndex = 20
        Me.Label14.Text = "输入-90--90之间的值"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(219, 117)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(17, 12)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "到"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(219, 86)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(17, 12)
        Me.Label11.TabIndex = 17
        Me.Label11.Text = "到"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(218, 55)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(17, 12)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "到"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(246, 21)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(17, 12)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "到"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(33, 117)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 12)
        Me.Label8.TabIndex = 14
        Me.Label8.Text = "震级："
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(33, 89)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(41, 12)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "经度："
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 55)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 12)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "纬度："
        '
        'TextBox震级查询上限
        '
        Me.TextBox震级查询上限.Location = New System.Drawing.Point(246, 114)
        Me.TextBox震级查询上限.Name = "TextBox震级查询上限"
        Me.TextBox震级查询上限.Size = New System.Drawing.Size(126, 21)
        Me.TextBox震级查询上限.TabIndex = 9
        '
        'TextBox震级查询下限
        '
        Me.TextBox震级查询下限.Location = New System.Drawing.Point(91, 114)
        Me.TextBox震级查询下限.Name = "TextBox震级查询下限"
        Me.TextBox震级查询下限.Size = New System.Drawing.Size(122, 21)
        Me.TextBox震级查询下限.TabIndex = 8
        '
        'TextBox经度查询下限
        '
        Me.TextBox经度查询下限.Location = New System.Drawing.Point(91, 83)
        Me.TextBox经度查询下限.Name = "TextBox经度查询下限"
        Me.TextBox经度查询下限.Size = New System.Drawing.Size(122, 21)
        Me.TextBox经度查询下限.TabIndex = 7
        '
        'TextBox经度查询上限
        '
        Me.TextBox经度查询上限.Location = New System.Drawing.Point(246, 83)
        Me.TextBox经度查询上限.Name = "TextBox经度查询上限"
        Me.TextBox经度查询上限.Size = New System.Drawing.Size(126, 21)
        Me.TextBox经度查询上限.TabIndex = 6
        '
        'TextBox纬度查询上限
        '
        Me.TextBox纬度查询上限.Location = New System.Drawing.Point(246, 52)
        Me.TextBox纬度查询上限.Name = "TextBox纬度查询上限"
        Me.TextBox纬度查询上限.Size = New System.Drawing.Size(126, 21)
        Me.TextBox纬度查询上限.TabIndex = 5
        '
        'TextBox纬度查询下限
        '
        Me.TextBox纬度查询下限.Location = New System.Drawing.Point(91, 52)
        Me.TextBox纬度查询下限.Name = "TextBox纬度查询下限"
        Me.TextBox纬度查询下限.Size = New System.Drawing.Size(122, 21)
        Me.TextBox纬度查询下限.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 21)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 12)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "发震时间："
        '
        'TabPage4
        '
        Me.TabPage4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage4.Controls.Add(Me.Label95)
        Me.TabPage4.Controls.Add(Me.Label94)
        Me.TabPage4.Controls.Add(Me.Label93)
        Me.TabPage4.Controls.Add(Me.Label92)
        Me.TabPage4.Controls.Add(Me.Label91)
        Me.TabPage4.Controls.Add(Me.Label86)
        Me.TabPage4.Controls.Add(Me.Label87)
        Me.TabPage4.Controls.Add(Me.Label88)
        Me.TabPage4.Controls.Add(Me.Label89)
        Me.TabPage4.Controls.Add(Me.Label90)
        Me.TabPage4.Controls.Add(Me.Button8)
        Me.TabPage4.Controls.Add(Me.GroupBox3)
        Me.TabPage4.Controls.Add(Me.PictureBox3)
        Me.TabPage4.Controls.Add(Me.Label76)
        Me.TabPage4.Controls.Add(Me.Label75)
        Me.TabPage4.Controls.Add(Me.Label74)
        Me.TabPage4.Controls.Add(Me.Label73)
        Me.TabPage4.Controls.Add(Me.Label72)
        Me.TabPage4.Controls.Add(Me.Label71)
        Me.TabPage4.Controls.Add(Me.Label70)
        Me.TabPage4.Controls.Add(Me.Label69)
        Me.TabPage4.Controls.Add(Me.Label68)
        Me.TabPage4.Controls.Add(Me.Label67)
        Me.TabPage4.Controls.Add(Me.Label66)
        Me.TabPage4.Controls.Add(Me.Label65)
        Me.TabPage4.Controls.Add(Me.Label64)
        Me.TabPage4.Controls.Add(Me.Label63)
        Me.TabPage4.Controls.Add(Me.Label38)
        Me.TabPage4.Controls.Add(Me.Button3)
        Me.TabPage4.Controls.Add(Me.ComboBox城市风险年份)
        Me.TabPage4.Controls.Add(Me.PictureBox4)
        Me.TabPage4.Controls.Add(Me.Button4)
        Me.TabPage4.Controls.Add(Me.GroupBox1)
        Me.TabPage4.Controls.Add(Me.Button2)
        Me.TabPage4.Controls.Add(Me.TextBox城市纬度查询)
        Me.TabPage4.Controls.Add(Me.TextBox城市经度查询)
        Me.TabPage4.Controls.Add(Me.Label24)
        Me.TabPage4.Controls.Add(Me.Label23)
        Me.TabPage4.Controls.Add(Me.ComboBox城市查询)
        Me.TabPage4.Controls.Add(Me.Label22)
        Me.TabPage4.Controls.Add(Me.Label27)
        Me.TabPage4.Controls.Add(Me.Label26)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(926, 1184)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "城市地震风险评估"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label92
        '
        Me.Label92.AutoSize = True
        Me.Label92.Location = New System.Drawing.Point(101, 910)
        Me.Label92.Name = "Label92"
        Me.Label92.Size = New System.Drawing.Size(23, 12)
        Me.Label92.TabIndex = 63
        Me.Label92.Text = "40%"
        '
        'Label91
        '
        Me.Label91.AutoSize = True
        Me.Label91.Location = New System.Drawing.Point(858, 1124)
        Me.Label91.Name = "Label91"
        Me.Label91.Size = New System.Drawing.Size(29, 12)
        Me.Label91.TabIndex = 62
        Me.Label91.Text = "年份"
        '
        'Label86
        '
        Me.Label86.AutoSize = True
        Me.Label86.Location = New System.Drawing.Point(39, 955)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(23, 12)
        Me.Label86.TabIndex = 61
        Me.Label86.Text = "40%"
        '
        'Label87
        '
        Me.Label87.AutoSize = True
        Me.Label87.Location = New System.Drawing.Point(40, 1003)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(23, 12)
        Me.Label87.TabIndex = 60
        Me.Label87.Text = "30%"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Location = New System.Drawing.Point(40, 1056)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(23, 12)
        Me.Label88.TabIndex = 59
        Me.Label88.Text = "20%"
        '
        'Label89
        '
        Me.Label89.AutoSize = True
        Me.Label89.Location = New System.Drawing.Point(40, 1109)
        Me.Label89.Name = "Label89"
        Me.Label89.Size = New System.Drawing.Size(23, 12)
        Me.Label89.TabIndex = 58
        Me.Label89.Text = "10%"
        '
        'Label90
        '
        Me.Label90.AutoSize = True
        Me.Label90.Location = New System.Drawing.Point(17, 903)
        Me.Label90.Name = "Label90"
        Me.Label90.Size = New System.Drawing.Size(41, 36)
        Me.Label90.TabIndex = 57
        Me.Label90.Text = "地震" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "频率" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（次）"
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button8.ForeColor = System.Drawing.Color.White
        Me.Button8.Location = New System.Drawing.Point(681, 897)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(222, 31)
        Me.Button8.TabIndex = 36
        Me.Button8.Text = "显示近年来该地地震频率变化趋势"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label85)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label77)
        Me.GroupBox3.Controls.Add(Me.Label50)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label49)
        Me.GroupBox3.Location = New System.Drawing.Point(790, 925)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(100, 103)
        Me.GroupBox3.TabIndex = 56
        Me.GroupBox3.TabStop = False
        '
        'Label85
        '
        Me.Label85.BackColor = System.Drawing.Color.Blue
        Me.Label85.Location = New System.Drawing.Point(17, 19)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(20, 20)
        Me.Label85.TabIndex = 50
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(38, 72)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(53, 12)
        Me.Label13.TabIndex = 55
        Me.Label13.Text = ">6级地震"
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(38, 21)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(53, 12)
        Me.Label77.TabIndex = 51
        Me.Label77.Text = "<4级地震"
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label50.Location = New System.Drawing.Point(17, 44)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(20, 20)
        Me.Label50.TabIndex = 52
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.Red
        Me.Label16.Location = New System.Drawing.Point(17, 70)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(20, 20)
        Me.Label16.TabIndex = 54
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(38, 46)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(59, 12)
        Me.Label49.TabIndex = 53
        Me.Label49.Text = "4-6级地震"
        '
        'PictureBox3
        '
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox3.Location = New System.Drawing.Point(12, 888)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(902, 288)
        Me.PictureBox3.TabIndex = 49
        Me.PictureBox3.TabStop = False
        '
        'Label76
        '
        Me.Label76.AutoSize = True
        Me.Label76.Location = New System.Drawing.Point(809, 142)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(53, 12)
        Me.Label76.TabIndex = 48
        Me.Label76.Text = ">6级地震"
        '
        'Label75
        '
        Me.Label75.BackColor = System.Drawing.Color.Red
        Me.Label75.Location = New System.Drawing.Point(788, 140)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(20, 20)
        Me.Label75.TabIndex = 47
        '
        'Label74
        '
        Me.Label74.AutoSize = True
        Me.Label74.Location = New System.Drawing.Point(809, 116)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(59, 12)
        Me.Label74.TabIndex = 46
        Me.Label74.Text = "4-6级地震"
        '
        'Label73
        '
        Me.Label73.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Label73.Location = New System.Drawing.Point(788, 114)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(20, 20)
        Me.Label73.TabIndex = 45
        '
        'Label72
        '
        Me.Label72.AutoSize = True
        Me.Label72.Location = New System.Drawing.Point(809, 91)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(53, 12)
        Me.Label72.TabIndex = 44
        Me.Label72.Text = "<4级地震"
        '
        'Label71
        '
        Me.Label71.BackColor = System.Drawing.Color.Blue
        Me.Label71.Location = New System.Drawing.Point(788, 89)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(20, 20)
        Me.Label71.TabIndex = 43
        '
        'Label70
        '
        Me.Label70.AutoSize = True
        Me.Label70.Location = New System.Drawing.Point(660, 358)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(17, 12)
        Me.Label70.TabIndex = 42
        Me.Label70.Text = "30"
        '
        'Label69
        '
        Me.Label69.AutoSize = True
        Me.Label69.Location = New System.Drawing.Point(459, 358)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(17, 12)
        Me.Label69.TabIndex = 41
        Me.Label69.Text = "20"
        '
        'Label68
        '
        Me.Label68.AutoSize = True
        Me.Label68.Location = New System.Drawing.Point(256, 358)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(17, 12)
        Me.Label68.TabIndex = 40
        Me.Label68.Text = "10"
        '
        'Label67
        '
        Me.Label67.AutoSize = True
        Me.Label67.Location = New System.Drawing.Point(39, 141)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(23, 12)
        Me.Label67.TabIndex = 39
        Me.Label67.Text = "40%"
        '
        'Label66
        '
        Me.Label66.AutoSize = True
        Me.Label66.Location = New System.Drawing.Point(40, 189)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(23, 12)
        Me.Label66.TabIndex = 38
        Me.Label66.Text = "30%"
        '
        'Label65
        '
        Me.Label65.AutoSize = True
        Me.Label65.Location = New System.Drawing.Point(40, 242)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(23, 12)
        Me.Label65.TabIndex = 37
        Me.Label65.Text = "20%"
        '
        'Label64
        '
        Me.Label64.AutoSize = True
        Me.Label64.Location = New System.Drawing.Point(40, 295)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(23, 12)
        Me.Label64.TabIndex = 36
        Me.Label64.Text = "10%"
        '
        'Label63
        '
        Me.Label63.AutoSize = True
        Me.Label63.Location = New System.Drawing.Point(767, 358)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(113, 12)
        Me.Label63.TabIndex = 35
        Me.Label63.Text = "一年内地震发生次数"
        '
        'Label38
        '
        Me.Label38.AutoSize = True
        Me.Label38.Location = New System.Drawing.Point(17, 89)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(35, 36)
        Me.Label38.TabIndex = 34
        Me.Label38.Text = "概" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "率" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "（%）"
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button3.ForeColor = System.Drawing.Color.White
        Me.Button3.Location = New System.Drawing.Point(640, 43)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(192, 29)
        Me.Button3.TabIndex = 33
        Me.Button3.Text = "在地图中标注地震"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'ComboBox城市风险年份
        '
        Me.ComboBox城市风险年份.FormattingEnabled = True
        Me.ComboBox城市风险年份.Location = New System.Drawing.Point(508, 11)
        Me.ComboBox城市风险年份.Name = "ComboBox城市风险年份"
        Me.ComboBox城市风险年份.Size = New System.Drawing.Size(121, 20)
        Me.ComboBox城市风险年份.TabIndex = 32
        '
        'PictureBox4
        '
        Me.PictureBox4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox4.Location = New System.Drawing.Point(12, 78)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(902, 318)
        Me.PictureBox4.TabIndex = 20
        Me.PictureBox4.TabStop = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button4.ForeColor = System.Drawing.Color.White
        Me.Button4.Location = New System.Drawing.Point(532, 43)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(99, 29)
        Me.Button4.TabIndex = 31
        Me.Button4.Text = "开始评估"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.DataGridView5)
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.Label30)
        Me.GroupBox1.Controls.Add(Me.Label29)
        Me.GroupBox1.Controls.Add(Me.TextBox城市风险大于六)
        Me.GroupBox1.Controls.Add(Me.TextBox城市风险四到六)
        Me.GroupBox1.Controls.Add(Me.TextBox城市风险小于四)
        Me.GroupBox1.Controls.Add(Me.TextBox城市风险地震数)
        Me.GroupBox1.Controls.Add(Me.Label28)
        Me.GroupBox1.Controls.Add(Me.Label25)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 402)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(902, 480)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "区域地震年频率报告"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label84)
        Me.GroupBox2.Controls.Add(Me.Label78)
        Me.GroupBox2.Controls.Add(Me.Label40)
        Me.GroupBox2.Controls.Add(Me.DomainUpDown3)
        Me.GroupBox2.Controls.Add(Me.DomainUpDown2)
        Me.GroupBox2.Controls.Add(Me.DomainUpDown1)
        Me.GroupBox2.Controls.Add(Me.TextBox风险指数)
        Me.GroupBox2.Controls.Add(Me.Label39)
        Me.GroupBox2.Controls.Add(Me.Label62)
        Me.GroupBox2.Controls.Add(Me.TextBox城市小于4级概率)
        Me.GroupBox2.Controls.Add(Me.TextBox城市大于6级概率)
        Me.GroupBox2.Controls.Add(Me.Label60)
        Me.GroupBox2.Controls.Add(Me.Label61)
        Me.GroupBox2.Controls.Add(Me.TextBox城市4到6级概率)
        Me.GroupBox2.Location = New System.Drawing.Point(669, 61)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(228, 412)
        Me.GroupBox2.TabIndex = 29
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "评估结果"
        '
        'Label84
        '
        Me.Label84.AutoSize = True
        Me.Label84.Location = New System.Drawing.Point(15, 208)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(131, 12)
        Me.Label84.TabIndex = 34
        Me.Label84.Text = "场6级以上地震的概率："
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Location = New System.Drawing.Point(15, 124)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(119, 12)
        Me.Label78.TabIndex = 33
        Me.Label78.Text = "场4-6级地震的概率："
        '
        'Label40
        '
        Me.Label40.AutoSize = True
        Me.Label40.Location = New System.Drawing.Point(15, 46)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(131, 12)
        Me.Label40.TabIndex = 32
        Me.Label40.Text = "场4级以下地震的概率："
        '
        'DomainUpDown3
        '
        Me.DomainUpDown3.Items.Add("99")
        Me.DomainUpDown3.Items.Add("98")
        Me.DomainUpDown3.Items.Add("97")
        Me.DomainUpDown3.Items.Add("96")
        Me.DomainUpDown3.Items.Add("95")
        Me.DomainUpDown3.Items.Add("94")
        Me.DomainUpDown3.Items.Add("93")
        Me.DomainUpDown3.Items.Add("92")
        Me.DomainUpDown3.Items.Add("91")
        Me.DomainUpDown3.Items.Add("90")
        Me.DomainUpDown3.Items.Add("89")
        Me.DomainUpDown3.Items.Add("88")
        Me.DomainUpDown3.Items.Add("87")
        Me.DomainUpDown3.Items.Add("86")
        Me.DomainUpDown3.Items.Add("85")
        Me.DomainUpDown3.Items.Add("84")
        Me.DomainUpDown3.Items.Add("83")
        Me.DomainUpDown3.Items.Add("82")
        Me.DomainUpDown3.Items.Add("81")
        Me.DomainUpDown3.Items.Add("80")
        Me.DomainUpDown3.Items.Add("79")
        Me.DomainUpDown3.Items.Add("78")
        Me.DomainUpDown3.Items.Add("77")
        Me.DomainUpDown3.Items.Add("76")
        Me.DomainUpDown3.Items.Add("75")
        Me.DomainUpDown3.Items.Add("74")
        Me.DomainUpDown3.Items.Add("73")
        Me.DomainUpDown3.Items.Add("72")
        Me.DomainUpDown3.Items.Add("71")
        Me.DomainUpDown3.Items.Add("70")
        Me.DomainUpDown3.Items.Add("69")
        Me.DomainUpDown3.Items.Add("68")
        Me.DomainUpDown3.Items.Add("67")
        Me.DomainUpDown3.Items.Add("66")
        Me.DomainUpDown3.Items.Add("65")
        Me.DomainUpDown3.Items.Add("64")
        Me.DomainUpDown3.Items.Add("63")
        Me.DomainUpDown3.Items.Add("62")
        Me.DomainUpDown3.Items.Add("61")
        Me.DomainUpDown3.Items.Add("60")
        Me.DomainUpDown3.Items.Add("59")
        Me.DomainUpDown3.Items.Add("58")
        Me.DomainUpDown3.Items.Add("57")
        Me.DomainUpDown3.Items.Add("56")
        Me.DomainUpDown3.Items.Add("55")
        Me.DomainUpDown3.Items.Add("54")
        Me.DomainUpDown3.Items.Add("53")
        Me.DomainUpDown3.Items.Add("52")
        Me.DomainUpDown3.Items.Add("51")
        Me.DomainUpDown3.Items.Add("50")
        Me.DomainUpDown3.Items.Add("49")
        Me.DomainUpDown3.Items.Add("48")
        Me.DomainUpDown3.Items.Add("47")
        Me.DomainUpDown3.Items.Add("46")
        Me.DomainUpDown3.Items.Add("45")
        Me.DomainUpDown3.Items.Add("44")
        Me.DomainUpDown3.Items.Add("43")
        Me.DomainUpDown3.Items.Add("42")
        Me.DomainUpDown3.Items.Add("41")
        Me.DomainUpDown3.Items.Add("40")
        Me.DomainUpDown3.Items.Add("39")
        Me.DomainUpDown3.Items.Add("38")
        Me.DomainUpDown3.Items.Add("37")
        Me.DomainUpDown3.Items.Add("36")
        Me.DomainUpDown3.Items.Add("35")
        Me.DomainUpDown3.Items.Add("34")
        Me.DomainUpDown3.Items.Add("33")
        Me.DomainUpDown3.Items.Add("32")
        Me.DomainUpDown3.Items.Add("31")
        Me.DomainUpDown3.Items.Add("30")
        Me.DomainUpDown3.Items.Add("29")
        Me.DomainUpDown3.Items.Add("28")
        Me.DomainUpDown3.Items.Add("27")
        Me.DomainUpDown3.Items.Add("26")
        Me.DomainUpDown3.Items.Add("25")
        Me.DomainUpDown3.Items.Add("24")
        Me.DomainUpDown3.Items.Add("23")
        Me.DomainUpDown3.Items.Add("22")
        Me.DomainUpDown3.Items.Add("21")
        Me.DomainUpDown3.Items.Add("20")
        Me.DomainUpDown3.Items.Add("19")
        Me.DomainUpDown3.Items.Add("18")
        Me.DomainUpDown3.Items.Add("17")
        Me.DomainUpDown3.Items.Add("16")
        Me.DomainUpDown3.Items.Add("15")
        Me.DomainUpDown3.Items.Add("14")
        Me.DomainUpDown3.Items.Add("13")
        Me.DomainUpDown3.Items.Add("12")
        Me.DomainUpDown3.Items.Add("11")
        Me.DomainUpDown3.Items.Add("10")
        Me.DomainUpDown3.Items.Add("9")
        Me.DomainUpDown3.Items.Add("8")
        Me.DomainUpDown3.Items.Add("7")
        Me.DomainUpDown3.Items.Add("6")
        Me.DomainUpDown3.Items.Add("5")
        Me.DomainUpDown3.Items.Add("4")
        Me.DomainUpDown3.Items.Add("3")
        Me.DomainUpDown3.Items.Add("2")
        Me.DomainUpDown3.Items.Add("1")
        Me.DomainUpDown3.Location = New System.Drawing.Point(90, 181)
        Me.DomainUpDown3.Name = "DomainUpDown3"
        Me.DomainUpDown3.ReadOnly = True
        Me.DomainUpDown3.Size = New System.Drawing.Size(39, 21)
        Me.DomainUpDown3.TabIndex = 31
        Me.DomainUpDown3.Text = "1"
        '
        'DomainUpDown2
        '
        Me.DomainUpDown2.Items.Add("99")
        Me.DomainUpDown2.Items.Add("98")
        Me.DomainUpDown2.Items.Add("97")
        Me.DomainUpDown2.Items.Add("96")
        Me.DomainUpDown2.Items.Add("95")
        Me.DomainUpDown2.Items.Add("94")
        Me.DomainUpDown2.Items.Add("93")
        Me.DomainUpDown2.Items.Add("92")
        Me.DomainUpDown2.Items.Add("91")
        Me.DomainUpDown2.Items.Add("90")
        Me.DomainUpDown2.Items.Add("89")
        Me.DomainUpDown2.Items.Add("88")
        Me.DomainUpDown2.Items.Add("87")
        Me.DomainUpDown2.Items.Add("86")
        Me.DomainUpDown2.Items.Add("85")
        Me.DomainUpDown2.Items.Add("84")
        Me.DomainUpDown2.Items.Add("83")
        Me.DomainUpDown2.Items.Add("82")
        Me.DomainUpDown2.Items.Add("81")
        Me.DomainUpDown2.Items.Add("80")
        Me.DomainUpDown2.Items.Add("79")
        Me.DomainUpDown2.Items.Add("78")
        Me.DomainUpDown2.Items.Add("77")
        Me.DomainUpDown2.Items.Add("76")
        Me.DomainUpDown2.Items.Add("75")
        Me.DomainUpDown2.Items.Add("74")
        Me.DomainUpDown2.Items.Add("73")
        Me.DomainUpDown2.Items.Add("72")
        Me.DomainUpDown2.Items.Add("71")
        Me.DomainUpDown2.Items.Add("70")
        Me.DomainUpDown2.Items.Add("69")
        Me.DomainUpDown2.Items.Add("68")
        Me.DomainUpDown2.Items.Add("67")
        Me.DomainUpDown2.Items.Add("66")
        Me.DomainUpDown2.Items.Add("65")
        Me.DomainUpDown2.Items.Add("64")
        Me.DomainUpDown2.Items.Add("63")
        Me.DomainUpDown2.Items.Add("62")
        Me.DomainUpDown2.Items.Add("61")
        Me.DomainUpDown2.Items.Add("60")
        Me.DomainUpDown2.Items.Add("59")
        Me.DomainUpDown2.Items.Add("58")
        Me.DomainUpDown2.Items.Add("57")
        Me.DomainUpDown2.Items.Add("56")
        Me.DomainUpDown2.Items.Add("55")
        Me.DomainUpDown2.Items.Add("54")
        Me.DomainUpDown2.Items.Add("53")
        Me.DomainUpDown2.Items.Add("52")
        Me.DomainUpDown2.Items.Add("51")
        Me.DomainUpDown2.Items.Add("50")
        Me.DomainUpDown2.Items.Add("49")
        Me.DomainUpDown2.Items.Add("48")
        Me.DomainUpDown2.Items.Add("47")
        Me.DomainUpDown2.Items.Add("46")
        Me.DomainUpDown2.Items.Add("45")
        Me.DomainUpDown2.Items.Add("44")
        Me.DomainUpDown2.Items.Add("43")
        Me.DomainUpDown2.Items.Add("42")
        Me.DomainUpDown2.Items.Add("41")
        Me.DomainUpDown2.Items.Add("40")
        Me.DomainUpDown2.Items.Add("39")
        Me.DomainUpDown2.Items.Add("38")
        Me.DomainUpDown2.Items.Add("37")
        Me.DomainUpDown2.Items.Add("36")
        Me.DomainUpDown2.Items.Add("35")
        Me.DomainUpDown2.Items.Add("34")
        Me.DomainUpDown2.Items.Add("33")
        Me.DomainUpDown2.Items.Add("32")
        Me.DomainUpDown2.Items.Add("31")
        Me.DomainUpDown2.Items.Add("30")
        Me.DomainUpDown2.Items.Add("29")
        Me.DomainUpDown2.Items.Add("28")
        Me.DomainUpDown2.Items.Add("27")
        Me.DomainUpDown2.Items.Add("26")
        Me.DomainUpDown2.Items.Add("25")
        Me.DomainUpDown2.Items.Add("24")
        Me.DomainUpDown2.Items.Add("23")
        Me.DomainUpDown2.Items.Add("22")
        Me.DomainUpDown2.Items.Add("21")
        Me.DomainUpDown2.Items.Add("20")
        Me.DomainUpDown2.Items.Add("19")
        Me.DomainUpDown2.Items.Add("18")
        Me.DomainUpDown2.Items.Add("17")
        Me.DomainUpDown2.Items.Add("16")
        Me.DomainUpDown2.Items.Add("15")
        Me.DomainUpDown2.Items.Add("14")
        Me.DomainUpDown2.Items.Add("13")
        Me.DomainUpDown2.Items.Add("12")
        Me.DomainUpDown2.Items.Add("11")
        Me.DomainUpDown2.Items.Add("10")
        Me.DomainUpDown2.Items.Add("9")
        Me.DomainUpDown2.Items.Add("8")
        Me.DomainUpDown2.Items.Add("7")
        Me.DomainUpDown2.Items.Add("6")
        Me.DomainUpDown2.Items.Add("5")
        Me.DomainUpDown2.Items.Add("4")
        Me.DomainUpDown2.Items.Add("3")
        Me.DomainUpDown2.Items.Add("2")
        Me.DomainUpDown2.Items.Add("1")
        Me.DomainUpDown2.Location = New System.Drawing.Point(90, 100)
        Me.DomainUpDown2.Name = "DomainUpDown2"
        Me.DomainUpDown2.ReadOnly = True
        Me.DomainUpDown2.Size = New System.Drawing.Size(40, 21)
        Me.DomainUpDown2.TabIndex = 30
        Me.DomainUpDown2.Text = "1"
        '
        'DomainUpDown1
        '
        Me.DomainUpDown1.Items.Add("99")
        Me.DomainUpDown1.Items.Add("98")
        Me.DomainUpDown1.Items.Add("97")
        Me.DomainUpDown1.Items.Add("96")
        Me.DomainUpDown1.Items.Add("95")
        Me.DomainUpDown1.Items.Add("94")
        Me.DomainUpDown1.Items.Add("93")
        Me.DomainUpDown1.Items.Add("92")
        Me.DomainUpDown1.Items.Add("91")
        Me.DomainUpDown1.Items.Add("90")
        Me.DomainUpDown1.Items.Add("89")
        Me.DomainUpDown1.Items.Add("88")
        Me.DomainUpDown1.Items.Add("87")
        Me.DomainUpDown1.Items.Add("86")
        Me.DomainUpDown1.Items.Add("85")
        Me.DomainUpDown1.Items.Add("84")
        Me.DomainUpDown1.Items.Add("83")
        Me.DomainUpDown1.Items.Add("82")
        Me.DomainUpDown1.Items.Add("81")
        Me.DomainUpDown1.Items.Add("80")
        Me.DomainUpDown1.Items.Add("79")
        Me.DomainUpDown1.Items.Add("78")
        Me.DomainUpDown1.Items.Add("77")
        Me.DomainUpDown1.Items.Add("76")
        Me.DomainUpDown1.Items.Add("75")
        Me.DomainUpDown1.Items.Add("74")
        Me.DomainUpDown1.Items.Add("73")
        Me.DomainUpDown1.Items.Add("72")
        Me.DomainUpDown1.Items.Add("71")
        Me.DomainUpDown1.Items.Add("70")
        Me.DomainUpDown1.Items.Add("69")
        Me.DomainUpDown1.Items.Add("68")
        Me.DomainUpDown1.Items.Add("67")
        Me.DomainUpDown1.Items.Add("66")
        Me.DomainUpDown1.Items.Add("65")
        Me.DomainUpDown1.Items.Add("64")
        Me.DomainUpDown1.Items.Add("63")
        Me.DomainUpDown1.Items.Add("62")
        Me.DomainUpDown1.Items.Add("61")
        Me.DomainUpDown1.Items.Add("60")
        Me.DomainUpDown1.Items.Add("59")
        Me.DomainUpDown1.Items.Add("58")
        Me.DomainUpDown1.Items.Add("57")
        Me.DomainUpDown1.Items.Add("56")
        Me.DomainUpDown1.Items.Add("55")
        Me.DomainUpDown1.Items.Add("54")
        Me.DomainUpDown1.Items.Add("53")
        Me.DomainUpDown1.Items.Add("52")
        Me.DomainUpDown1.Items.Add("51")
        Me.DomainUpDown1.Items.Add("50")
        Me.DomainUpDown1.Items.Add("49")
        Me.DomainUpDown1.Items.Add("48")
        Me.DomainUpDown1.Items.Add("47")
        Me.DomainUpDown1.Items.Add("46")
        Me.DomainUpDown1.Items.Add("45")
        Me.DomainUpDown1.Items.Add("44")
        Me.DomainUpDown1.Items.Add("43")
        Me.DomainUpDown1.Items.Add("42")
        Me.DomainUpDown1.Items.Add("41")
        Me.DomainUpDown1.Items.Add("40")
        Me.DomainUpDown1.Items.Add("39")
        Me.DomainUpDown1.Items.Add("38")
        Me.DomainUpDown1.Items.Add("37")
        Me.DomainUpDown1.Items.Add("36")
        Me.DomainUpDown1.Items.Add("35")
        Me.DomainUpDown1.Items.Add("34")
        Me.DomainUpDown1.Items.Add("33")
        Me.DomainUpDown1.Items.Add("32")
        Me.DomainUpDown1.Items.Add("31")
        Me.DomainUpDown1.Items.Add("30")
        Me.DomainUpDown1.Items.Add("29")
        Me.DomainUpDown1.Items.Add("28")
        Me.DomainUpDown1.Items.Add("27")
        Me.DomainUpDown1.Items.Add("26")
        Me.DomainUpDown1.Items.Add("25")
        Me.DomainUpDown1.Items.Add("24")
        Me.DomainUpDown1.Items.Add("23")
        Me.DomainUpDown1.Items.Add("22")
        Me.DomainUpDown1.Items.Add("21")
        Me.DomainUpDown1.Items.Add("20")
        Me.DomainUpDown1.Items.Add("19")
        Me.DomainUpDown1.Items.Add("18")
        Me.DomainUpDown1.Items.Add("17")
        Me.DomainUpDown1.Items.Add("16")
        Me.DomainUpDown1.Items.Add("15")
        Me.DomainUpDown1.Items.Add("14")
        Me.DomainUpDown1.Items.Add("13")
        Me.DomainUpDown1.Items.Add("12")
        Me.DomainUpDown1.Items.Add("11")
        Me.DomainUpDown1.Items.Add("10")
        Me.DomainUpDown1.Items.Add("9")
        Me.DomainUpDown1.Items.Add("8")
        Me.DomainUpDown1.Items.Add("7")
        Me.DomainUpDown1.Items.Add("6")
        Me.DomainUpDown1.Items.Add("5")
        Me.DomainUpDown1.Items.Add("4")
        Me.DomainUpDown1.Items.Add("3")
        Me.DomainUpDown1.Items.Add("2")
        Me.DomainUpDown1.Items.Add("1")
        Me.DomainUpDown1.Location = New System.Drawing.Point(88, 22)
        Me.DomainUpDown1.Name = "DomainUpDown1"
        Me.DomainUpDown1.ReadOnly = True
        Me.DomainUpDown1.Size = New System.Drawing.Size(39, 21)
        Me.DomainUpDown1.TabIndex = 1
        Me.DomainUpDown1.Text = "1"
        '
        'TextBox风险指数
        '
        Me.TextBox风险指数.Location = New System.Drawing.Point(18, 291)
        Me.TextBox风险指数.Multiline = True
        Me.TextBox风险指数.Name = "TextBox风险指数"
        Me.TextBox风险指数.ReadOnly = True
        Me.TextBox风险指数.Size = New System.Drawing.Size(204, 115)
        Me.TextBox风险指数.TabIndex = 29
        Me.TextBox风险指数.Text = "(级数越高，地震影响越大）" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(15, 31)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(71, 12)
        Me.Label39.TabIndex = 22
        Me.Label39.Text = "一年仅发生 "
        '
        'Label62
        '
        Me.Label62.AutoSize = True
        Me.Label62.Location = New System.Drawing.Point(15, 273)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(89, 12)
        Me.Label62.TabIndex = 28
        Me.Label62.Text = "地震风险指数："
        '
        'TextBox城市小于4级概率
        '
        Me.TextBox城市小于4级概率.Location = New System.Drawing.Point(56, 64)
        Me.TextBox城市小于4级概率.Name = "TextBox城市小于4级概率"
        Me.TextBox城市小于4级概率.ReadOnly = True
        Me.TextBox城市小于4级概率.Size = New System.Drawing.Size(94, 21)
        Me.TextBox城市小于4级概率.TabIndex = 25
        '
        'TextBox城市大于6级概率
        '
        Me.TextBox城市大于6级概率.Location = New System.Drawing.Point(56, 223)
        Me.TextBox城市大于6级概率.Name = "TextBox城市大于6级概率"
        Me.TextBox城市大于6级概率.ReadOnly = True
        Me.TextBox城市大于6级概率.Size = New System.Drawing.Size(94, 21)
        Me.TextBox城市大于6级概率.TabIndex = 27
        '
        'Label60
        '
        Me.Label60.AutoSize = True
        Me.Label60.Location = New System.Drawing.Point(15, 109)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(65, 12)
        Me.Label60.TabIndex = 23
        Me.Label60.Text = "一年仅发生"
        '
        'Label61
        '
        Me.Label61.AutoSize = True
        Me.Label61.Location = New System.Drawing.Point(15, 190)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(65, 12)
        Me.Label61.TabIndex = 24
        Me.Label61.Text = "一年仅发生"
        '
        'TextBox城市4到6级概率
        '
        Me.TextBox城市4到6级概率.Location = New System.Drawing.Point(56, 142)
        Me.TextBox城市4到6级概率.Name = "TextBox城市4到6级概率"
        Me.TextBox城市4到6级概率.ReadOnly = True
        Me.TextBox城市4到6级概率.Size = New System.Drawing.Size(94, 21)
        Me.TextBox城市4到6级概率.TabIndex = 26
        '
        'DataGridView5
        '
        Me.DataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView5.Location = New System.Drawing.Point(6, 61)
        Me.DataGridView5.Name = "DataGridView5"
        Me.DataGridView5.RowTemplate.Height = 27
        Me.DataGridView5.Size = New System.Drawing.Size(654, 412)
        Me.DataGridView5.TabIndex = 21
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(666, 33)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(83, 12)
        Me.Label31.TabIndex = 15
        Me.Label31.Text = "6级以上地震："
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(433, 33)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(71, 12)
        Me.Label30.TabIndex = 14
        Me.Label30.Text = "4-6级地震："
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(203, 33)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(83, 12)
        Me.Label29.TabIndex = 13
        Me.Label29.Text = "4级以下地震："
        '
        'TextBox城市风险大于六
        '
        Me.TextBox城市风险大于六.Location = New System.Drawing.Point(777, 30)
        Me.TextBox城市风险大于六.Name = "TextBox城市风险大于六"
        Me.TextBox城市风险大于六.ReadOnly = True
        Me.TextBox城市风险大于六.Size = New System.Drawing.Size(101, 21)
        Me.TextBox城市风险大于六.TabIndex = 12
        '
        'TextBox城市风险四到六
        '
        Me.TextBox城市风险四到六.Location = New System.Drawing.Point(530, 30)
        Me.TextBox城市风险四到六.Name = "TextBox城市风险四到六"
        Me.TextBox城市风险四到六.ReadOnly = True
        Me.TextBox城市风险四到六.Size = New System.Drawing.Size(104, 21)
        Me.TextBox城市风险四到六.TabIndex = 11
        '
        'TextBox城市风险小于四
        '
        Me.TextBox城市风险小于四.Location = New System.Drawing.Point(314, 30)
        Me.TextBox城市风险小于四.Name = "TextBox城市风险小于四"
        Me.TextBox城市风险小于四.ReadOnly = True
        Me.TextBox城市风险小于四.Size = New System.Drawing.Size(98, 21)
        Me.TextBox城市风险小于四.TabIndex = 10
        '
        'TextBox城市风险地震数
        '
        Me.TextBox城市风险地震数.Location = New System.Drawing.Point(91, 30)
        Me.TextBox城市风险地震数.Name = "TextBox城市风险地震数"
        Me.TextBox城市风险地震数.ReadOnly = True
        Me.TextBox城市风险地震数.Size = New System.Drawing.Size(94, 21)
        Me.TextBox城市风险地震数.TabIndex = 9
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(13, 33)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(65, 12)
        Me.Label28.TabIndex = 8
        Me.Label28.Text = "地震总数："
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(13, 33)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(0, 12)
        Me.Label25.TabIndex = 4
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DodgerBlue
        Me.Button2.ForeColor = System.Drawing.Color.White
        Me.Button2.Location = New System.Drawing.Point(427, 43)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(96, 29)
        Me.Button2.TabIndex = 29
        Me.Button2.Text = "显示地图"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'TextBox城市纬度查询
        '
        Me.TextBox城市纬度查询.Location = New System.Drawing.Point(253, 40)
        Me.TextBox城市纬度查询.Name = "TextBox城市纬度查询"
        Me.TextBox城市纬度查询.ReadOnly = True
        Me.TextBox城市纬度查询.Size = New System.Drawing.Size(121, 21)
        Me.TextBox城市纬度查询.TabIndex = 5
        '
        'TextBox城市经度查询
        '
        Me.TextBox城市经度查询.Location = New System.Drawing.Point(63, 40)
        Me.TextBox城市经度查询.Name = "TextBox城市经度查询"
        Me.TextBox城市经度查询.ReadOnly = True
        Me.TextBox城市经度查询.Size = New System.Drawing.Size(127, 21)
        Me.TextBox城市经度查询.TabIndex = 4
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(16, 43)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(41, 12)
        Me.Label24.TabIndex = 3
        Me.Label24.Text = "经度："
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(206, 43)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(41, 12)
        Me.Label23.TabIndex = 2
        Me.Label23.Text = "纬度："
        '
        'ComboBox城市查询
        '
        Me.ComboBox城市查询.FormattingEnabled = True
        Me.ComboBox城市查询.Location = New System.Drawing.Point(207, 11)
        Me.ComboBox城市查询.Name = "ComboBox城市查询"
        Me.ComboBox城市查询.Size = New System.Drawing.Size(121, 20)
        Me.ComboBox城市查询.TabIndex = 1
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(16, 14)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(185, 12)
        Me.Label22.TabIndex = 0
        Me.Label22.Text = "请选择城市或双击地图中某一位置"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(437, 14)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(65, 12)
        Me.Label27.TabIndex = 6
        Me.Label27.Text = "数据来源："
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(635, 14)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(89, 12)
        Me.Label26.TabIndex = 5
        Me.Label26.Text = "年该地地震数据"
        '
        'TabPage5
        '
        Me.TabPage5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TabPage5.Controls.Add(Me.Label48)
        Me.TabPage5.Controls.Add(Me.Label47)
        Me.TabPage5.Controls.Add(Me.Label46)
        Me.TabPage5.Controls.Add(Me.Label45)
        Me.TabPage5.Controls.Add(Me.Label44)
        Me.TabPage5.Controls.Add(Me.Label21)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(926, 1184)
        Me.TabPage5.TabIndex = 4
        Me.TabPage5.Text = "相关说明"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label48.Location = New System.Drawing.Point(70, 424)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(824, 208)
        Me.Label48.TabIndex = 5
        Me.Label48.Text = resources.GetString("Label48.Text")
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label47.Location = New System.Drawing.Point(52, 408)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(93, 16)
        Me.Label47.TabIndex = 4
        Me.Label47.Text = "算法说明："
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label46.Location = New System.Drawing.Point(70, 185)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(704, 176)
        Me.Label46.TabIndex = 3
        Me.Label46.Text = resources.GetString("Label46.Text")
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label45.Location = New System.Drawing.Point(53, 169)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(93, 16)
        Me.Label45.TabIndex = 2
        Me.Label45.Text = "使用说明："
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label44.Location = New System.Drawing.Point(70, 46)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(744, 80)
        Me.Label44.TabIndex = 1
        Me.Label44.Text = "1.在""后台数据预览""中，图形可能因界面移动而缺损；只需离开界面再重新进入便可重新显示图形。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "2.在""城市分析按评估""中，也可能出现曲线缺损情况；此时需要重" & _
    "新点击""开始评估""按钮重新生成曲线。" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "3.本数据库可以储存全球的天然地震信息，但地图显示功能只显示中国范围内的天然地震。"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label21.Location = New System.Drawing.Point(52, 30)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(93, 16)
        Me.Label21.TabIndex = 0
        Me.Label21.Text = "常见问题："
        '
        'Timer1
        '
        Me.Timer1.Interval = 10
        '
        'Timer2
        '
        '
        'Timer3
        '
        '
        'Label93
        '
        Me.Label93.AutoSize = True
        Me.Label93.Location = New System.Drawing.Point(809, 1144)
        Me.Label93.Name = "Label93"
        Me.Label93.Size = New System.Drawing.Size(29, 12)
        Me.Label93.TabIndex = 64
        Me.Label93.Text = "年份"
        '
        'Label94
        '
        Me.Label94.AutoSize = True
        Me.Label94.Location = New System.Drawing.Point(861, 1144)
        Me.Label94.Name = "Label94"
        Me.Label94.Size = New System.Drawing.Size(29, 12)
        Me.Label94.TabIndex = 65
        Me.Label94.Text = "年份"
        '
        'Label95
        '
        Me.Label95.AutoSize = True
        Me.Label95.Location = New System.Drawing.Point(845, 1144)
        Me.Label95.Name = "Label95"
        Me.Label95.Size = New System.Drawing.Size(17, 12)
        Me.Label95.TabIndex = 66
        Me.Label95.Text = "到"
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._2669c2f13c906965e862b251146994b6_1_
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1165, 749)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "地震记录查询系统"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DataGridView5, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox数据总量 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox纬度跨度上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox经度跨度上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox时间跨度下限 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox震级查询上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox震级查询下限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox经度查询下限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox经度查询上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox纬度查询上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox纬度查询下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents TextBox城市纬度查询 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox城市经度查询 As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents ComboBox城市查询 As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents TextBox城市风险大于六 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox城市风险四到六 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox城市风险小于四 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox城市风险地震数 As System.Windows.Forms.TextBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents ComboBox时间查询上限 As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox时间查询下限 As System.Windows.Forms.ComboBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents TextBox大于六比重 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox四到六比重 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox小于四级百分比 As System.Windows.Forms.TextBox
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents TextBox大于六数量 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox四到六数量 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox小于四级数量 As System.Windows.Forms.TextBox
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents TextBox时间跨度上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox经度跨度下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents TextBox纬度跨度下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents DataGridView4 As System.Windows.Forms.DataGridView
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents DataGridView5 As System.Windows.Forms.DataGridView
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents ComboBox城市风险年份 As System.Windows.Forms.ComboBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox风险指数 As System.Windows.Forms.TextBox
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents TextBox城市小于4级概率 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox城市大于6级概率 As System.Windows.Forms.TextBox
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents TextBox城市4到6级概率 As System.Windows.Forms.TextBox
    Friend WithEvents DomainUpDown1 As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDown3 As System.Windows.Forms.DomainUpDown
    Friend WithEvents DomainUpDown2 As System.Windows.Forms.DomainUpDown
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Labelq As System.Windows.Forms.Label
    Friend WithEvents Labely As System.Windows.Forms.Label
    Friend WithEvents Labele As System.Windows.Forms.Label
    Friend WithEvents Labelr As System.Windows.Forms.Label
    Friend WithEvents Labelw As System.Windows.Forms.Label
    Friend WithEvents Labelt As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents Label88 As System.Windows.Forms.Label
    Friend WithEvents Label89 As System.Windows.Forms.Label
    Friend WithEvents Label90 As System.Windows.Forms.Label
    Friend WithEvents Label91 As System.Windows.Forms.Label
    Friend WithEvents Label92 As System.Windows.Forms.Label
    Friend WithEvents Label95 As System.Windows.Forms.Label
    Friend WithEvents Label94 As System.Windows.Forms.Label
    Friend WithEvents Label93 As System.Windows.Forms.Label
End Class
