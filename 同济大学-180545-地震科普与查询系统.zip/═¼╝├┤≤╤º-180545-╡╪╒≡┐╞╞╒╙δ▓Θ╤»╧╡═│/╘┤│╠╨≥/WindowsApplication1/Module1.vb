﻿Module Module1
    Public k% = 0
End Module
