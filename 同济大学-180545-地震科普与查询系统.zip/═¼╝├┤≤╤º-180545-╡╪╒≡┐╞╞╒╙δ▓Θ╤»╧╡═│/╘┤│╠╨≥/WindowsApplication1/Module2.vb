﻿Module Module2
    Public co As String

End Module
