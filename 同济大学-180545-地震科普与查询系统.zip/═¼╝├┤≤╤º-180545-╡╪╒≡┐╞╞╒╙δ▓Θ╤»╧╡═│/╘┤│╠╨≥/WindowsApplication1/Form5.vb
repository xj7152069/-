﻿Imports System.Data.SqlClient
Imports System.Math
Public Class Form5
    Dim myconn As New SqlConnection("initial catalog=china earthquake;data source=10.10.109.119;user id=tj5;password=db18-5")
    Dim mydataset As New DataSet
    Dim mybind As New BindingSource
    Dim c(16000), b(16000), d(16000) As Single
    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
      
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Dim x, y As Single
        x = (Control.MousePosition.X - 6 - Me.Location.X) / 18.2 + 73.024
        y = 54.538 - (Control.MousePosition.Y - 33 - Me.Location.Y) / 18.2
        Dim str1 As String = "select ltrim(rtrim(城市名称)) from city where 纬度>='" & y - 1 & "' and 纬度<='" & y + 1 & "' and 经度>='" & x - 1 & "'and 经度<='" & x + 1 & "'"
        Dim myad1 As New SqlDataAdapter(str1, myconn)
        myad1.Fill(mydataset, "城市")
        Dim c As String
        c = "附近的城市有："
        For i = 0 To mydataset.Tables("城市").Rows.Count - 1
            c = c & mydataset.Tables("城市").Rows(i).Item(0) & " "
        Next
        mydataset.Tables("城市").Clear()
        Dim toolTip1 As New ToolTip()
        toolTip1.AutoPopDelay = 5000
        toolTip1.InitialDelay = 100
        toolTip1.ReshowDelay = 500
        toolTip1.ShowAlways = True
        toolTip1.SetToolTip(PictureBox1, c)
    End Sub

    Private Sub PictureBox1_DoubleClick(sender As Object, e As EventArgs) Handles PictureBox1.DoubleClick
        Dim x, y As Single
        If k = 4 Then
            x = (Control.MousePosition.X - 6 - Me.Location.X) / 18.2 + 73.024
            y = 54.538 - (Control.MousePosition.Y - 33 - Me.Location.Y) / 18.2
            Me.Label经度.Text = x
            Me.Label纬度.Text = y
            Form1.TextBox城市经度查询.Text = x
            Form1.TextBox城市纬度查询.Text = y
            Form1.Focus()
            Form1.ComboBox城市查询.Text = ""
        End If
    End Sub

    Private Sub PictureBox1_MouseClick(sender As Object, e As MouseEventArgs) Handles PictureBox1.MouseClick
       
    End Sub
End Class