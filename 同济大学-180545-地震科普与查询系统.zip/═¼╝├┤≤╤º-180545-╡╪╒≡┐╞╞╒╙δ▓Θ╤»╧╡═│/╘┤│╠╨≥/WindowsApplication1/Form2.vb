﻿Imports System.Data.SqlClient
Imports System.Math
Public Class Form2
    Dim myconn As New SqlConnection("initial catalog=china earthquake;data source=10.10.109.119;user id=tj5;password=db18-5")
    Dim mydataset As New DataSet
    Dim mybind As New BindingSource
    Dim c(16000), b(16000), d(16000) As Single

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If k = 13 Then
            MsgBox("后台无地震数据，此功能将无法使用；添加数据后重启系统便可使用此功能")
        Else
            Form1.Show()
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.GroupBox1.Visible = True
        Me.TextBox1.Focus()
    End Sub

    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        MaximizeBox = False
        Dim str1 As String = "select * from earthquake"
        Dim myad1 As New SqlDataAdapter(str1, myconn)
        myad1.Fill(mydataset, "t1")
        Dim str2 As String = "select min(时间) as Q,max(时间) as W,min(经度) as E,max(经度) as R,min(纬度) as T,max(纬度) as Y from earthquake"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t2")
        If mydataset.Tables("t1").Rows.Count < 2 Then
            k = 13
        Else
            Me.TextBox时间跨度下限.Text = mydataset.Tables("t2").Rows(0).Item("Q")
            Me.TextBox时间跨度上限.Text = mydataset.Tables("t2").Rows(0).Item("W")
            Me.TextBox经度跨度下限.Text = mydataset.Tables("t2").Rows(0).Item("E")
            Me.TextBox经度跨度上限.Text = mydataset.Tables("t2").Rows(0).Item("R")
            Me.TextBox纬度跨度下限.Text = mydataset.Tables("t2").Rows(0).Item("T")
            Me.TextBox纬度跨度上限.Text = mydataset.Tables("t2").Rows(0).Item("Y")
        End If
        mydataset.Tables("t2").Clear()
        Me.TextBox1.PasswordChar = "*"
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        Me.GroupBox1.Visible = False
    End Sub

    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox1.Text = "715206" Then
            Form4.Show()
            Form1.Close()
            Form6.Close()
            Me.GroupBox1.Visible = False
        Else
            MsgBox("口令错误")
        End If
        Me.TextBox1.Clear()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Form6.Show()
    End Sub
End Class