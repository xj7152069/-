﻿Imports System.Data.SqlClient
Imports System.Math
Public Class Form3
    Dim myconn As New SqlConnection("initial catalog=china earthquake;data source=10.10.109.119;user id=tj5;password=db18-5")
    Dim mydataset As New DataSet
    Dim mybind As New BindingSource
    Dim s As Single
    Dim c(16000), b(16000), d(16000), m(20, 35) As Single
    Dim t(16000), pl(16000) As String

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        FormBorderStyle = Windows.Forms.FormBorderStyle.Fixed3D
        Me.MaximizeBox = False
        Dim str1 As String = "select * from earthquake"
        Dim myad1 As New SqlDataAdapter(str1, myconn)
        myad1.Fill(mydataset, "所有数据1")
        myad1.Fill(mydataset, "筛选")
        Dim str3 As String = "select * from earthquake where 时间>='" & Form1.ComboBox时间查询下限.Text & "' and 时间<='" & Form1.ComboBox时间查询上限.Text & "' and 纬度>='" & Form1.TextBox纬度查询下限.Text & "' and 纬度<='" & Form1.TextBox纬度查询上限.Text & "' and 经度>='" & Form1.TextBox经度查询下限.Text & "'and 经度<='" & Form1.TextBox经度查询上限.Text & "' and 震级>='" & Form1.TextBox震级查询下限.Text & "' and 震级<='" & Form1.TextBox震级查询上限.Text & "'"
        Dim myad3 As New SqlDataAdapter(str3, myconn)
        myad3.Fill(mydataset, "查询1")
        Dim str5 As String = "select * from earthquake where 纬度>='" & Form1.TextBox城市纬度查询.Text - 1.5 & "' and 纬度<='" & Form1.TextBox城市纬度查询.Text + 1.5 & "' and 经度>='" & Form1.TextBox城市经度查询.Text - 1.5 & "'and 经度<='" & Form1.TextBox城市经度查询.Text + 1.5 & "' and left(ltrim(时间),4)='" & Form1.ComboBox城市风险年份.Text & "'"
        Dim myad5 As New SqlDataAdapter(str5, myconn)
        myad5.Fill(mydataset, "城市1")
        s = Round((mydataset.Tables("所有数据1").Rows.Count / 24000) * 7.5, 2)
    End Sub

    Protected Sub LzBt_click(ByVal sender As Object, ByVal e As EventArgs)
        Dim na = DirectCast(sender, Label).Text
        Labelt.Text = na
    End Sub
 

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If k = 1 Then
            Me.GroupBox1.Visible = True
            ReDim c(16000), b(16000), d(16000), t(16000), pl(16000)
            For i = 1 To mydataset.Tables("所有数据1").Rows.Count
                c(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("经度")
                b(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("纬度")
                d(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("震级")
                t(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("时间")
                pl(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("区域位置")
            Next
            Me.Timer1.Start()
        ElseIf k = 2 Then
            Me.GroupBox1.Visible = True
            ReDim c(16000), b(16000), d(16000), t(16000), pl(16000)
            For i = 1 To mydataset.Tables("查询1").Rows.Count
                c(i) = mydataset.Tables("查询1").Rows(i - 1).Item("经度")
                b(i) = mydataset.Tables("查询1").Rows(i - 1).Item("纬度")
                d(i) = mydataset.Tables("查询1").Rows(i - 1).Item("震级")
                t(i) = mydataset.Tables("查询1").Rows(i - 1).Item("时间")
                pl(i) = mydataset.Tables("查询1").Rows(i - 1).Item("区域位置")
            Next
            Me.Timer2.Start()
        ElseIf k = 5 Then
            Me.Label10.Visible = True
            ReDim c(16000), b(16000), d(16000), t(16000), pl(16000)
            For i = 1 To mydataset.Tables("城市1").Rows.Count
                c(i) = mydataset.Tables("城市1").Rows(i - 1).Item("经度")
                b(i) = mydataset.Tables("城市1").Rows(i - 1).Item("纬度")
                d(i) = mydataset.Tables("城市1").Rows(i - 1).Item("震级")
                t(i) = mydataset.Tables("城市1").Rows(i - 1).Item("时间")
                pl(i) = mydataset.Tables("城市1").Rows(i - 1).Item("区域位置")
            Next
            Me.Timer3.Start()
        ElseIf k = 7 Then
            Me.Label12.Visible = True
            form7.Show()
            form7.ProgressBar1.Minimum = 0
            form7.ProgressBar1.Maximum = 11200
            form7.ProgressBar1.Value = 0
            Dim s1%
            s1 = 0
            ReDim c(16000), b(16000), m(80, 140)
            For i = 1 To mydataset.Tables("所有数据1").Rows.Count
                c(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("经度")
                b(i) = mydataset.Tables("所有数据1").Rows(i - 1).Item("纬度")
            Next
            For i = 1 To 80
                For j = 1 To 140
                    For p = 1 To mydataset.Tables("所有数据1").Rows.Count
                        If c(p) >= 70 + j * 0.5 - 0.25 And c(p) < 70 + j * 0.5 + 0.25 And b(p) >= 15 + i * 0.5 - 0.25 And b(p) < i * 0.5 + 15 + 0.25 Then
                            s1 = s1 + 1
                        End If
                    Next
                    If s1 >= s Then
                        m(i, j) = 1
                    Else
                        m(i, j) = 0
                    End If
                    s1 = 0
                    form7.ProgressBar1.Value = form7.ProgressBar1.Value + 1
                Next
            Next
            form7.Close()
            Me.Timer4.Start()
        End If

    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        ProgressBar1.Minimum = 0
        ProgressBar1.Maximum = mydataset.Tables("所有数据1").Rows.Count
        ProgressBar1.Value = 0
        For i = 1 To mydataset.Tables("所有数据1").Rows.Count
            ProgressBar1.Value = i
            If c(i) >= 50 And c(i) <= 136 And b(i) >= 12 And b(i) <= 55 Then
                Dim a As New Label
                Me.Controls.Add(a)
                a.Text = vbCrLf & vbCrLf & "基本信息:" & "经度：" & c(i) & vbCrLf & "纬度：" & b(i) & vbCrLf & "震级：" & d(i) & vbCrLf & "位置：" & pl(i) & vbCrLf & "时间：" & t(i)
                a.Left = (Int((c(i) - 73.024) * 20.4 - d(i) * 2))
                a.Top = (Int((54.538 - b(i)) * 20.4 - d(i) * 2))
                a.BorderStyle = BorderStyle.Fixed3D
                a.Width = d(i) * 4
                a.Height = d(i) * 4
                If d(i) < 4 Then
                    a.BackColor = Color.Blue
                ElseIf d(i) >= 4 And d(i) < 6 Then
                    a.BackColor = Color.Orange
                ElseIf d(i) >= 6 Then
                    a.BackColor = Color.Red
                End If
                a.BringToFront()

                AddHandler a.Click, New EventHandler(AddressOf LzBt_Click)
            End If
            If i = mydataset.Tables("所有数据1").Rows.Count Then
                Me.Label10.Visible = True
                Me.GroupBox1.Visible = False
                Me.Timer1.Stop()
            End If
        Next
    End Sub


    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        Me.GroupBox1.Visible = True
        ProgressBar1.Minimum = 0
        ProgressBar1.Maximum = mydataset.Tables("查询1").Rows.Count
        ProgressBar1.Value = 0
        For i = 1 To mydataset.Tables("查询1").Rows.Count
            If c(i) >= 50 And c(i) <= 136 And b(i) >= 12 And b(i) <= 55 Then
                Dim a As New Label
                Me.Controls.Add(a)
                a.Text = vbCrLf & vbCrLf & "基本信息:" & "经度：" & c(i) & vbCrLf & "纬度：" & b(i) & vbCrLf & "震级：" & d(i) & vbCrLf & "位置：" & pl(i) & vbCrLf & "时间：" & t(i)
                a.Left = (Int((c(i) - 73.024) * 20.4 - d(i) * 2))
                a.Top = (Int((54.538 - b(i)) * 20.4 - d(i) * 2))
                a.BorderStyle = BorderStyle.Fixed3D
                a.Width = d(i) * 4
                a.Height = d(i) * 4
                If d(i) < 4 Then
                    a.BackColor = Color.Blue
                ElseIf d(i) >= 4 And d(i) < 6 Then
                    a.BackColor = Color.Orange
                ElseIf d(i) >= 6 Then
                    a.BackColor = Color.Red
                End If
                a.BringToFront()
                AddHandler a.Click, New EventHandler(AddressOf LzBt_Click)
            End If
            ProgressBar1.Value = i
            If i = mydataset.Tables("查询1").Rows.Count Then
                Me.Label10.Visible = True
                Me.GroupBox1.Visible = False
                Me.Timer2.Stop()
            End If
        Next
    End Sub


    Private Sub Timer3_Tick(sender As Object, e As EventArgs) Handles Timer3.Tick
        form7.Show()
        form7.ProgressBar1.Minimum = 0
        form7.ProgressBar1.Maximum = mydataset.Tables("城市1").Rows.Count
        form7.ProgressBar1.Value = 0
        For i = 1 To mydataset.Tables("城市1").Rows.Count
            If c(i) >= 50 And c(i) <= 136 And b(i) >= 12 And b(i) <= 55 Then
                Dim a As New Label
                Me.Controls.Add(a)
                a.Text = vbCrLf & vbCrLf & "基本信息:" & "经度：" & c(i) & vbCrLf & "纬度：" & b(i) & vbCrLf & "震级：" & d(i) & vbCrLf & "位置：" & pl(i) & vbCrLf & "时间：" & t(i)
                a.Left = (Int((c(i) - 73.024) * 20.4 - d(i) * 2))
                a.Top = (Int((54.538 - b(i)) * 20.4 - d(i) * 2))
                a.BorderStyle = BorderStyle.Fixed3D
                a.Width = d(i) * 4
                a.Height = d(i) * 4
                If d(i) < 4 Then
                    a.BackColor = Color.Blue
                ElseIf d(i) >= 4 And d(i) < 6 Then
                    a.BackColor = Color.Orange
                ElseIf d(i) >= 6 Then
                    a.BackColor = Color.Red
                End If
                a.BringToFront()
                AddHandler a.Click, New EventHandler(AddressOf LzBt_Click)
            End If
            form7.ProgressBar1.Value = i
            If i = mydataset.Tables("城市1").Rows.Count Then
                Me.Timer3.Stop()
                form7.Close()
            End If
        Next
    End Sub

    Private Sub Timer4_Tick(sender As Object, e As EventArgs) Handles Timer4.Tick
        form7.Show()
        form7.ProgressBar1.Minimum = 0
        form7.ProgressBar1.Maximum = 11200
        form7.ProgressBar1.Value = 0
        For i = 1 To 80
            For j = 1 To 140
                If m(i, j) = 1 Then
                    Dim a As New Label
                    Me.Controls.Add(a)
                    a.Text = ""
                    a.Left = (Int((70 + j * 0.5 - 73.024) * 20.4)) - 5
                    a.Top = (Int((54.538 - 15 - i * 0.5) * 20.4)) - 5
                    a.BorderStyle = BorderStyle.Fixed3D
                    a.Width = 10
                    a.Height = 10
                    a.BackColor = Color.Red
                    a.BringToFront()
                End If
                form7.ProgressBar1.Value = form7.ProgressBar1.Value + 1
            Next
        Next
        Me.Timer4.Stop()
        form7.Close()
    End Sub

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        Me.Labelt.Text = "此处无相应记录"
    End Sub
End Class