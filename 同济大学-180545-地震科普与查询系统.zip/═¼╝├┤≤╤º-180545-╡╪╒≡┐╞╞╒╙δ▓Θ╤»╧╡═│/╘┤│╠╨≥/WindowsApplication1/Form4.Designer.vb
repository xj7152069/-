﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Labelerr = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label导入 = New System.Windows.Forms.Label()
        Me.Label重复 = New System.Windows.Forms.Label()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Label文件路径 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.DataGridView3 = New System.Windows.Forms.DataGridView()
        Me.TabPage7 = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.TextBox经度添加 = New System.Windows.Forms.TextBox()
        Me.TextBox位置添加 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox时间添加 = New System.Windows.Forms.TextBox()
        Me.TextBox纬度添加 = New System.Windows.Forms.TextBox()
        Me.TextBox深度添加 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox震级添加 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.TabControl3 = New System.Windows.Forms.TabControl()
        Me.TabPage9 = New System.Windows.Forms.TabPage()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.TextBox震级删除上限 = New System.Windows.Forms.TextBox()
        Me.TextBox震级删除下限 = New System.Windows.Forms.TextBox()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.TextBox经度删除上限 = New System.Windows.Forms.TextBox()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.TextBox经度删除下限 = New System.Windows.Forms.TextBox()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.TextBox纬度删除上限 = New System.Windows.Forms.TextBox()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.TextBox纬度删除下限 = New System.Windows.Forms.TextBox()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.ComboBox时间删除上限 = New System.Windows.Forms.ComboBox()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.ComboBox时间删除下限 = New System.Windows.Forms.ComboBox()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TextBox经度删除浏览 = New System.Windows.Forms.TextBox()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.TextBox位置删除浏览 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox时间删除浏览 = New System.Windows.Forms.TextBox()
        Me.TextBox纬度删除浏览 = New System.Windows.Forms.TextBox()
        Me.TextBox深度删除浏览 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.TextBox震级删除浏览 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.ComboBox专题添加 = New System.Windows.Forms.ComboBox()
        Me.TabControl4 = New System.Windows.Forms.TabControl()
        Me.TabPage10 = New System.Windows.Forms.TabPage()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label提示 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.TextBox经度专题添加 = New System.Windows.Forms.TextBox()
        Me.TextBox位置专题添加 = New System.Windows.Forms.TextBox()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.TextBox时间专题添加 = New System.Windows.Forms.TextBox()
        Me.TextBox纬度专题添加 = New System.Windows.Forms.TextBox()
        Me.TextBox深度专题添加 = New System.Windows.Forms.TextBox()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.TextBox震级专题添加 = New System.Windows.Forms.TextBox()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.TabPage5 = New System.Windows.Forms.TabPage()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.TextBox专题名称 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.TabControl5 = New System.Windows.Forms.TabControl()
        Me.TabPage8 = New System.Windows.Forms.TabPage()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TextBox专题修改经度 = New System.Windows.Forms.TextBox()
        Me.TextBox专题修改位置 = New System.Windows.Forms.TextBox()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.TextBox专题修改时间 = New System.Windows.Forms.TextBox()
        Me.TextBox专题修改纬度 = New System.Windows.Forms.TextBox()
        Me.TextBox专题修改深度 = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.TextBox专题修改震级 = New System.Windows.Forms.TextBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.TabPage16 = New System.Windows.Forms.TabPage()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.TabPage11 = New System.Windows.Forms.TabPage()
        Me.TextBox说明2 = New System.Windows.Forms.TextBox()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Label删除说明2 = New System.Windows.Forms.Label()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.ComboBox删除科普标题 = New System.Windows.Forms.ComboBox()
        Me.Label删除说明3 = New System.Windows.Forms.Label()
        Me.Label删除说明1 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.PictureBox删除说明 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage7.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.TabControl3.SuspendLayout()
        Me.TabPage9.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabControl4.SuspendLayout()
        Me.TabPage10.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage5.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.TabControl5.SuspendLayout()
        Me.TabPage8.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.TabPage16.SuspendLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage11.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage12.SuspendLayout()
        CType(Me.PictureBox删除说明, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Controls.Add(Me.TabPage11)
        Me.TabControl1.Controls.Add(Me.TabPage12)
        Me.TabControl1.Location = New System.Drawing.Point(129, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(783, 682)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TabControl2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(775, 656)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "数据添加"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage7)
        Me.TabControl2.Location = New System.Drawing.Point(29, 25)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(719, 628)
        Me.TabControl2.TabIndex = 0
        '
        'TabPage6
        '
        Me.TabPage6.Controls.Add(Me.GroupBox5)
        Me.TabPage6.Controls.Add(Me.PictureBox2)
        Me.TabPage6.Controls.Add(Me.Label22)
        Me.TabPage6.Controls.Add(Me.Labelerr)
        Me.TabPage6.Controls.Add(Me.Label34)
        Me.TabPage6.Controls.Add(Me.Label33)
        Me.TabPage6.Controls.Add(Me.Label导入)
        Me.TabPage6.Controls.Add(Me.Label重复)
        Me.TabPage6.Controls.Add(Me.Button34)
        Me.TabPage6.Controls.Add(Me.Label文件路径)
        Me.TabPage6.Controls.Add(Me.Label31)
        Me.TabPage6.Controls.Add(Me.Button8)
        Me.TabPage6.Controls.Add(Me.DataGridView3)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(711, 602)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "批量添加"
        Me.TabPage6.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.ProgressBar1)
        Me.GroupBox5.Location = New System.Drawing.Point(132, 135)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(447, 73)
        Me.GroupBox5.TabIndex = 18
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "正在执行当前操作，请稍后"
        Me.GroupBox5.Visible = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(30, 22)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(387, 23)
        Me.ProgressBar1.TabIndex = 0
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), System.Drawing.Image)
        Me.PictureBox2.Location = New System.Drawing.Point(175, 390)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(508, 190)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(26, 568)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(113, 12)
        Me.Label22.TabIndex = 12
        Me.Label22.Text = "错误的数据数量为："
        '
        'Labelerr
        '
        Me.Labelerr.AutoSize = True
        Me.Labelerr.Location = New System.Drawing.Point(86, 584)
        Me.Labelerr.Name = "Labelerr"
        Me.Labelerr.Size = New System.Drawing.Size(29, 12)
        Me.Labelerr.TabIndex = 11
        Me.Labelerr.Text = "（）"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(26, 499)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(125, 12)
        Me.Label34.TabIndex = 10
        Me.Label34.Text = "成功导入的数据量为："
        '
        'Label33
        '
        Me.Label33.AutoSize = True
        Me.Label33.Location = New System.Drawing.Point(26, 536)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(137, 12)
        Me.Label33.TabIndex = 9
        Me.Label33.Text = "与后台重复的数据量为："
        '
        'Label导入
        '
        Me.Label导入.AutoSize = True
        Me.Label导入.Location = New System.Drawing.Point(86, 516)
        Me.Label导入.Name = "Label导入"
        Me.Label导入.Size = New System.Drawing.Size(29, 12)
        Me.Label导入.TabIndex = 8
        Me.Label导入.Text = "（）"
        '
        'Label重复
        '
        Me.Label重复.AutoSize = True
        Me.Label重复.Location = New System.Drawing.Point(86, 552)
        Me.Label重复.Name = "Label重复"
        Me.Label重复.Size = New System.Drawing.Size(29, 12)
        Me.Label重复.TabIndex = 7
        Me.Label重复.Text = "（）"
        '
        'Button34
        '
        Me.Button34.Location = New System.Drawing.Point(27, 446)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(141, 50)
        Me.Button34.TabIndex = 6
        Me.Button34.Text = "导入后台数据库"
        Me.Button34.UseVisualStyleBackColor = True
        '
        'Label文件路径
        '
        Me.Label文件路径.AutoSize = True
        Me.Label文件路径.Location = New System.Drawing.Point(84, 7)
        Me.Label文件路径.Name = "Label文件路径"
        Me.Label文件路径.Size = New System.Drawing.Size(17, 12)
        Me.Label文件路径.TabIndex = 4
        Me.Label文件路径.Text = "()"
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(25, 7)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(53, 12)
        Me.Label31.TabIndex = 2
        Me.Label31.Text = "文件路径"
        '
        'Button8
        '
        Me.Button8.Location = New System.Drawing.Point(27, 390)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(142, 50)
        Me.Button8.TabIndex = 1
        Me.Button8.Text = "选择导入文件"
        Me.Button8.UseVisualStyleBackColor = True
        '
        'DataGridView3
        '
        Me.DataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView3.Location = New System.Drawing.Point(28, 25)
        Me.DataGridView3.Name = "DataGridView3"
        Me.DataGridView3.RowTemplate.Height = 27
        Me.DataGridView3.Size = New System.Drawing.Size(655, 350)
        Me.DataGridView3.TabIndex = 0
        '
        'TabPage7
        '
        Me.TabPage7.Controls.Add(Me.GroupBox2)
        Me.TabPage7.Location = New System.Drawing.Point(4, 22)
        Me.TabPage7.Name = "TabPage7"
        Me.TabPage7.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage7.Size = New System.Drawing.Size(711, 602)
        Me.TabPage7.TabIndex = 1
        Me.TabPage7.Text = "逐条添加"
        Me.TabPage7.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Button24)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Button23)
        Me.GroupBox2.Controls.Add(Me.TextBox经度添加)
        Me.GroupBox2.Controls.Add(Me.TextBox位置添加)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.TextBox时间添加)
        Me.GroupBox2.Controls.Add(Me.TextBox纬度添加)
        Me.GroupBox2.Controls.Add(Me.TextBox深度添加)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.TextBox震级添加)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Location = New System.Drawing.Point(32, 22)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(646, 328)
        Me.GroupBox2.TabIndex = 27
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "基本信息"
        '
        'Button24
        '
        Me.Button24.BackColor = System.Drawing.Color.Cyan
        Me.Button24.Location = New System.Drawing.Point(449, 114)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(105, 44)
        Me.Button24.TabIndex = 52
        Me.Button24.Text = "重新输入"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(102, 42)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 12)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "经度："
        '
        'Button23
        '
        Me.Button23.BackColor = System.Drawing.Color.Cyan
        Me.Button23.Location = New System.Drawing.Point(449, 39)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(105, 44)
        Me.Button23.TabIndex = 51
        Me.Button23.Text = "添加该记录"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'TextBox经度添加
        '
        Me.TextBox经度添加.Location = New System.Drawing.Point(149, 39)
        Me.TextBox经度添加.Name = "TextBox经度添加"
        Me.TextBox经度添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox经度添加.TabIndex = 14
        '
        'TextBox位置添加
        '
        Me.TextBox位置添加.Location = New System.Drawing.Point(149, 241)
        Me.TextBox位置添加.Name = "TextBox位置添加"
        Me.TextBox位置添加.Size = New System.Drawing.Size(207, 21)
        Me.TextBox位置添加.TabIndex = 24
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(102, 86)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 12)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "纬度："
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(78, 244)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(65, 12)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "参考位置："
        '
        'TextBox时间添加
        '
        Me.TextBox时间添加.Location = New System.Drawing.Point(149, 202)
        Me.TextBox时间添加.Name = "TextBox时间添加"
        Me.TextBox时间添加.Size = New System.Drawing.Size(207, 21)
        Me.TextBox时间添加.TabIndex = 23
        '
        'TextBox纬度添加
        '
        Me.TextBox纬度添加.Location = New System.Drawing.Point(149, 83)
        Me.TextBox纬度添加.Name = "TextBox纬度添加"
        Me.TextBox纬度添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox纬度添加.TabIndex = 20
        '
        'TextBox深度添加
        '
        Me.TextBox深度添加.Location = New System.Drawing.Point(149, 164)
        Me.TextBox深度添加.Name = "TextBox深度添加"
        Me.TextBox深度添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox深度添加.TabIndex = 22
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(78, 205)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(65, 12)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "发震时间："
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(102, 130)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 12)
        Me.Label6.TabIndex = 16
        Me.Label6.Text = "震级："
        '
        'TextBox震级添加
        '
        Me.TextBox震级添加.Location = New System.Drawing.Point(149, 127)
        Me.TextBox震级添加.Name = "TextBox震级添加"
        Me.TextBox震级添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox震级添加.TabIndex = 21
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(78, 167)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(65, 12)
        Me.Label7.TabIndex = 17
        Me.Label7.Text = "震源深度："
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.TabControl3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(775, 656)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "数据删除"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'TabControl3
        '
        Me.TabControl3.Controls.Add(Me.TabPage9)
        Me.TabControl3.Location = New System.Drawing.Point(6, 6)
        Me.TabControl3.Name = "TabControl3"
        Me.TabControl3.SelectedIndex = 0
        Me.TabControl3.Size = New System.Drawing.Size(771, 647)
        Me.TabControl3.TabIndex = 1
        '
        'TabPage9
        '
        Me.TabPage9.Controls.Add(Me.GroupBox7)
        Me.TabPage9.Controls.Add(Me.Button15)
        Me.TabPage9.Controls.Add(Me.Label14)
        Me.TabPage9.Controls.Add(Me.Label15)
        Me.TabPage9.Controls.Add(Me.Label16)
        Me.TabPage9.Controls.Add(Me.Label17)
        Me.TabPage9.Controls.Add(Me.DataGridView1)
        Me.TabPage9.Controls.Add(Me.GroupBox4)
        Me.TabPage9.Controls.Add(Me.GroupBox3)
        Me.TabPage9.Location = New System.Drawing.Point(4, 22)
        Me.TabPage9.Name = "TabPage9"
        Me.TabPage9.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage9.Size = New System.Drawing.Size(763, 621)
        Me.TabPage9.TabIndex = 1
        Me.TabPage9.UseVisualStyleBackColor = True
        '
        'Button15
        '
        Me.Button15.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button15.Location = New System.Drawing.Point(585, 557)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(168, 30)
        Me.Button15.TabIndex = 55
        Me.Button15.Text = "删除所有查询到的记录"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(266, 139)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(65, 12)
        Me.Label14.TabIndex = 25
        Me.Label14.Text = "查询结果："
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(350, 139)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(29, 12)
        Me.Label15.TabIndex = 26
        Me.Label15.Text = "共有"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(393, 139)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(65, 12)
        Me.Label16.TabIndex = 27
        Me.Label16.Text = "（记录数）"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(481, 139)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(41, 12)
        Me.Label17.TabIndex = 28
        Me.Label17.Text = "条记录"
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(251, 157)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.RowTemplate.Height = 27
        Me.DataGridView1.Size = New System.Drawing.Size(506, 394)
        Me.DataGridView1.TabIndex = 1
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Button14)
        Me.GroupBox4.Controls.Add(Me.Label58)
        Me.GroupBox4.Controls.Add(Me.TextBox震级删除上限)
        Me.GroupBox4.Controls.Add(Me.TextBox震级删除下限)
        Me.GroupBox4.Controls.Add(Me.Label57)
        Me.GroupBox4.Controls.Add(Me.TextBox经度删除上限)
        Me.GroupBox4.Controls.Add(Me.Label56)
        Me.GroupBox4.Controls.Add(Me.TextBox经度删除下限)
        Me.GroupBox4.Controls.Add(Me.Label55)
        Me.GroupBox4.Controls.Add(Me.TextBox纬度删除上限)
        Me.GroupBox4.Controls.Add(Me.Label54)
        Me.GroupBox4.Controls.Add(Me.TextBox纬度删除下限)
        Me.GroupBox4.Controls.Add(Me.Label53)
        Me.GroupBox4.Controls.Add(Me.ComboBox时间删除上限)
        Me.GroupBox4.Controls.Add(Me.Label52)
        Me.GroupBox4.Controls.Add(Me.ComboBox时间删除下限)
        Me.GroupBox4.Controls.Add(Me.Label51)
        Me.GroupBox4.Location = New System.Drawing.Point(6, 7)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(747, 128)
        Me.GroupBox4.TabIndex = 28
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "查询条件"
        '
        'Button14
        '
        Me.Button14.BackColor = System.Drawing.Color.Cyan
        Me.Button14.Location = New System.Drawing.Point(459, 26)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(122, 30)
        Me.Button14.TabIndex = 49
        Me.Button14.Text = "开始查询"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Label58
        '
        Me.Label58.AutoSize = True
        Me.Label58.Location = New System.Drawing.Point(210, 94)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(17, 12)
        Me.Label58.TabIndex = 44
        Me.Label58.Text = "到"
        '
        'TextBox震级删除上限
        '
        Me.TextBox震级删除上限.Location = New System.Drawing.Point(238, 91)
        Me.TextBox震级删除上限.Name = "TextBox震级删除上限"
        Me.TextBox震级删除上限.Size = New System.Drawing.Size(126, 21)
        Me.TextBox震级删除上限.TabIndex = 43
        '
        'TextBox震级删除下限
        '
        Me.TextBox震级删除下限.Location = New System.Drawing.Point(82, 91)
        Me.TextBox震级删除下限.Name = "TextBox震级删除下限"
        Me.TextBox震级删除下限.Size = New System.Drawing.Size(122, 21)
        Me.TextBox震级删除下限.TabIndex = 42
        '
        'Label57
        '
        Me.Label57.AutoSize = True
        Me.Label57.Location = New System.Drawing.Point(24, 94)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(41, 12)
        Me.Label57.TabIndex = 41
        Me.Label57.Text = "震级："
        '
        'TextBox经度删除上限
        '
        Me.TextBox经度删除上限.Location = New System.Drawing.Point(615, 60)
        Me.TextBox经度删除上限.Name = "TextBox经度删除上限"
        Me.TextBox经度删除上限.Size = New System.Drawing.Size(126, 21)
        Me.TextBox经度删除上限.TabIndex = 40
        '
        'Label56
        '
        Me.Label56.AutoSize = True
        Me.Label56.Location = New System.Drawing.Point(587, 63)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(17, 12)
        Me.Label56.TabIndex = 39
        Me.Label56.Text = "到"
        '
        'TextBox经度删除下限
        '
        Me.TextBox经度删除下限.Location = New System.Drawing.Point(459, 60)
        Me.TextBox经度删除下限.Name = "TextBox经度删除下限"
        Me.TextBox经度删除下限.Size = New System.Drawing.Size(122, 21)
        Me.TextBox经度删除下限.TabIndex = 38
        '
        'Label55
        '
        Me.Label55.AutoSize = True
        Me.Label55.Location = New System.Drawing.Point(401, 63)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(41, 12)
        Me.Label55.TabIndex = 37
        Me.Label55.Text = "经度："
        '
        'TextBox纬度删除上限
        '
        Me.TextBox纬度删除上限.Location = New System.Drawing.Point(238, 60)
        Me.TextBox纬度删除上限.Name = "TextBox纬度删除上限"
        Me.TextBox纬度删除上限.Size = New System.Drawing.Size(126, 21)
        Me.TextBox纬度删除上限.TabIndex = 36
        '
        'Label54
        '
        Me.Label54.AutoSize = True
        Me.Label54.Location = New System.Drawing.Point(210, 63)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(17, 12)
        Me.Label54.TabIndex = 35
        Me.Label54.Text = "到"
        '
        'TextBox纬度删除下限
        '
        Me.TextBox纬度删除下限.Location = New System.Drawing.Point(82, 60)
        Me.TextBox纬度删除下限.Name = "TextBox纬度删除下限"
        Me.TextBox纬度删除下限.Size = New System.Drawing.Size(122, 21)
        Me.TextBox纬度删除下限.TabIndex = 34
        '
        'Label53
        '
        Me.Label53.AutoSize = True
        Me.Label53.Location = New System.Drawing.Point(24, 63)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(41, 12)
        Me.Label53.TabIndex = 33
        Me.Label53.Text = "纬度："
        '
        'ComboBox时间删除上限
        '
        Me.ComboBox时间删除上限.FormattingEnabled = True
        Me.ComboBox时间删除上限.Location = New System.Drawing.Point(256, 31)
        Me.ComboBox时间删除上限.Name = "ComboBox时间删除上限"
        Me.ComboBox时间删除上限.Size = New System.Drawing.Size(146, 20)
        Me.ComboBox时间删除上限.TabIndex = 32
        '
        'Label52
        '
        Me.Label52.AutoSize = True
        Me.Label52.Location = New System.Drawing.Point(228, 34)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(17, 12)
        Me.Label52.TabIndex = 31
        Me.Label52.Text = "到"
        '
        'ComboBox时间删除下限
        '
        Me.ComboBox时间删除下限.FormattingEnabled = True
        Me.ComboBox时间删除下限.Location = New System.Drawing.Point(82, 31)
        Me.ComboBox时间删除下限.Name = "ComboBox时间删除下限"
        Me.ComboBox时间删除下限.Size = New System.Drawing.Size(140, 20)
        Me.ComboBox时间删除下限.TabIndex = 30
        '
        'Label51
        '
        Me.Label51.AutoSize = True
        Me.Label51.Location = New System.Drawing.Point(6, 34)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(65, 12)
        Me.Label51.TabIndex = 2
        Me.Label51.Text = "发震时间："
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button13)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Button7)
        Me.GroupBox3.Controls.Add(Me.Button10)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.TextBox经度删除浏览)
        Me.GroupBox3.Controls.Add(Me.Button9)
        Me.GroupBox3.Controls.Add(Me.TextBox位置删除浏览)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.TextBox时间删除浏览)
        Me.GroupBox3.Controls.Add(Me.TextBox纬度删除浏览)
        Me.GroupBox3.Controls.Add(Me.TextBox深度删除浏览)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.TextBox震级删除浏览)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 141)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(239, 455)
        Me.GroupBox3.TabIndex = 27
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "当前记录"
        '
        'Button13
        '
        Me.Button13.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Button13.Location = New System.Drawing.Point(110, 393)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(112, 37)
        Me.Button13.TabIndex = 54
        Me.Button13.Text = "删除当前记录"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(46, 42)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(41, 12)
        Me.Label8.TabIndex = 13
        Me.Label8.Text = "经度："
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(108, 355)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(114, 32)
        Me.Button7.TabIndex = 49
        Me.Button7.Text = "前往最后一条"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Location = New System.Drawing.Point(107, 314)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(115, 31)
        Me.Button10.TabIndex = 51
        Me.Button10.Text = "下一条"
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(9, 355)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(91, 32)
        Me.Button1.TabIndex = 48
        Me.Button1.Text = "返回第一条"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TextBox经度删除浏览
        '
        Me.TextBox经度删除浏览.Location = New System.Drawing.Point(104, 39)
        Me.TextBox经度删除浏览.Name = "TextBox经度删除浏览"
        Me.TextBox经度删除浏览.ReadOnly = True
        Me.TextBox经度删除浏览.Size = New System.Drawing.Size(122, 21)
        Me.TextBox经度删除浏览.TabIndex = 14
        '
        'Button9
        '
        Me.Button9.Location = New System.Drawing.Point(9, 314)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(85, 31)
        Me.Button9.TabIndex = 50
        Me.Button9.Text = "上一条"
        Me.Button9.UseVisualStyleBackColor = True
        '
        'TextBox位置删除浏览
        '
        Me.TextBox位置删除浏览.Location = New System.Drawing.Point(19, 283)
        Me.TextBox位置删除浏览.Name = "TextBox位置删除浏览"
        Me.TextBox位置删除浏览.ReadOnly = True
        Me.TextBox位置删除浏览.Size = New System.Drawing.Size(207, 21)
        Me.TextBox位置删除浏览.TabIndex = 24
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(46, 86)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 12)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "纬度："
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 265)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 12)
        Me.Label10.TabIndex = 19
        Me.Label10.Text = "参考位置："
        '
        'TextBox时间删除浏览
        '
        Me.TextBox时间删除浏览.Location = New System.Drawing.Point(19, 223)
        Me.TextBox时间删除浏览.Name = "TextBox时间删除浏览"
        Me.TextBox时间删除浏览.ReadOnly = True
        Me.TextBox时间删除浏览.Size = New System.Drawing.Size(207, 21)
        Me.TextBox时间删除浏览.TabIndex = 23
        '
        'TextBox纬度删除浏览
        '
        Me.TextBox纬度删除浏览.Location = New System.Drawing.Point(104, 83)
        Me.TextBox纬度删除浏览.Name = "TextBox纬度删除浏览"
        Me.TextBox纬度删除浏览.ReadOnly = True
        Me.TextBox纬度删除浏览.Size = New System.Drawing.Size(122, 21)
        Me.TextBox纬度删除浏览.TabIndex = 20
        '
        'TextBox深度删除浏览
        '
        Me.TextBox深度删除浏览.Location = New System.Drawing.Point(104, 164)
        Me.TextBox深度删除浏览.Name = "TextBox深度删除浏览"
        Me.TextBox深度删除浏览.ReadOnly = True
        Me.TextBox深度删除浏览.Size = New System.Drawing.Size(122, 21)
        Me.TextBox深度删除浏览.TabIndex = 22
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(16, 205)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(65, 12)
        Me.Label11.TabIndex = 18
        Me.Label11.Text = "发震时间："
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(46, 130)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(41, 12)
        Me.Label12.TabIndex = 16
        Me.Label12.Text = "震级："
        '
        'TextBox震级删除浏览
        '
        Me.TextBox震级删除浏览.Location = New System.Drawing.Point(104, 127)
        Me.TextBox震级删除浏览.Name = "TextBox震级删除浏览"
        Me.TextBox震级删除浏览.ReadOnly = True
        Me.TextBox震级删除浏览.Size = New System.Drawing.Size(122, 21)
        Me.TextBox震级删除浏览.TabIndex = 21
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(16, 167)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(65, 12)
        Me.Label13.TabIndex = 17
        Me.Label13.Text = "震源深度："
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.Button20)
        Me.TabPage3.Controls.Add(Me.Button19)
        Me.TabPage3.Controls.Add(Me.ComboBox专题添加)
        Me.TabPage3.Controls.Add(Me.TabControl4)
        Me.TabPage3.Controls.Add(Me.TextBox专题名称)
        Me.TabPage3.Controls.Add(Me.Label1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(775, 656)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "地震专题添加"
        Me.TabPage3.UseVisualStyleBackColor = True
        '
        'Button20
        '
        Me.Button20.Location = New System.Drawing.Point(601, 51)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(158, 23)
        Me.Button20.TabIndex = 7
        Me.Button20.Text = "返回添加新的专题"
        Me.Button20.UseVisualStyleBackColor = True
        '
        'Button19
        '
        Me.Button19.Location = New System.Drawing.Point(601, 19)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(158, 23)
        Me.Button19.TabIndex = 6
        Me.Button19.Text = "向已有的专题添加信息"
        Me.Button19.UseVisualStyleBackColor = True
        '
        'ComboBox专题添加
        '
        Me.ComboBox专题添加.FormattingEnabled = True
        Me.ComboBox专题添加.Location = New System.Drawing.Point(111, 21)
        Me.ComboBox专题添加.Name = "ComboBox专题添加"
        Me.ComboBox专题添加.Size = New System.Drawing.Size(391, 20)
        Me.ComboBox专题添加.TabIndex = 5
        Me.ComboBox专题添加.Visible = False
        '
        'TabControl4
        '
        Me.TabControl4.Controls.Add(Me.TabPage10)
        Me.TabControl4.Controls.Add(Me.TabPage5)
        Me.TabControl4.Location = New System.Drawing.Point(23, 74)
        Me.TabControl4.Name = "TabControl4"
        Me.TabControl4.SelectedIndex = 0
        Me.TabControl4.Size = New System.Drawing.Size(740, 563)
        Me.TabControl4.TabIndex = 4
        '
        'TabPage10
        '
        Me.TabPage10.Controls.Add(Me.Button16)
        Me.TabPage10.Controls.Add(Me.GroupBox1)
        Me.TabPage10.Location = New System.Drawing.Point(4, 22)
        Me.TabPage10.Name = "TabPage10"
        Me.TabPage10.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage10.Size = New System.Drawing.Size(732, 537)
        Me.TabPage10.TabIndex = 0
        Me.TabPage10.Text = "基本信息"
        Me.TabPage10.UseVisualStyleBackColor = True
        '
        'Button16
        '
        Me.Button16.Location = New System.Drawing.Point(29, 295)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(214, 44)
        Me.Button16.TabIndex = 5
        Me.Button16.Text = "添加标题和基本信息"
        Me.Button16.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label提示)
        Me.GroupBox1.Controls.Add(Me.Label44)
        Me.GroupBox1.Controls.Add(Me.TextBox经度专题添加)
        Me.GroupBox1.Controls.Add(Me.TextBox位置专题添加)
        Me.GroupBox1.Controls.Add(Me.Label45)
        Me.GroupBox1.Controls.Add(Me.Label49)
        Me.GroupBox1.Controls.Add(Me.TextBox时间专题添加)
        Me.GroupBox1.Controls.Add(Me.TextBox纬度专题添加)
        Me.GroupBox1.Controls.Add(Me.TextBox深度专题添加)
        Me.GroupBox1.Controls.Add(Me.Label48)
        Me.GroupBox1.Controls.Add(Me.Label46)
        Me.GroupBox1.Controls.Add(Me.TextBox震级专题添加)
        Me.GroupBox1.Controls.Add(Me.Label47)
        Me.GroupBox1.Location = New System.Drawing.Point(29, 22)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(672, 255)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        '
        'Label提示
        '
        Me.Label提示.Font = New System.Drawing.Font("宋体", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label提示.Location = New System.Drawing.Point(337, 136)
        Me.Label提示.Name = "Label提示"
        Me.Label提示.Size = New System.Drawing.Size(297, 93)
        Me.Label提示.TabIndex = 25
        Me.Label提示.Text = "提示：要先完成基本信息的添加才能添" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "加图片；基本信息一经添加，就不能单" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "独删除，添加前请确认信息正确！在专" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "题添加过程中请勿更改标题，否则系统" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "将默认您已" & _
    "完成当前专题的添加！"
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(46, 42)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(47, 12)
        Me.Label44.TabIndex = 13
        Me.Label44.Text = "*经度："
        '
        'TextBox经度专题添加
        '
        Me.TextBox经度专题添加.Location = New System.Drawing.Point(104, 39)
        Me.TextBox经度专题添加.Name = "TextBox经度专题添加"
        Me.TextBox经度专题添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox经度专题添加.TabIndex = 14
        '
        'TextBox位置专题添加
        '
        Me.TextBox位置专题添加.Location = New System.Drawing.Point(104, 181)
        Me.TextBox位置专题添加.Name = "TextBox位置专题添加"
        Me.TextBox位置专题添加.Size = New System.Drawing.Size(207, 21)
        Me.TextBox位置专题添加.TabIndex = 24
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(357, 42)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(47, 12)
        Me.Label45.TabIndex = 15
        Me.Label45.Text = "*纬度："
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(16, 184)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(65, 12)
        Me.Label49.TabIndex = 19
        Me.Label49.Text = "参考位置："
        '
        'TextBox时间专题添加
        '
        Me.TextBox时间专题添加.Location = New System.Drawing.Point(104, 136)
        Me.TextBox时间专题添加.Name = "TextBox时间专题添加"
        Me.TextBox时间专题添加.Size = New System.Drawing.Size(207, 21)
        Me.TextBox时间专题添加.TabIndex = 23
        '
        'TextBox纬度专题添加
        '
        Me.TextBox纬度专题添加.Location = New System.Drawing.Point(423, 39)
        Me.TextBox纬度专题添加.Name = "TextBox纬度专题添加"
        Me.TextBox纬度专题添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox纬度专题添加.TabIndex = 20
        '
        'TextBox深度专题添加
        '
        Me.TextBox深度专题添加.Location = New System.Drawing.Point(423, 78)
        Me.TextBox深度专题添加.Name = "TextBox深度专题添加"
        Me.TextBox深度专题添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox深度专题添加.TabIndex = 22
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(8, 139)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(71, 12)
        Me.Label48.TabIndex = 18
        Me.Label48.Text = "*发震时间："
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(38, 88)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(47, 12)
        Me.Label46.TabIndex = 16
        Me.Label46.Text = "*震级："
        '
        'TextBox震级专题添加
        '
        Me.TextBox震级专题添加.Location = New System.Drawing.Point(104, 85)
        Me.TextBox震级专题添加.Name = "TextBox震级专题添加"
        Me.TextBox震级专题添加.Size = New System.Drawing.Size(122, 21)
        Me.TextBox震级专题添加.TabIndex = 21
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(335, 88)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(65, 12)
        Me.Label47.TabIndex = 17
        Me.Label47.Text = "震源深度："
        '
        'TabPage5
        '
        Me.TabPage5.Controls.Add(Me.Button17)
        Me.TabPage5.Controls.Add(Me.Label19)
        Me.TabPage5.Controls.Add(Me.TextBox3)
        Me.TabPage5.Controls.Add(Me.PictureBox6)
        Me.TabPage5.Controls.Add(Me.Label18)
        Me.TabPage5.Controls.Add(Me.TextBox2)
        Me.TabPage5.Controls.Add(Me.Button11)
        Me.TabPage5.Location = New System.Drawing.Point(4, 22)
        Me.TabPage5.Name = "TabPage5"
        Me.TabPage5.Size = New System.Drawing.Size(732, 537)
        Me.TabPage5.TabIndex = 5
        Me.TabPage5.Text = "图片信息"
        Me.TabPage5.UseVisualStyleBackColor = True
        '
        'Button17
        '
        Me.Button17.Location = New System.Drawing.Point(456, 15)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(107, 33)
        Me.Button17.TabIndex = 7
        Me.Button17.Text = "打开图片文件"
        Me.Button17.UseVisualStyleBackColor = True
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(19, 76)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(65, 12)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "添加说明："
        '
        'TextBox3
        '
        Me.TextBox3.BackColor = System.Drawing.Color.Gainsboro
        Me.TextBox3.Location = New System.Drawing.Point(22, 94)
        Me.TextBox3.Multiline = True
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(216, 417)
        Me.TextBox3.TabIndex = 5
        '
        'PictureBox6
        '
        Me.PictureBox6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox6.Location = New System.Drawing.Point(244, 59)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(470, 452)
        Me.PictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox6.TabIndex = 3
        Me.PictureBox6.TabStop = False
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(19, 24)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(41, 12)
        Me.Label18.TabIndex = 2
        Me.Label18.Text = "标题："
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(77, 21)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(274, 21)
        Me.TextBox2.TabIndex = 1
        '
        'Button11
        '
        Me.Button11.Location = New System.Drawing.Point(591, 15)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(123, 33)
        Me.Button11.TabIndex = 0
        Me.Button11.Text = "添加此图片"
        Me.Button11.UseVisualStyleBackColor = True
        '
        'TextBox专题名称
        '
        Me.TextBox专题名称.Location = New System.Drawing.Point(111, 21)
        Me.TextBox专题名称.Name = "TextBox专题名称"
        Me.TextBox专题名称.Size = New System.Drawing.Size(426, 21)
        Me.TextBox专题名称.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label1.Location = New System.Drawing.Point(34, 24)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(71, 12)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "*专题名称："
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.Button36)
        Me.TabPage4.Controls.Add(Me.ComboBox1)
        Me.TabPage4.Controls.Add(Me.Label30)
        Me.TabPage4.Controls.Add(Me.TabControl5)
        Me.TabPage4.Location = New System.Drawing.Point(4, 22)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(775, 656)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "地震专题删除"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Button36
        '
        Me.Button36.Location = New System.Drawing.Point(597, 27)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(129, 40)
        Me.Button36.TabIndex = 10
        Me.Button36.Text = "删除此专题"
        Me.Button36.UseVisualStyleBackColor = True
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(95, 27)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(414, 20)
        Me.ComboBox1.TabIndex = 7
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Font = New System.Drawing.Font("宋体", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label30.Location = New System.Drawing.Point(29, 30)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(47, 12)
        Me.Label30.TabIndex = 6
        Me.Label30.Text = "*标题："
        '
        'TabControl5
        '
        Me.TabControl5.Controls.Add(Me.TabPage8)
        Me.TabControl5.Controls.Add(Me.TabPage16)
        Me.TabControl5.Location = New System.Drawing.Point(18, 73)
        Me.TabControl5.Name = "TabControl5"
        Me.TabControl5.SelectedIndex = 0
        Me.TabControl5.Size = New System.Drawing.Size(740, 563)
        Me.TabControl5.TabIndex = 5
        '
        'TabPage8
        '
        Me.TabPage8.Controls.Add(Me.GroupBox6)
        Me.TabPage8.Location = New System.Drawing.Point(4, 22)
        Me.TabPage8.Name = "TabPage8"
        Me.TabPage8.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage8.Size = New System.Drawing.Size(732, 537)
        Me.TabPage8.TabIndex = 0
        Me.TabPage8.Text = "基本信息"
        Me.TabPage8.UseVisualStyleBackColor = True
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Controls.Add(Me.TextBox专题修改经度)
        Me.GroupBox6.Controls.Add(Me.TextBox专题修改位置)
        Me.GroupBox6.Controls.Add(Me.Label25)
        Me.GroupBox6.Controls.Add(Me.Label26)
        Me.GroupBox6.Controls.Add(Me.TextBox专题修改时间)
        Me.GroupBox6.Controls.Add(Me.TextBox专题修改纬度)
        Me.GroupBox6.Controls.Add(Me.TextBox专题修改深度)
        Me.GroupBox6.Controls.Add(Me.Label27)
        Me.GroupBox6.Controls.Add(Me.Label28)
        Me.GroupBox6.Controls.Add(Me.TextBox专题修改震级)
        Me.GroupBox6.Controls.Add(Me.Label29)
        Me.GroupBox6.Location = New System.Drawing.Point(45, 34)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(631, 328)
        Me.GroupBox6.TabIndex = 26
        Me.GroupBox6.TabStop = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(46, 42)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(47, 12)
        Me.Label24.TabIndex = 13
        Me.Label24.Text = "*经度："
        '
        'TextBox专题修改经度
        '
        Me.TextBox专题修改经度.Location = New System.Drawing.Point(104, 39)
        Me.TextBox专题修改经度.Name = "TextBox专题修改经度"
        Me.TextBox专题修改经度.ReadOnly = True
        Me.TextBox专题修改经度.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题修改经度.TabIndex = 14
        '
        'TextBox专题修改位置
        '
        Me.TextBox专题修改位置.Location = New System.Drawing.Point(104, 174)
        Me.TextBox专题修改位置.Name = "TextBox专题修改位置"
        Me.TextBox专题修改位置.ReadOnly = True
        Me.TextBox专题修改位置.Size = New System.Drawing.Size(207, 21)
        Me.TextBox专题修改位置.TabIndex = 24
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(362, 42)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(47, 12)
        Me.Label25.TabIndex = 15
        Me.Label25.Text = "*纬度："
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(24, 177)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(65, 12)
        Me.Label26.TabIndex = 19
        Me.Label26.Text = "参考位置："
        '
        'TextBox专题修改时间
        '
        Me.TextBox专题修改时间.Location = New System.Drawing.Point(104, 129)
        Me.TextBox专题修改时间.Name = "TextBox专题修改时间"
        Me.TextBox专题修改时间.ReadOnly = True
        Me.TextBox专题修改时间.Size = New System.Drawing.Size(207, 21)
        Me.TextBox专题修改时间.TabIndex = 23
        '
        'TextBox专题修改纬度
        '
        Me.TextBox专题修改纬度.Location = New System.Drawing.Point(428, 39)
        Me.TextBox专题修改纬度.Name = "TextBox专题修改纬度"
        Me.TextBox专题修改纬度.ReadOnly = True
        Me.TextBox专题修改纬度.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题修改纬度.TabIndex = 20
        '
        'TextBox专题修改深度
        '
        Me.TextBox专题修改深度.Location = New System.Drawing.Point(428, 85)
        Me.TextBox专题修改深度.Name = "TextBox专题修改深度"
        Me.TextBox专题修改深度.ReadOnly = True
        Me.TextBox专题修改深度.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题修改深度.TabIndex = 22
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(16, 132)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(71, 12)
        Me.Label27.TabIndex = 18
        Me.Label27.Text = "*发震时间："
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(46, 88)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(47, 12)
        Me.Label28.TabIndex = 16
        Me.Label28.Text = "*震级："
        '
        'TextBox专题修改震级
        '
        Me.TextBox专题修改震级.Location = New System.Drawing.Point(104, 85)
        Me.TextBox专题修改震级.Name = "TextBox专题修改震级"
        Me.TextBox专题修改震级.ReadOnly = True
        Me.TextBox专题修改震级.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题修改震级.TabIndex = 21
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(340, 88)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(65, 12)
        Me.Label29.TabIndex = 17
        Me.Label29.Text = "震源深度："
        '
        'TabPage16
        '
        Me.TabPage16.Controls.Add(Me.Button21)
        Me.TabPage16.Controls.Add(Me.Button12)
        Me.TabPage16.Controls.Add(Me.TextBox4)
        Me.TabPage16.Controls.Add(Me.Label21)
        Me.TabPage16.Controls.Add(Me.PictureBox7)
        Me.TabPage16.Controls.Add(Me.TextBox1)
        Me.TabPage16.Controls.Add(Me.Label20)
        Me.TabPage16.Controls.Add(Me.Button2)
        Me.TabPage16.Location = New System.Drawing.Point(4, 22)
        Me.TabPage16.Name = "TabPage16"
        Me.TabPage16.Size = New System.Drawing.Size(732, 537)
        Me.TabPage16.TabIndex = 5
        Me.TabPage16.Text = "图文信息"
        Me.TabPage16.UseVisualStyleBackColor = True
        '
        'Button21
        '
        Me.Button21.Location = New System.Drawing.Point(575, 17)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(129, 40)
        Me.Button21.TabIndex = 11
        Me.Button21.Text = "仅删除该图片"
        Me.Button21.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Location = New System.Drawing.Point(144, 468)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(75, 44)
        Me.Button12.TabIndex = 6
        Me.Button12.Text = "下一张"
        Me.Button12.UseVisualStyleBackColor = True
        '
        'TextBox4
        '
        Me.TextBox4.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.TextBox4.Location = New System.Drawing.Point(18, 86)
        Me.TextBox4.Multiline = True
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(218, 359)
        Me.TextBox4.TabIndex = 5
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(15, 68)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(41, 12)
        Me.Label21.TabIndex = 4
        Me.Label21.Text = "说明："
        '
        'PictureBox7
        '
        Me.PictureBox7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox7.Location = New System.Drawing.Point(242, 68)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(475, 444)
        Me.PictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox7.TabIndex = 3
        Me.PictureBox7.TabStop = False
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(73, 17)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 21)
        Me.TextBox1.TabIndex = 2
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(15, 20)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(41, 12)
        Me.Label20.TabIndex = 1
        Me.Label20.Text = "标题："
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(18, 468)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 44)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "上一张"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'TabPage11
        '
        Me.TabPage11.Controls.Add(Me.TextBox说明2)
        Me.TabPage11.Controls.Add(Me.Label32)
        Me.TabPage11.Controls.Add(Me.TextBox5)
        Me.TabPage11.Controls.Add(Me.Button3)
        Me.TabPage11.Controls.Add(Me.Button4)
        Me.TabPage11.Controls.Add(Me.Label36)
        Me.TabPage11.Controls.Add(Me.PictureBox1)
        Me.TabPage11.Location = New System.Drawing.Point(4, 22)
        Me.TabPage11.Name = "TabPage11"
        Me.TabPage11.Size = New System.Drawing.Size(775, 656)
        Me.TabPage11.TabIndex = 4
        Me.TabPage11.Text = "添加科普单元"
        Me.TabPage11.UseVisualStyleBackColor = True
        '
        'TextBox说明2
        '
        Me.TextBox说明2.Location = New System.Drawing.Point(94, 531)
        Me.TextBox说明2.Multiline = True
        Me.TextBox说明2.Name = "TextBox说明2"
        Me.TextBox说明2.Size = New System.Drawing.Size(655, 90)
        Me.TextBox说明2.TabIndex = 36
        '
        'Label32
        '
        Me.Label32.AutoSize = True
        Me.Label32.Location = New System.Drawing.Point(35, 528)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(53, 12)
        Me.Label32.TabIndex = 31
        Me.Label32.Text = "添加文字"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(152, 48)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(382, 21)
        Me.TextBox5.TabIndex = 29
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(591, 41)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(131, 33)
        Me.Button3.TabIndex = 24
        Me.Button3.Text = "保存此单元"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(56, 96)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(90, 50)
        Me.Button4.TabIndex = 23
        Me.Button4.Text = "点此添加图片"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Label36
        '
        Me.Label36.AutoSize = True
        Me.Label36.Location = New System.Drawing.Point(105, 55)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(41, 12)
        Me.Label36.TabIndex = 21
        Me.Label36.Text = "标题："
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(37, 80)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(712, 445)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox1.TabIndex = 22
        Me.PictureBox1.TabStop = False
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.Label删除说明2)
        Me.TabPage12.Controls.Add(Me.Button18)
        Me.TabPage12.Controls.Add(Me.ComboBox删除科普标题)
        Me.TabPage12.Controls.Add(Me.Label删除说明3)
        Me.TabPage12.Controls.Add(Me.Label删除说明1)
        Me.TabPage12.Controls.Add(Me.Label39)
        Me.TabPage12.Controls.Add(Me.PictureBox删除说明)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(775, 656)
        Me.TabPage12.TabIndex = 5
        Me.TabPage12.Text = "删除科普单元"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'Label删除说明2
        '
        Me.Label删除说明2.Font = New System.Drawing.Font("宋体", 10.5!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label删除说明2.ForeColor = System.Drawing.Color.Red
        Me.Label删除说明2.Location = New System.Drawing.Point(64, 543)
        Me.Label删除说明2.Name = "Label删除说明2"
        Me.Label删除说明2.Size = New System.Drawing.Size(639, 92)
        Me.Label删除说明2.TabIndex = 29
        '
        'Button18
        '
        Me.Button18.Location = New System.Drawing.Point(605, 25)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(83, 41)
        Me.Button18.TabIndex = 28
        Me.Button18.Text = "删除此单元"
        Me.Button18.UseVisualStyleBackColor = True
        '
        'ComboBox删除科普标题
        '
        Me.ComboBox删除科普标题.FormattingEnabled = True
        Me.ComboBox删除科普标题.Location = New System.Drawing.Point(112, 36)
        Me.ComboBox删除科普标题.Name = "ComboBox删除科普标题"
        Me.ComboBox删除科普标题.Size = New System.Drawing.Size(361, 20)
        Me.ComboBox删除科普标题.TabIndex = 27
        '
        'Label删除说明3
        '
        Me.Label删除说明3.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label删除说明3.ForeColor = System.Drawing.Color.Red
        Me.Label删除说明3.Location = New System.Drawing.Point(459, 92)
        Me.Label删除说明3.Name = "Label删除说明3"
        Me.Label删除说明3.Size = New System.Drawing.Size(107, 10)
        Me.Label删除说明3.TabIndex = 26
        '
        'Label删除说明1
        '
        Me.Label删除说明1.Font = New System.Drawing.Font("宋体", 10.5!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label删除说明1.Location = New System.Drawing.Point(15, 92)
        Me.Label删除说明1.Name = "Label删除说明1"
        Me.Label删除说明1.Size = New System.Drawing.Size(10, 102)
        Me.Label删除说明1.TabIndex = 25
        '
        'Label39
        '
        Me.Label39.AutoSize = True
        Me.Label39.Location = New System.Drawing.Point(65, 39)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(41, 12)
        Me.Label39.TabIndex = 21
        Me.Label39.Text = "标题："
        '
        'PictureBox删除说明
        '
        Me.PictureBox删除说明.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox删除说明.Location = New System.Drawing.Point(67, 72)
        Me.PictureBox删除说明.Name = "PictureBox删除说明"
        Me.PictureBox删除说明.Size = New System.Drawing.Size(636, 468)
        Me.PictureBox删除说明.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox删除说明.TabIndex = 22
        Me.PictureBox删除说明.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.ProgressBar2)
        Me.GroupBox7.Location = New System.Drawing.Point(281, 305)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(447, 73)
        Me.GroupBox7.TabIndex = 56
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "正在执行当前操作，请稍后"
        Me.GroupBox7.Visible = False
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(30, 22)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(387, 23)
        Me.ProgressBar2.TabIndex = 0
        '
        'Form4
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._2669c2f13c906965e862b251146994b6_1_
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1047, 706)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form4"
        Me.Text = "管理员系统"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage7.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabControl3.ResumeLayout(False)
        Me.TabPage9.ResumeLayout(False)
        Me.TabPage9.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage3.PerformLayout()
        Me.TabControl4.ResumeLayout(False)
        Me.TabPage10.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.TabPage5.ResumeLayout(False)
        Me.TabPage5.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.TabPage4.PerformLayout()
        Me.TabControl5.ResumeLayout(False)
        Me.TabPage8.ResumeLayout(False)
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.TabPage16.ResumeLayout(False)
        Me.TabPage16.PerformLayout()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage11.ResumeLayout(False)
        Me.TabPage11.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        CType(Me.PictureBox删除说明, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage7 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox专题名称 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl4 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage10 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox位置专题添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox时间专题添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox深度专题添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox震级专题添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox纬度专题添加 As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents TextBox经度专题添加 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox经度添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox位置添加 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox时间添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox纬度添加 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox深度添加 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox震级添加 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TabControl3 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage9 As System.Windows.Forms.TabPage
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents TextBox震级删除上限 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox震级删除下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents TextBox经度删除上限 As System.Windows.Forms.TextBox
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents TextBox经度删除下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents TextBox纬度删除上限 As System.Windows.Forms.TextBox
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents TextBox纬度删除下限 As System.Windows.Forms.TextBox
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents ComboBox时间删除上限 As System.Windows.Forms.ComboBox
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents ComboBox时间删除下限 As System.Windows.Forms.ComboBox
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents TextBox经度删除浏览 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox位置删除浏览 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox时间删除浏览 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox纬度删除浏览 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox深度删除浏览 As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox震级删除浏览 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents TabControl5 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage8 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TextBox专题修改经度 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题修改位置 As System.Windows.Forms.TextBox
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox专题修改时间 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题修改纬度 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题修改深度 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents TextBox专题修改震级 As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents DataGridView3 As System.Windows.Forms.DataGridView
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Label文件路径 As System.Windows.Forms.Label
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents TabPage5 As System.Windows.Forms.TabPage
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TabPage16 As System.Windows.Forms.TabPage
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents PictureBox7 As System.Windows.Forms.PictureBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label导入 As System.Windows.Forms.Label
    Friend WithEvents Label重复 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Labelerr As System.Windows.Forms.Label
    Friend WithEvents TabPage11 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents TextBox说明2 As System.Windows.Forms.TextBox
    Friend WithEvents Label删除说明2 As System.Windows.Forms.Label
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents ComboBox删除科普标题 As System.Windows.Forms.ComboBox
    Friend WithEvents Label删除说明3 As System.Windows.Forms.Label
    Friend WithEvents Label删除说明1 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents PictureBox删除说明 As System.Windows.Forms.PictureBox
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents ComboBox专题添加 As System.Windows.Forms.ComboBox
    Friend WithEvents Label提示 As System.Windows.Forms.Label
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
End Class
