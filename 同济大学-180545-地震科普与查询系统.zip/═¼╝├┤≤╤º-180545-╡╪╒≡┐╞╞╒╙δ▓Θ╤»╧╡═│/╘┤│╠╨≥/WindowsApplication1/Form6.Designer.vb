﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form6
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.TabControl2 = New System.Windows.Forms.TabControl()
        Me.TabPage6 = New System.Windows.Forms.TabPage()
        Me.TextBox专题查询标题 = New System.Windows.Forms.TextBox()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.TextBox专题查询位置 = New System.Windows.Forms.TextBox()
        Me.TextBox专题查询时间 = New System.Windows.Forms.TextBox()
        Me.TextBox专题查询深度 = New System.Windows.Forms.TextBox()
        Me.TextBox专题查询震级 = New System.Windows.Forms.TextBox()
        Me.TextBox专题查询纬度 = New System.Windows.Forms.TextBox()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.TextBox专题查询经度 = New System.Windows.Forms.TextBox()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.TabPage12 = New System.Windows.Forms.TabPage()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.ComboBox专题查询 = New System.Windows.Forms.ComboBox()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TreeView1 = New System.Windows.Forms.TreeView()
        Me.Label说明3 = New System.Windows.Forms.Label()
        Me.Label说明2 = New System.Windows.Forms.Label()
        Me.Label说明1 = New System.Windows.Forms.Label()
        Me.PictureBox说明 = New System.Windows.Forms.PictureBox()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabControl2.SuspendLayout()
        Me.TabPage6.SuspendLayout()
        Me.TabPage12.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox说明, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(66, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(933, 925)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.TabControl2)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.ComboBox专题查询)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(925, 899)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "地震专题"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'TabControl2
        '
        Me.TabControl2.Controls.Add(Me.TabPage6)
        Me.TabControl2.Controls.Add(Me.TabPage12)
        Me.TabControl2.Location = New System.Drawing.Point(21, 60)
        Me.TabControl2.Name = "TabControl2"
        Me.TabControl2.SelectedIndex = 0
        Me.TabControl2.Size = New System.Drawing.Size(884, 784)
        Me.TabControl2.TabIndex = 8
        '
        'TabPage6
        '
        Me.TabPage6.BackColor = System.Drawing.Color.White
        Me.TabPage6.Controls.Add(Me.TextBox专题查询标题)
        Me.TabPage6.Controls.Add(Me.Label50)
        Me.TabPage6.Controls.Add(Me.TextBox专题查询位置)
        Me.TabPage6.Controls.Add(Me.TextBox专题查询时间)
        Me.TabPage6.Controls.Add(Me.TextBox专题查询深度)
        Me.TabPage6.Controls.Add(Me.TextBox专题查询震级)
        Me.TabPage6.Controls.Add(Me.TextBox专题查询纬度)
        Me.TabPage6.Controls.Add(Me.Label49)
        Me.TabPage6.Controls.Add(Me.Label48)
        Me.TabPage6.Controls.Add(Me.Label47)
        Me.TabPage6.Controls.Add(Me.Label46)
        Me.TabPage6.Controls.Add(Me.Label45)
        Me.TabPage6.Controls.Add(Me.TextBox专题查询经度)
        Me.TabPage6.Controls.Add(Me.Label44)
        Me.TabPage6.Location = New System.Drawing.Point(4, 22)
        Me.TabPage6.Name = "TabPage6"
        Me.TabPage6.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage6.Size = New System.Drawing.Size(876, 758)
        Me.TabPage6.TabIndex = 0
        Me.TabPage6.Text = "基本信息"
        '
        'TextBox专题查询标题
        '
        Me.TextBox专题查询标题.Location = New System.Drawing.Point(81, 28)
        Me.TextBox专题查询标题.Name = "TextBox专题查询标题"
        Me.TextBox专题查询标题.ReadOnly = True
        Me.TextBox专题查询标题.Size = New System.Drawing.Size(623, 21)
        Me.TextBox专题查询标题.TabIndex = 26
        '
        'Label50
        '
        Me.Label50.AutoSize = True
        Me.Label50.Location = New System.Drawing.Point(23, 31)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(41, 12)
        Me.Label50.TabIndex = 25
        Me.Label50.Text = "标题："
        '
        'TextBox专题查询位置
        '
        Me.TextBox专题查询位置.Location = New System.Drawing.Point(453, 142)
        Me.TextBox专题查询位置.Name = "TextBox专题查询位置"
        Me.TextBox专题查询位置.ReadOnly = True
        Me.TextBox专题查询位置.Size = New System.Drawing.Size(207, 21)
        Me.TextBox专题查询位置.TabIndex = 24
        '
        'TextBox专题查询时间
        '
        Me.TextBox专题查询时间.Location = New System.Drawing.Point(111, 142)
        Me.TextBox专题查询时间.Name = "TextBox专题查询时间"
        Me.TextBox专题查询时间.ReadOnly = True
        Me.TextBox专题查询时间.Size = New System.Drawing.Size(207, 21)
        Me.TextBox专题查询时间.TabIndex = 23
        '
        'TextBox专题查询深度
        '
        Me.TextBox专题查询深度.Location = New System.Drawing.Point(368, 101)
        Me.TextBox专题查询深度.Name = "TextBox专题查询深度"
        Me.TextBox专题查询深度.ReadOnly = True
        Me.TextBox专题查询深度.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题查询深度.TabIndex = 22
        '
        'TextBox专题查询震级
        '
        Me.TextBox专题查询震级.Location = New System.Drawing.Point(81, 101)
        Me.TextBox专题查询震级.Name = "TextBox专题查询震级"
        Me.TextBox专题查询震级.ReadOnly = True
        Me.TextBox专题查询震级.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题查询震级.TabIndex = 21
        '
        'TextBox专题查询纬度
        '
        Me.TextBox专题查询纬度.Location = New System.Drawing.Point(368, 64)
        Me.TextBox专题查询纬度.Name = "TextBox专题查询纬度"
        Me.TextBox专题查询纬度.ReadOnly = True
        Me.TextBox专题查询纬度.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题查询纬度.TabIndex = 20
        '
        'Label49
        '
        Me.Label49.AutoSize = True
        Me.Label49.Location = New System.Drawing.Point(365, 145)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(65, 12)
        Me.Label49.TabIndex = 19
        Me.Label49.Text = "参考位置："
        '
        'Label48
        '
        Me.Label48.AutoSize = True
        Me.Label48.Location = New System.Drawing.Point(23, 145)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(65, 12)
        Me.Label48.TabIndex = 18
        Me.Label48.Text = "发震时间："
        '
        'Label47
        '
        Me.Label47.AutoSize = True
        Me.Label47.Location = New System.Drawing.Point(280, 104)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(65, 12)
        Me.Label47.TabIndex = 17
        Me.Label47.Text = "震源深度："
        '
        'Label46
        '
        Me.Label46.AutoSize = True
        Me.Label46.Location = New System.Drawing.Point(23, 104)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(41, 12)
        Me.Label46.TabIndex = 16
        Me.Label46.Text = "震级："
        '
        'Label45
        '
        Me.Label45.AutoSize = True
        Me.Label45.Location = New System.Drawing.Point(310, 67)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(41, 12)
        Me.Label45.TabIndex = 15
        Me.Label45.Text = "纬度："
        '
        'TextBox专题查询经度
        '
        Me.TextBox专题查询经度.Location = New System.Drawing.Point(81, 64)
        Me.TextBox专题查询经度.Name = "TextBox专题查询经度"
        Me.TextBox专题查询经度.ReadOnly = True
        Me.TextBox专题查询经度.Size = New System.Drawing.Size(122, 21)
        Me.TextBox专题查询经度.TabIndex = 14
        '
        'Label44
        '
        Me.Label44.AutoSize = True
        Me.Label44.Location = New System.Drawing.Point(23, 67)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(41, 12)
        Me.Label44.TabIndex = 13
        Me.Label44.Text = "经度："
        '
        'TabPage12
        '
        Me.TabPage12.Controls.Add(Me.Button7)
        Me.TabPage12.Controls.Add(Me.TextBox2)
        Me.TabPage12.Controls.Add(Me.Button6)
        Me.TabPage12.Controls.Add(Me.TextBox1)
        Me.TabPage12.Controls.Add(Me.Label77)
        Me.TabPage12.Controls.Add(Me.PictureBox3)
        Me.TabPage12.Location = New System.Drawing.Point(4, 22)
        Me.TabPage12.Name = "TabPage12"
        Me.TabPage12.Size = New System.Drawing.Size(876, 758)
        Me.TabPage12.TabIndex = 6
        Me.TabPage12.Text = "图文信息"
        Me.TabPage12.UseVisualStyleBackColor = True
        '
        'Button7
        '
        Me.Button7.Location = New System.Drawing.Point(727, 8)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(75, 42)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "下一张"
        Me.Button7.UseVisualStyleBackColor = True
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.Color.Gainsboro
        Me.TextBox2.Location = New System.Drawing.Point(21, 674)
        Me.TextBox2.Multiline = True
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(829, 78)
        Me.TextBox2.TabIndex = 5
        '
        'Button6
        '
        Me.Button6.Location = New System.Drawing.Point(609, 8)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(75, 42)
        Me.Button6.TabIndex = 3
        Me.Button6.Text = "上一张"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(67, 15)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.ReadOnly = True
        Me.TextBox1.Size = New System.Drawing.Size(485, 21)
        Me.TextBox1.TabIndex = 1
        '
        'Label77
        '
        Me.Label77.AutoSize = True
        Me.Label77.Location = New System.Drawing.Point(19, 18)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(41, 12)
        Me.Label77.TabIndex = 0
        Me.Label77.Text = "标题："
        '
        'PictureBox3
        '
        Me.PictureBox3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox3.Location = New System.Drawing.Point(21, 56)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(829, 612)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(23, 21)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(65, 12)
        Me.Label21.TabIndex = 7
        Me.Label21.Text = "专题选择："
        '
        'ComboBox专题查询
        '
        Me.ComboBox专题查询.FormattingEnabled = True
        Me.ComboBox专题查询.Location = New System.Drawing.Point(94, 18)
        Me.ComboBox专题查询.Name = "ComboBox专题查询"
        Me.ComboBox专题查询.Size = New System.Drawing.Size(623, 20)
        Me.ComboBox专题查询.TabIndex = 6
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Label1)
        Me.TabPage2.Controls.Add(Me.TextBox3)
        Me.TabPage2.Controls.Add(Me.TreeView1)
        Me.TabPage2.Controls.Add(Me.Label说明3)
        Me.TabPage2.Controls.Add(Me.Label说明2)
        Me.TabPage2.Controls.Add(Me.Label说明1)
        Me.TabPage2.Controls.Add(Me.PictureBox说明)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(925, 899)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "科普知识"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(207, 57)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 12)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "标题："
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(254, 54)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.ReadOnly = True
        Me.TextBox3.Size = New System.Drawing.Size(587, 21)
        Me.TextBox3.TabIndex = 21
        '
        'TreeView1
        '
        Me.TreeView1.Location = New System.Drawing.Point(6, 31)
        Me.TreeView1.Name = "TreeView1"
        Me.TreeView1.Size = New System.Drawing.Size(146, 742)
        Me.TreeView1.TabIndex = 20
        '
        'Label说明3
        '
        Me.Label说明3.Font = New System.Drawing.Font("宋体", 10.5!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label说明3.ForeColor = System.Drawing.Color.Red
        Me.Label说明3.Location = New System.Drawing.Point(158, 31)
        Me.Label说明3.Name = "Label说明3"
        Me.Label说明3.Size = New System.Drawing.Size(752, 71)
        Me.Label说明3.TabIndex = 19
        '
        'Label说明2
        '
        Me.Label说明2.Font = New System.Drawing.Font("宋体", 10.5!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label说明2.ForeColor = System.Drawing.Color.Red
        Me.Label说明2.Location = New System.Drawing.Point(155, 659)
        Me.Label说明2.Name = "Label说明2"
        Me.Label说明2.Size = New System.Drawing.Size(755, 114)
        Me.Label说明2.TabIndex = 18
        '
        'Label说明1
        '
        Me.Label说明1.Font = New System.Drawing.Font("宋体", 10.5!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(134, Byte))
        Me.Label说明1.Location = New System.Drawing.Point(206, -34)
        Me.Label说明1.Name = "Label说明1"
        Me.Label说明1.Size = New System.Drawing.Size(612, 81)
        Me.Label说明1.TabIndex = 17
        '
        'PictureBox说明
        '
        Me.PictureBox说明.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox说明.Location = New System.Drawing.Point(158, 105)
        Me.PictureBox说明.Name = "PictureBox说明"
        Me.PictureBox说明.Size = New System.Drawing.Size(752, 551)
        Me.PictureBox说明.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox说明.TabIndex = 11
        Me.PictureBox说明.TabStop = False
        '
        'Form6
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.AutoScroll = True
        Me.BackgroundImage = Global.WindowsApplication1.My.Resources.Resources._2669c2f13c906965e862b251146994b6_1_
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1070, 690)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form6"
        Me.Text = "地震专题与地震科普"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabControl2.ResumeLayout(False)
        Me.TabPage6.ResumeLayout(False)
        Me.TabPage6.PerformLayout()
        Me.TabPage12.ResumeLayout(False)
        Me.TabPage12.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox说明, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabControl2 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage6 As System.Windows.Forms.TabPage
    Friend WithEvents TextBox专题查询标题 As System.Windows.Forms.TextBox
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents TextBox专题查询位置 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题查询时间 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题查询深度 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题查询震级 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox专题查询纬度 As System.Windows.Forms.TextBox
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents TextBox专题查询经度 As System.Windows.Forms.TextBox
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents TabPage12 As System.Windows.Forms.TabPage
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents ComboBox专题查询 As System.Windows.Forms.ComboBox
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label说明3 As System.Windows.Forms.Label
    Friend WithEvents Label说明2 As System.Windows.Forms.Label
    Friend WithEvents Label说明1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox说明 As System.Windows.Forms.PictureBox
    Friend WithEvents TreeView1 As System.Windows.Forms.TreeView
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
End Class
