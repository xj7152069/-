﻿Imports System.Data.SqlClient
Imports System.Math
Imports System.Drawing.Drawing2D
Imports System.IO
Imports System.Data.OleDb
Public Class Form6
    Dim myconn As New SqlConnection("initial catalog=china earthquake;data source=10.10.109.119;user id=tj5;password=db18-5")
    Dim mydataset As New DataSet
    Dim mybind As New BindingSource
    Dim mybind1 As New BindingSource
    Dim c(16000), b(16000), d(16000) As Single

    Private Sub Form6_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.MaximizeBox = False
        Me.ComboBox专题查询.Items.Clear()
        Me.Label说明3.Parent = PictureBox说明
        Dim str2 As String = "select  distinct 专题名称 as x from information"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        For i = 0 To mydataset.Tables("t1").Rows.Count - 1
            Me.ComboBox专题查询.Items.Add(mydataset.Tables("t1").Rows(i).Item("x"))
        Next
        mydataset.Tables("t1").Clear()
        Dim mystr As String = "select * from photo where 专题名称='" & Me.ComboBox专题查询.Text & "'"
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        myadapter.Fill(mydataset, "专题删除")
        mydataset.Tables("专题删除").Clear()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs)
        mybind.MovePrevious()
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs)
        mybind.MoveNext()
    End Sub

    Private Sub TreeView1_AfterSelect(sender As Object, e As TreeViewEventArgs)

    End Sub

    Private Sub ComboBox专题查询_SelectedIndexChanged_1(sender As Object, e As EventArgs) Handles ComboBox专题查询.SelectedIndexChanged
        Me.TextBox专题查询标题.Clear()
        Me.TextBox专题查询经度.Clear()
        Me.TextBox专题查询深度.Clear()
        Me.TextBox专题查询时间.Clear()
        Me.TextBox专题查询纬度.Clear()
        Me.TextBox专题查询位置.Clear()
        Me.PictureBox3.Image = Nothing
        Me.TextBox专题查询震级.Clear()
        Me.TextBox1.Clear()
        Me.TextBox2.Clear()
        Dim str2 As String = "select  * from information where information.专题名称='" & Me.ComboBox专题查询.Text & "'"
        Dim myad2 As New SqlDataAdapter(str2, myconn)
        myad2.Fill(mydataset, "t1")
        Me.TextBox专题查询经度.Text = mydataset.Tables("t1").Rows(0).Item("经度")
        Me.TextBox专题查询深度.Text = mydataset.Tables("t1").Rows(0).Item("震源深度")
        Me.TextBox专题查询时间.Text = mydataset.Tables("t1").Rows(0).Item("时间")
        Me.TextBox专题查询纬度.Text = mydataset.Tables("t1").Rows(0).Item("纬度")
        Me.TextBox专题查询位置.Text = mydataset.Tables("t1").Rows(0).Item("区域位置")
        Me.TextBox专题查询震级.Text = mydataset.Tables("t1").Rows(0).Item("震级")
        Me.TextBox专题查询标题.Text = Me.ComboBox专题查询.Text
        mydataset.Tables("t1").Clear()
        mydataset.Tables("专题删除").Clear()
        PictureBox3.Image = Nothing
        TextBox1.Clear()
        TextBox2.Clear()
        Dim mystr As String = "select * from photo where 专题名称='" & Me.ComboBox专题查询.Text & "'"
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        myadapter.Fill(mydataset, "专题删除")
        TextBox1.DataBindings.Clear()
        TextBox2.DataBindings.Clear()
        PictureBox3.DataBindings.Clear()
        mybind.DataSource = mydataset
        mybind.DataMember = "专题删除"
        TextBox1.DataBindings.Add(New Binding("text", mybind, "照片标题", True))
        TextBox2.DataBindings.Add(New Binding("text", mybind, "说明", True))
        PictureBox3.DataBindings.Add(New Binding("image", mybind, "图片", True))
    End Sub

    Private Sub Button6_Click_1(sender As Object, e As EventArgs) Handles Button6.Click
        mybind.MovePrevious()
    End Sub

    Private Sub Button7_Click_1(sender As Object, e As EventArgs) Handles Button7.Click
        mybind.MoveNext()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs)
        mybind1.MovePrevious()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        mybind1.MoveNext()
    End Sub

    Private Sub TabPage2_Enter(sender As Object, e As EventArgs) Handles TabPage2.Enter
        PictureBox说明.Image = Nothing
        Dim mystr As String = "select * from picture  "
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        myadapter.Fill(mydataset, "科普")
        For i = 0 To mydataset.Tables("科普").Rows.Count - 1
            Me.TreeView1.Nodes.Add(mydataset.Tables("科普").Rows(i).Item("科普标题"))
        Next
    End Sub

    Private Sub TabPage2_Click(sender As Object, e As EventArgs) Handles TabPage2.Click

    End Sub

    Private Sub TreeView1_AfterSelect_1(sender As Object, e As TreeViewEventArgs) Handles TreeView1.AfterSelect
        mydataset.Tables("科普").Clear()
        Dim mystr As String = "select * from picture where 科普标题='" & Me.TreeView1.SelectedNode.Text & "' "
        Dim myadapter As New SqlDataAdapter(mystr, myconn)
        myadapter.Fill(mydataset, "科普")
        Label说明2.DataBindings.Clear()
        PictureBox说明.DataBindings.Clear()
        mybind1.DataSource = mydataset
        mybind1.DataMember = "科普"
        Label说明2.DataBindings.Add(New Binding("text", mybind1, "说明2", True))
        PictureBox说明.DataBindings.Add(New Binding("image", mybind1, "图片", True))
        Me.TextBox3.Text = Me.TreeView1.SelectedNode.Text
    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub
End Class